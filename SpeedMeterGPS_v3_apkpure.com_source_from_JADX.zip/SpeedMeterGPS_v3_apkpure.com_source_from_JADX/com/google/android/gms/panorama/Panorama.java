package com.google.android.gms.panorama;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.C0047a;
import com.google.android.gms.common.api.Api.C0048b;
import com.google.android.gms.common.api.Api.C0049c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.internal.gz;
import com.google.android.gms.internal.kg;
import com.google.android.gms.internal.kh;

public final class Panorama {
    public static final Api<NoOptions> API;
    public static final PanoramaApi PanoramaApi;
    public static final C0049c<kh> yE;
    static final C0048b<kh, NoOptions> yF;

    /* renamed from: com.google.android.gms.panorama.Panorama.1 */
    static class C07971 implements C0048b<kh, NoOptions> {
        C07971() {
        }

        public /* synthetic */ C0047a m2887a(Context context, Looper looper, gz gzVar, Object obj, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return m2888d(context, looper, gzVar, (NoOptions) obj, connectionCallbacks, onConnectionFailedListener);
        }

        public kh m2888d(Context context, Looper looper, gz gzVar, NoOptions noOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new kh(context, looper, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    static {
        yE = new C0049c();
        yF = new C07971();
        API = new Api(yF, yE, new Scope[0]);
        PanoramaApi = new kg();
    }

    private Panorama() {
    }
}
