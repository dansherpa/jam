package com.google.android.gms.drive.events;

import android.app.IntentService;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.internal.hn;
import com.google.android.gms.tagmanager.DataLayer;
import com.google.android.gms.wearable.DataEvent;
import java.util.concurrent.LinkedBlockingDeque;

public abstract class DriveEventService extends IntentService {
    private static final LinkedBlockingDeque<DriveEvent> Ie;
    private final String mName;

    /* renamed from: com.google.android.gms.drive.events.DriveEventService.1 */
    class C00791 extends Binder {
        final /* synthetic */ DriveEventService If;

        C00791(DriveEventService driveEventService) {
            this.If = driveEventService;
        }

        protected boolean onTransact(int code, Parcel in, Parcel out, int flags) {
            Log.d("DriveEventService", "onTransact");
            DriveEventService.Ie.add((DriveEvent) in.readParcelable(this.If.getClassLoader()));
            this.If.startService(new Intent(this.If, this.If.getClass()));
            return true;
        }
    }

    static {
        Ie = new LinkedBlockingDeque();
    }

    protected DriveEventService() {
        this("DriveEventService");
    }

    protected DriveEventService(String name) {
        super(name);
        this.mName = name;
    }

    private void m261a(DriveEvent driveEvent) {
        try {
            switch (driveEvent.getType()) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    hn.m1225a(driveEvent instanceof ChangeEvent, "Unexpected event type: %s", driveEvent);
                    onChangeEvent((ChangeEvent) driveEvent);
                case DataEvent.TYPE_DELETED /*2*/:
                    hn.m1225a(driveEvent instanceof FileConflictEvent, "Unexpected event type: %s", driveEvent);
                    m262a((FileConflictEvent) driveEvent);
                default:
                    Log.w(this.mName, "Unrecognized event: " + driveEvent);
            }
        } catch (Throwable e) {
            Log.wtf(this.mName, "Service does not implement listener for type:" + driveEvent.getType(), e);
        } catch (Throwable e2) {
            Log.w(this.mName, "Error handling event: " + driveEvent, e2);
        }
    }

    public void m262a(FileConflictEvent fileConflictEvent) {
        Log.w("DriveEventService", "Unhandled FileConflictEvent: " + fileConflictEvent);
    }

    public IBinder onBind(Intent intent) {
        return new C00791(this);
    }

    public void onChangeEvent(ChangeEvent event) {
        Log.w("DriveEventService", "Unhandled ChangeEvent: " + event);
    }

    protected final void onHandleIntent(Intent intent) {
        intent.setExtrasClassLoader(getClassLoader());
        DriveEvent driveEvent = (DriveEvent) intent.getParcelableExtra(DataLayer.EVENT_KEY);
        if (driveEvent == null) {
            driveEvent = (DriveEvent) Ie.poll();
        }
        if (driveEvent != null) {
            m261a(driveEvent);
        } else {
            Log.e("DriveEventService", "The event queue is unexpectedly empty.");
        }
    }
}
