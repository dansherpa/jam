package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.drive.metadata.C0923b;
import java.util.ArrayList;
import java.util.Collection;

/* renamed from: com.google.android.gms.drive.metadata.internal.i */
public class C1074i<T extends Parcelable> extends C0923b<T> {
    public C1074i(String str, int i) {
        super(str, i);
    }

    protected void m3916a(Bundle bundle, Collection<T> collection) {
        bundle.putParcelableArrayList(getName(), new ArrayList(collection));
    }

    protected /* synthetic */ Object m3917f(Bundle bundle) {
        return m3918k(bundle);
    }

    protected Collection<T> m3918k(Bundle bundle) {
        return bundle.getParcelableArrayList(getName());
    }
}
