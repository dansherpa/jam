package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.ir;
import com.google.android.gms.internal.it;
import com.google.android.gms.internal.iv;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.metadata.internal.e */
public final class C0105e {
    private static Map<String, MetadataField<?>> JO;

    static {
        JO = new HashMap();
        C0105e.m362b(ir.JQ);
        C0105e.m362b(ir.Ko);
        C0105e.m362b(ir.Kh);
        C0105e.m362b(ir.Km);
        C0105e.m362b(ir.Kp);
        C0105e.m362b(ir.Kb);
        C0105e.m362b(ir.Kc);
        C0105e.m362b(ir.JZ);
        C0105e.m362b(ir.Ke);
        C0105e.m362b(ir.Kk);
        C0105e.m362b(ir.JR);
        C0105e.m362b(ir.Kj);
        C0105e.m362b(ir.JT);
        C0105e.m362b(ir.Ka);
        C0105e.m362b(ir.JU);
        C0105e.m362b(ir.JV);
        C0105e.m362b(ir.JW);
        C0105e.m362b(ir.Kg);
        C0105e.m362b(ir.Kd);
        C0105e.m362b(ir.Ki);
        C0105e.m362b(ir.Kl);
        C0105e.m362b(ir.Kq);
        C0105e.m362b(ir.Kr);
        C0105e.m362b(ir.JY);
        C0105e.m362b(ir.JX);
        C0105e.m362b(ir.Kn);
        C0105e.m362b(ir.Kf);
        C0105e.m362b(ir.JS);
        C0105e.m362b(ir.Ks);
        C0105e.m362b(it.Kt);
        C0105e.m362b(it.Kv);
        C0105e.m362b(it.Kw);
        C0105e.m362b(it.Kx);
        C0105e.m362b(it.Ku);
        C0105e.m362b(iv.Kz);
        C0105e.m362b(iv.KA);
    }

    public static MetadataField<?> aN(String str) {
        return (MetadataField) JO.get(str);
    }

    private static void m362b(MetadataField<?> metadataField) {
        if (JO.containsKey(metadataField.getName())) {
            throw new IllegalArgumentException("Duplicate field name registered: " + metadataField.getName());
        }
        JO.put(metadataField.getName(), metadataField);
    }

    public static Collection<MetadataField<?>> gz() {
        return Collections.unmodifiableCollection(JO.values());
    }
}
