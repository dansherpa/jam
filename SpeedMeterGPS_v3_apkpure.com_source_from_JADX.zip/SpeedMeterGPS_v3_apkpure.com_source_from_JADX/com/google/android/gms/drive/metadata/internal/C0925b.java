package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0524a;

/* renamed from: com.google.android.gms.drive.metadata.internal.b */
public class C0925b extends C0524a<Boolean> {
    public C0925b(String str, int i) {
        super(str, i);
    }

    protected void m3210a(Bundle bundle, Boolean bool) {
        bundle.putBoolean(getName(), bool.booleanValue());
    }

    protected /* synthetic */ Object m3212b(DataHolder dataHolder, int i, int i2) {
        return m3213d(dataHolder, i, i2);
    }

    protected Boolean m3213d(DataHolder dataHolder, int i, int i2) {
        return Boolean.valueOf(dataHolder.m2017d(getName(), i, i2));
    }

    protected /* synthetic */ Object m3214f(Bundle bundle) {
        return m3215g(bundle);
    }

    protected Boolean m3215g(Bundle bundle) {
        return Boolean.valueOf(bundle.getBoolean(getName()));
    }
}
