package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0524a;

/* renamed from: com.google.android.gms.drive.metadata.internal.f */
public class C0926f extends C0524a<Integer> {
    public C0926f(String str, int i) {
        super(str, i);
    }

    protected void m3216a(Bundle bundle, Integer num) {
        bundle.putInt(getName(), num.intValue());
    }

    protected /* synthetic */ Object m3218b(DataHolder dataHolder, int i, int i2) {
        return m3219f(dataHolder, i, i2);
    }

    protected Integer m3219f(DataHolder dataHolder, int i, int i2) {
        return Integer.valueOf(dataHolder.m2014b(getName(), i, i2));
    }

    protected /* synthetic */ Object m3220f(Bundle bundle) {
        return m3221i(bundle);
    }

    protected Integer m3221i(Bundle bundle) {
        return Integer.valueOf(bundle.getInt(getName()));
    }
}
