package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0524a;

/* renamed from: com.google.android.gms.drive.metadata.internal.g */
public class C0927g extends C0524a<Long> {
    public C0927g(String str, int i) {
        super(str, i);
    }

    protected void m3222a(Bundle bundle, Long l) {
        bundle.putLong(getName(), l.longValue());
    }

    protected /* synthetic */ Object m3224b(DataHolder dataHolder, int i, int i2) {
        return m3226g(dataHolder, i, i2);
    }

    protected /* synthetic */ Object m3225f(Bundle bundle) {
        return m3227j(bundle);
    }

    protected Long m3226g(DataHolder dataHolder, int i, int i2) {
        return Long.valueOf(dataHolder.m2012a(getName(), i, i2));
    }

    protected Long m3227j(Bundle bundle) {
        return Long.valueOf(bundle.getLong(getName()));
    }
}
