package com.google.android.gms.drive.metadata;

import com.google.android.gms.common.data.DataHolder;
import java.util.Collection;
import java.util.Collections;

/* renamed from: com.google.android.gms.drive.metadata.b */
public abstract class C0923b<T> extends C0524a<Collection<T>> {
    protected C0923b(String str, int i) {
        super(str, Collections.emptySet(), Collections.emptySet(), i);
    }

    protected /* synthetic */ Object m3208b(DataHolder dataHolder, int i, int i2) {
        return m3209c(dataHolder, i, i2);
    }

    protected Collection<T> m3209c(DataHolder dataHolder, int i, int i2) {
        throw new UnsupportedOperationException("Cannot read collections from a dataHolder.");
    }
}
