package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0924d;
import java.util.Date;

/* renamed from: com.google.android.gms.drive.metadata.internal.d */
public class C1073d extends C0924d<Date> {
    public C1073d(String str, int i) {
        super(str, i);
    }

    protected void m3910a(Bundle bundle, Date date) {
        bundle.putLong(getName(), date.getTime());
    }

    protected /* synthetic */ Object m3911b(DataHolder dataHolder, int i, int i2) {
        return m3912e(dataHolder, i, i2);
    }

    protected Date m3912e(DataHolder dataHolder, int i, int i2) {
        return new Date(dataHolder.m2012a(getName(), i, i2));
    }

    protected /* synthetic */ Object m3913f(Bundle bundle) {
        return m3914h(bundle);
    }

    protected Date m3914h(Bundle bundle) {
        return new Date(bundle.getLong(getName()));
    }
}
