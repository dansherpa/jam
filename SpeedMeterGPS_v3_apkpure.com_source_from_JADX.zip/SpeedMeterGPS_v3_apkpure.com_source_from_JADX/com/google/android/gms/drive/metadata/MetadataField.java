package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.Collection;

public interface MetadataField<T> {
    T m355a(DataHolder dataHolder, int i, int i2);

    void m356a(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2);

    void m357a(T t, Bundle bundle);

    T m358e(Bundle bundle);

    String getName();

    Collection<String> gx();
}
