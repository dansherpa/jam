package com.google.android.gms.drive.metadata.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.CustomPropertyKey;
import com.google.android.gms.internal.hn;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class AppVisibleCustomProperties implements SafeParcelable, Iterable<CustomProperty> {
    public static final Creator<AppVisibleCustomProperties> CREATOR;
    public static final AppVisibleCustomProperties JK;
    final List<CustomProperty> JL;
    final int xJ;

    /* renamed from: com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties.a */
    public static class C0102a {
        private final Map<CustomPropertyKey, CustomProperty> JM;

        public C0102a() {
            this.JM = new HashMap();
        }

        public AppVisibleCustomProperties gy() {
            return new AppVisibleCustomProperties(null);
        }
    }

    static {
        CREATOR = new C0103a();
        JK = new C0102a().gy();
    }

    AppVisibleCustomProperties(int versionCode, Collection<CustomProperty> properties) {
        this.xJ = versionCode;
        hn.m1230f(properties);
        this.JL = new ArrayList(properties);
    }

    private AppVisibleCustomProperties(Collection<CustomProperty> properties) {
        this(1, (Collection) properties);
    }

    public int describeContents() {
        return 0;
    }

    public Iterator<CustomProperty> iterator() {
        return this.JL.iterator();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0103a.m360a(this, dest, flags);
    }
}
