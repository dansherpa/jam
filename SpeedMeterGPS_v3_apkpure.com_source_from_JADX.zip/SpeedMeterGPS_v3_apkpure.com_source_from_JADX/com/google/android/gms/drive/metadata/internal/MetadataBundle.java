package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.hl;
import com.google.android.gms.internal.hn;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class MetadataBundle implements SafeParcelable {
    public static final Creator<MetadataBundle> CREATOR;
    final Bundle JP;
    final int xJ;

    static {
        CREATOR = new C0106h();
    }

    MetadataBundle(int versionCode, Bundle valueBundle) {
        this.xJ = versionCode;
        this.JP = (Bundle) hn.m1230f(valueBundle);
        this.JP.setClassLoader(getClass().getClassLoader());
        List<String> arrayList = new ArrayList();
        for (String str : this.JP.keySet()) {
            if (C0105e.aN(str) == null) {
                arrayList.add(str);
                Log.w("MetadataBundle", "Ignored unknown metadata field in bundle: " + str);
            }
        }
        for (String str2 : arrayList) {
            this.JP.remove(str2);
        }
    }

    private MetadataBundle(Bundle valueBundle) {
        this(1, valueBundle);
    }

    public static <T> MetadataBundle m2087a(MetadataField<T> metadataField, T t) {
        MetadataBundle gA = gA();
        gA.m2090b(metadataField, t);
        return gA;
    }

    public static MetadataBundle m2088a(MetadataBundle metadataBundle) {
        return new MetadataBundle(new Bundle(metadataBundle.JP));
    }

    public static MetadataBundle gA() {
        return new MetadataBundle(new Bundle());
    }

    public <T> T m2089a(MetadataField<T> metadataField) {
        return metadataField.m358e(this.JP);
    }

    public <T> void m2090b(MetadataField<T> metadataField, T t) {
        if (C0105e.aN(metadataField.getName()) == null) {
            throw new IllegalArgumentException("Unregistered field: " + metadataField.getName());
        }
        metadataField.m357a(t, this.JP);
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MetadataBundle)) {
            return false;
        }
        MetadataBundle metadataBundle = (MetadataBundle) obj;
        Set<String> keySet = this.JP.keySet();
        if (!keySet.equals(metadataBundle.JP.keySet())) {
            return false;
        }
        for (String str : keySet) {
            if (!hl.equal(this.JP.get(str), metadataBundle.JP.get(str))) {
                return false;
            }
        }
        return true;
    }

    public Set<MetadataField<?>> gB() {
        Set<MetadataField<?>> hashSet = new HashSet();
        for (String aN : this.JP.keySet()) {
            hashSet.add(C0105e.aN(aN));
        }
        return hashSet;
    }

    public int hashCode() {
        int i = 1;
        for (String str : this.JP.keySet()) {
            i *= 31;
            i = this.JP.get(str).hashCode() + i;
        }
        return i;
    }

    public String toString() {
        return "MetadataBundle [values=" + this.JP + "]";
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0106h.m363a(this, dest, flags);
    }
}
