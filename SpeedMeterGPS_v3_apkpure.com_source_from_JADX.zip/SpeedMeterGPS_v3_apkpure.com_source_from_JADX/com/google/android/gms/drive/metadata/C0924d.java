package com.google.android.gms.drive.metadata;

/* renamed from: com.google.android.gms.drive.metadata.d */
public abstract class C0924d<T extends Comparable<T>> extends C0524a<T> {
    protected C0924d(String str, int i) {
        super(str, i);
    }
}
