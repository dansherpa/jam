package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.drive.metadata.C0524a;
import java.util.Collection;

/* renamed from: com.google.android.gms.drive.metadata.internal.j */
public abstract class C0928j<T extends Parcelable> extends C0524a<T> {
    public C0928j(String str, Collection<String> collection, Collection<String> collection2, int i) {
        super(str, collection, collection2, i);
    }

    protected void m3228a(Bundle bundle, T t) {
        bundle.putParcelable(getName(), t);
    }

    protected /* synthetic */ Object m3230f(Bundle bundle) {
        return m3231l(bundle);
    }

    protected T m3231l(Bundle bundle) {
        return bundle.getParcelable(getName());
    }
}
