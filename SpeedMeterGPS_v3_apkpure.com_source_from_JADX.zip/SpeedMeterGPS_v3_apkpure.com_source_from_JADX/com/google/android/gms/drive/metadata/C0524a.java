package com.google.android.gms.drive.metadata;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.hn;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* renamed from: com.google.android.gms.drive.metadata.a */
public abstract class C0524a<T> implements MetadataField<T> {
    private final String JE;
    private final Set<String> JF;
    private final Set<String> JG;
    private final int JH;

    protected C0524a(String str, int i) {
        this.JE = (String) hn.m1226b((Object) str, (Object) "fieldName");
        this.JF = Collections.singleton(str);
        this.JG = Collections.emptySet();
        this.JH = i;
    }

    protected C0524a(String str, Collection<String> collection, Collection<String> collection2, int i) {
        this.JE = (String) hn.m1226b((Object) str, (Object) "fieldName");
        this.JF = Collections.unmodifiableSet(new HashSet(collection));
        this.JG = Collections.unmodifiableSet(new HashSet(collection2));
        this.JH = i;
    }

    public final T m2080a(DataHolder dataHolder, int i, int i2) {
        for (String h : this.JF) {
            if (dataHolder.m2021h(h, i, i2)) {
                return null;
            }
        }
        return m2084b(dataHolder, i, i2);
    }

    protected abstract void m2081a(Bundle bundle, T t);

    public final void m2082a(DataHolder dataHolder, MetadataBundle metadataBundle, int i, int i2) {
        hn.m1226b((Object) dataHolder, (Object) "dataHolder");
        hn.m1226b((Object) metadataBundle, (Object) "bundle");
        metadataBundle.m2090b(this, m2080a(dataHolder, i, i2));
    }

    public final void m2083a(T t, Bundle bundle) {
        hn.m1226b((Object) bundle, (Object) "bundle");
        if (t == null) {
            bundle.putString(getName(), null);
        } else {
            m2081a(bundle, (Object) t);
        }
    }

    protected abstract T m2084b(DataHolder dataHolder, int i, int i2);

    public final T m2085e(Bundle bundle) {
        hn.m1226b((Object) bundle, (Object) "bundle");
        return bundle.get(getName()) != null ? m2086f(bundle) : null;
    }

    protected abstract T m2086f(Bundle bundle);

    public final String getName() {
        return this.JE;
    }

    public final Collection<String> gx() {
        return this.JF;
    }

    public String toString() {
        return this.JE;
    }
}
