package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.C0524a;

/* renamed from: com.google.android.gms.drive.metadata.internal.l */
public class C0929l extends C0524a<String> {
    public C0929l(String str, int i) {
        super(str, i);
    }

    protected void m3233a(Bundle bundle, String str) {
        bundle.putString(getName(), str);
    }

    protected /* synthetic */ Object m3234b(DataHolder dataHolder, int i, int i2) {
        return m3236h(dataHolder, i, i2);
    }

    protected /* synthetic */ Object m3235f(Bundle bundle) {
        return m3237m(bundle);
    }

    protected String m3236h(DataHolder dataHolder, int i, int i2) {
        return dataHolder.m2016c(getName(), i, i2);
    }

    protected String m3237m(Bundle bundle) {
        return bundle.getString(getName());
    }
}
