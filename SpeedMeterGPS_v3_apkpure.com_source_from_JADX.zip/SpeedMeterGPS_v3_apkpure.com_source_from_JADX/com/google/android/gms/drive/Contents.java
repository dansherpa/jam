package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class Contents implements SafeParcelable {
    public static final Creator<Contents> CREATOR;
    final ParcelFileDescriptor Fg;
    private boolean HA;
    private boolean HB;
    final int Hv;
    final DriveId Hw;
    String Hx;
    boolean Hy;
    private boolean Hz;
    private boolean mClosed;
    final int qX;
    final int xJ;

    static {
        CREATOR = new C0074a();
    }

    Contents(int versionCode, ParcelFileDescriptor parcelFileDescriptor, int requestId, int mode, DriveId driveId, String baseContentHash, boolean validForConflictDetection) {
        this.mClosed = false;
        this.Hz = false;
        this.HA = false;
        this.HB = false;
        this.xJ = versionCode;
        this.Fg = parcelFileDescriptor;
        this.qX = requestId;
        this.Hv = mode;
        this.Hw = driveId;
        this.Hx = baseContentHash;
        this.Hy = validForConflictDetection;
    }

    public void close() {
        this.mClosed = true;
    }

    public int describeContents() {
        return 0;
    }

    public DriveId getDriveId() {
        return this.Hw;
    }

    public InputStream getInputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the input stream.");
        } else if (this.Hv != DriveFile.MODE_READ_ONLY) {
            throw new IllegalStateException("getInputStream() can only be used with contents opened with MODE_READ_ONLY.");
        } else if (this.Hz) {
            throw new IllegalStateException("getInputStream() can only be called once per Contents instance.");
        } else {
            this.Hz = true;
            return new FileInputStream(this.Fg.getFileDescriptor());
        }
    }

    public int getMode() {
        return this.Hv;
    }

    public OutputStream getOutputStream() {
        if (this.mClosed) {
            throw new IllegalStateException("Contents have been closed, cannot access the output stream.");
        } else if (this.Hv != DriveFile.MODE_WRITE_ONLY) {
            throw new IllegalStateException("getOutputStream() can only be used with contents opened with MODE_WRITE_ONLY.");
        } else if (this.HA) {
            throw new IllegalStateException("getOutputStream() can only be called once per Contents instance.");
        } else {
            this.HA = true;
            return new FileOutputStream(this.Fg.getFileDescriptor());
        }
    }

    public ParcelFileDescriptor getParcelFileDescriptor() {
        if (!this.mClosed) {
            return this.Fg;
        }
        throw new IllegalStateException("Contents have been closed, cannot access the output stream.");
    }

    public int getRequestId() {
        return this.qX;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0074a.m255a(this, dest, flags);
    }
}
