package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.a */
public class C0074a implements Creator<Contents> {
    static void m255a(Contents contents, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, contents.xJ);
        C0072b.m236a(parcel, 2, contents.Fg, i, false);
        C0072b.m252c(parcel, 3, contents.qX);
        C0072b.m252c(parcel, 4, contents.Hv);
        C0072b.m236a(parcel, 5, contents.Hw, i, false);
        C0072b.m240a(parcel, 6, contents.Hx, false);
        C0072b.m243a(parcel, 7, contents.Hy);
        C0072b.m228G(parcel, C);
    }

    public Contents m256M(Parcel parcel) {
        String str = null;
        boolean z = false;
        int B = C0071a.m189B(parcel);
        DriveId driveId = null;
        int i = 0;
        int i2 = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        int i3 = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i3 = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) C0071a.m194a(parcel, A, ParcelFileDescriptor.CREATOR);
                    break;
                case DetectedActivity.STILL /*3*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    driveId = (DriveId) C0071a.m194a(parcel, A, DriveId.CREATOR);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new Contents(i3, parcelFileDescriptor, i2, i, driveId, str, z);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public Contents[] aG(int i) {
        return new Contents[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m256M(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aG(x0);
    }
}
