package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class StorageStats implements SafeParcelable {
    public static final Creator<StorageStats> CREATOR;
    final long HY;
    final long HZ;
    final long Ia;
    final long Ib;
    final int Ic;
    final int xJ;

    static {
        CREATOR = new C0078e();
    }

    StorageStats(int versionCode, long metadataSizeBytes, long cachedContentsSizeBytes, long pinnedItemsSizeBytes, long totalSizeBytes, int numPinnedItems) {
        this.xJ = versionCode;
        this.HY = metadataSizeBytes;
        this.HZ = cachedContentsSizeBytes;
        this.Ia = pinnedItemsSizeBytes;
        this.Ib = totalSizeBytes;
        this.Ic = numPinnedItems;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0078e.m259a(this, out, flags);
    }
}
