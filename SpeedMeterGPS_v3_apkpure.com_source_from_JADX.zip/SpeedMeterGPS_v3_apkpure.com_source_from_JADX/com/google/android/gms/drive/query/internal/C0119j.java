package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.query.internal.j */
public class C0119j implements Creator<NotFilter> {
    static void m375a(NotFilter notFilter, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, notFilter.xJ);
        C0072b.m236a(parcel, 1, notFilter.KW, i, false);
        C0072b.m228G(parcel, C);
    }

    public NotFilter aN(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        FilterHolder filterHolder = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    filterHolder = (FilterHolder) C0071a.m194a(parcel, A, FilterHolder.CREATOR);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new NotFilter(i, filterHolder);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public NotFilter[] bJ(int i) {
        return new NotFilter[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aN(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bJ(x0);
    }
}
