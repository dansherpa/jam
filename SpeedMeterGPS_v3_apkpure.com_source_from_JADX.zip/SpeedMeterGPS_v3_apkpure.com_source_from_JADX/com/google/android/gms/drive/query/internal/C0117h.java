package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;
import java.util.ArrayList;
import java.util.List;

/* renamed from: com.google.android.gms.drive.query.internal.h */
public class C0117h implements Creator<LogicalFilter> {
    static void m373a(LogicalFilter logicalFilter, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, logicalFilter.xJ);
        C0072b.m236a(parcel, 1, logicalFilter.KI, i, false);
        C0072b.m251b(parcel, 2, logicalFilter.KV, false);
        C0072b.m228G(parcel, C);
    }

    public LogicalFilter aL(Parcel parcel) {
        List list = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        Operator operator = null;
        while (parcel.dataPosition() < B) {
            int i2;
            Operator operator2;
            ArrayList c;
            int A = C0071a.m187A(parcel);
            List list2;
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i2 = i;
                    Operator operator3 = (Operator) C0071a.m194a(parcel, A, Operator.CREATOR);
                    list2 = list;
                    operator2 = operator3;
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    c = C0071a.m200c(parcel, A, FilterHolder.CREATOR);
                    operator2 = operator;
                    i2 = i;
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    List list3 = list;
                    operator2 = operator;
                    i2 = C0071a.m205g(parcel, A);
                    list2 = list3;
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    c = list;
                    operator2 = operator;
                    i2 = i;
                    break;
            }
            i = i2;
            operator = operator2;
            Object obj = c;
        }
        if (parcel.dataPosition() == B) {
            return new LogicalFilter(i, operator, list);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public LogicalFilter[] bH(int i) {
        return new LogicalFilter[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aL(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bH(x0);
    }
}
