package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.query.Filter;

public class ComparisonFilter<T> implements SafeParcelable, Filter {
    public static final C0110a CREATOR;
    final Operator KI;
    final MetadataBundle KJ;
    final MetadataField<T> KK;
    final int xJ;

    static {
        CREATOR = new C0110a();
    }

    ComparisonFilter(int versionCode, Operator operator, MetadataBundle value) {
        this.xJ = versionCode;
        this.KI = operator;
        this.KJ = value;
        this.KK = C0114e.m370b(value);
    }

    public ComparisonFilter(Operator operator, SearchableMetadataField<T> field, T value) {
        this(1, operator, MetadataBundle.m2087a(field, value));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0110a.m366a(this, out, flags);
    }
}
