package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.C0923b;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.query.Filter;
import java.util.Collections;

public class InFilter<T> implements SafeParcelable, Filter {
    public static final C0116g CREATOR;
    final MetadataBundle KJ;
    private final C0923b<T> KU;
    final int xJ;

    static {
        CREATOR = new C0116g();
    }

    InFilter(int versionCode, MetadataBundle value) {
        this.xJ = versionCode;
        this.KJ = value;
        this.KU = (C0923b) C0114e.m370b(value);
    }

    public InFilter(SearchableCollectionMetadataField<T> field, T value) {
        this(1, MetadataBundle.m2087a(field, Collections.singleton(value)));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0116g.m372a(this, out, flags);
    }
}
