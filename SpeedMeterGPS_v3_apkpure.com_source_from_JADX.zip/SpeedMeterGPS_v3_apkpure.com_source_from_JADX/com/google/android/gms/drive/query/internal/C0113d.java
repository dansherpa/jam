package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.query.internal.d */
public class C0113d implements Creator<FilterHolder> {
    static void m369a(FilterHolder filterHolder, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m236a(parcel, 1, filterHolder.KM, i, false);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, filterHolder.xJ);
        C0072b.m236a(parcel, 2, filterHolder.KN, i, false);
        C0072b.m236a(parcel, 3, filterHolder.KO, i, false);
        C0072b.m236a(parcel, 4, filterHolder.KP, i, false);
        C0072b.m236a(parcel, 5, filterHolder.KQ, i, false);
        C0072b.m236a(parcel, 6, filterHolder.KR, i, false);
        C0072b.m236a(parcel, 7, filterHolder.KS, i, false);
        C0072b.m228G(parcel, C);
    }

    public FilterHolder aI(Parcel parcel) {
        HasFilter hasFilter = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        MatchAllFilter matchAllFilter = null;
        InFilter inFilter = null;
        NotFilter notFilter = null;
        LogicalFilter logicalFilter = null;
        FieldOnlyFilter fieldOnlyFilter = null;
        ComparisonFilter comparisonFilter = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    comparisonFilter = (ComparisonFilter) C0071a.m194a(parcel, A, ComparisonFilter.CREATOR);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    fieldOnlyFilter = (FieldOnlyFilter) C0071a.m194a(parcel, A, FieldOnlyFilter.CREATOR);
                    break;
                case DetectedActivity.STILL /*3*/:
                    logicalFilter = (LogicalFilter) C0071a.m194a(parcel, A, LogicalFilter.CREATOR);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    notFilter = (NotFilter) C0071a.m194a(parcel, A, NotFilter.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    inFilter = (InFilter) C0071a.m194a(parcel, A, InFilter.CREATOR);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    matchAllFilter = (MatchAllFilter) C0071a.m194a(parcel, A, MatchAllFilter.CREATOR);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    hasFilter = (HasFilter) C0071a.m194a(parcel, A, HasFilter.CREATOR);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new FilterHolder(i, comparisonFilter, fieldOnlyFilter, logicalFilter, notFilter, inFilter, matchAllFilter, hasFilter);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public FilterHolder[] bE(int i) {
        return new FilterHolder[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aI(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bE(x0);
    }
}
