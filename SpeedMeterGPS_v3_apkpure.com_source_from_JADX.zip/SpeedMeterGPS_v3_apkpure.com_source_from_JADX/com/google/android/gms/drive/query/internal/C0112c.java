package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.query.internal.c */
public class C0112c implements Creator<FieldWithSortOrder> {
    static void m368a(FieldWithSortOrder fieldWithSortOrder, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, fieldWithSortOrder.xJ);
        C0072b.m240a(parcel, 1, fieldWithSortOrder.JE, false);
        C0072b.m243a(parcel, 2, fieldWithSortOrder.KL);
        C0072b.m228G(parcel, C);
    }

    public FieldWithSortOrder aH(Parcel parcel) {
        boolean z = false;
        int B = C0071a.m189B(parcel);
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new FieldWithSortOrder(i, str, z);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public FieldWithSortOrder[] bD(int i) {
        return new FieldWithSortOrder[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aH(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bD(x0);
    }
}
