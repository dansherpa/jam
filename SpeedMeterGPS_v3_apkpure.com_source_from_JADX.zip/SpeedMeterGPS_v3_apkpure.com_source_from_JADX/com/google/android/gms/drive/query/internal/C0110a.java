package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.query.internal.a */
public class C0110a implements Creator<ComparisonFilter> {
    static void m366a(ComparisonFilter comparisonFilter, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, comparisonFilter.xJ);
        C0072b.m236a(parcel, 1, comparisonFilter.KI, i, false);
        C0072b.m236a(parcel, 2, comparisonFilter.KJ, i, false);
        C0072b.m228G(parcel, C);
    }

    public ComparisonFilter aF(Parcel parcel) {
        MetadataBundle metadataBundle = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        Operator operator = null;
        while (parcel.dataPosition() < B) {
            int i2;
            MetadataBundle metadataBundle2;
            Operator operator2;
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i2 = i;
                    Operator operator3 = (Operator) C0071a.m194a(parcel, A, Operator.CREATOR);
                    metadataBundle2 = metadataBundle;
                    operator2 = operator3;
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    metadataBundle2 = (MetadataBundle) C0071a.m194a(parcel, A, MetadataBundle.CREATOR);
                    operator2 = operator;
                    i2 = i;
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    MetadataBundle metadataBundle3 = metadataBundle;
                    operator2 = operator;
                    i2 = C0071a.m205g(parcel, A);
                    metadataBundle2 = metadataBundle3;
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    metadataBundle2 = metadataBundle;
                    operator2 = operator;
                    i2 = i;
                    break;
            }
            i = i2;
            operator = operator2;
            metadataBundle = metadataBundle2;
        }
        if (parcel.dataPosition() == B) {
            return new ComparisonFilter(i, operator, metadataBundle);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public ComparisonFilter[] bB(int i) {
        return new ComparisonFilter[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aF(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bB(x0);
    }
}
