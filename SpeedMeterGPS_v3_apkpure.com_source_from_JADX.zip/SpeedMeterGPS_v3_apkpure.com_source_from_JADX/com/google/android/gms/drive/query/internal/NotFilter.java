package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.query.Filter;

public class NotFilter implements SafeParcelable, Filter {
    public static final Creator<NotFilter> CREATOR;
    final FilterHolder KW;
    final int xJ;

    static {
        CREATOR = new C0119j();
    }

    NotFilter(int versionCode, FilterHolder toNegate) {
        this.xJ = versionCode;
        this.KW = toNegate;
    }

    public NotFilter(Filter toNegate) {
        this(1, new FilterHolder(toNegate));
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0119j.m375a(this, out, flags);
    }
}
