package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.query.Filter;

public class HasFilter<T> implements SafeParcelable, Filter {
    public static final C0115f CREATOR;
    final MetadataBundle KJ;
    final MetadataField<T> KK;
    final int xJ;

    static {
        CREATOR = new C0115f();
    }

    HasFilter(int versionCode, MetadataBundle value) {
        this.xJ = versionCode;
        this.KJ = value;
        this.KK = C0114e.m370b(value);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0115f.m371a(this, out, flags);
    }
}
