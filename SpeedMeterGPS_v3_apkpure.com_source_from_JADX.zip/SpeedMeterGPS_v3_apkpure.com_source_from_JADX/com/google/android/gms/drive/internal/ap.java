package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.drive.StorageStats;
import com.google.android.gms.wearable.DataEvent;

public class ap implements Creator<OnStorageStatsResponse> {
    static void m322a(OnStorageStatsResponse onStorageStatsResponse, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, onStorageStatsResponse.xJ);
        C0072b.m236a(parcel, 2, onStorageStatsResponse.JA, i, false);
        C0072b.m228G(parcel, C);
    }

    public OnStorageStatsResponse aq(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        StorageStats storageStats = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    storageStats = (StorageStats) C0071a.m194a(parcel, A, StorageStats.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new OnStorageStatsResponse(i, storageStats);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public OnStorageStatsResponse[] bm(int i) {
        return new OnStorageStatsResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aq(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bm(x0);
    }
}
