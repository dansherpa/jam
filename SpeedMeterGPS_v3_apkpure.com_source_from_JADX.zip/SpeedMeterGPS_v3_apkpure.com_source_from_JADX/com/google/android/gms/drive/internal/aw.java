package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.Status;

public class aw extends C0911c {
    private final C0052d<Status> yO;

    public aw(C0052d<Status> c0052d) {
        this.yO = c0052d;
    }

    public void m3890o(Status status) throws RemoteException {
        this.yO.m147a(status);
    }

    public void onSuccess() throws RemoteException {
        this.yO.m147a(Status.Ek);
    }
}
