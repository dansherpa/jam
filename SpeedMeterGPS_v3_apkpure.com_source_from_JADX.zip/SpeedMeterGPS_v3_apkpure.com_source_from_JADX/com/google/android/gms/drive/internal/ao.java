package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.wearable.DataEvent;
import java.util.List;

public class ao implements Creator<OnResourceIdSetResponse> {
    static void m321a(OnResourceIdSetResponse onResourceIdSetResponse, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, onResourceIdSetResponse.getVersionCode());
        C0072b.m241a(parcel, 2, onResourceIdSetResponse.gj(), false);
        C0072b.m228G(parcel, C);
    }

    public OnResourceIdSetResponse ap(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    list = C0071a.m190B(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new OnResourceIdSetResponse(i, list);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public OnResourceIdSetResponse[] bl(int i) {
        return new OnResourceIdSetResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ap(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bl(x0);
    }
}
