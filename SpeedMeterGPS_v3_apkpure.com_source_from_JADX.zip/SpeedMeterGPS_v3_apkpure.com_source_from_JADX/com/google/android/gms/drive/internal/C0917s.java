package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFile.DownloadProgressListener;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.internal.C0520p.C0913a;

/* renamed from: com.google.android.gms.drive.internal.s */
public class C0917s extends C0522v implements DriveFile {

    /* renamed from: com.google.android.gms.drive.internal.s.c */
    private static class C1068c extends C0911c {
        private final DownloadProgressListener Jb;
        private final C0052d<ContentsResult> yO;

        public C1068c(C0052d<ContentsResult> c0052d, DownloadProgressListener downloadProgressListener) {
            this.yO = c0052d;
            this.Jb = downloadProgressListener;
        }

        public void m3898a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.yO.m147a(new C0913a(Status.Ek, onContentsResponse.go()));
        }

        public void m3899a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
            if (this.Jb != null) {
                this.Jb.onProgress(onDownloadProgressResponse.gp(), onDownloadProgressResponse.gq());
            }
        }

        public void m3900o(Status status) throws RemoteException {
            this.yO.m147a(new C0913a(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.a */
    private abstract class C1126a extends C1067q<Status> {
        final /* synthetic */ C0917s IZ;

        private C1126a(C0917s c0917s) {
            this.IZ = c0917s;
        }

        public /* synthetic */ Result m4119c(Status status) {
            return m4120d(status);
        }

        public Status m4120d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.b */
    private abstract class C1127b extends C1067q<Status> {
        final /* synthetic */ C0917s IZ;

        private C1127b(C0917s c0917s) {
            this.IZ = c0917s;
        }

        public /* synthetic */ Result m4121c(Status status) {
            return m4122d(status);
        }

        public Status m4122d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.d */
    private abstract class C1128d extends C1067q<ContentsResult> {
        final /* synthetic */ C0917s IZ;

        private C1128d(C0917s c0917s) {
            this.IZ = c0917s;
        }

        public /* synthetic */ Result m4123c(Status status) {
            return m4124q(status);
        }

        public ContentsResult m4124q(Status status) {
            return new C0913a(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.1 */
    class C12061 extends C1128d {
        final /* synthetic */ int IX;
        final /* synthetic */ DownloadProgressListener IY;
        final /* synthetic */ C0917s IZ;

        C12061(C0917s c0917s, int i, DownloadProgressListener downloadProgressListener) {
            this.IZ = c0917s;
            this.IX = i;
            this.IY = downloadProgressListener;
            super(null);
        }

        protected void m4378a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m287a(new OpenContentsRequest(this.IZ.getDriveId(), this.IX), new C1068c(this, this.IY));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.2 */
    class C12072 extends C1127b {
        final /* synthetic */ Contents IJ;
        final /* synthetic */ C0917s IZ;

        C12072(C0917s c0917s, Contents contents) {
            this.IZ = c0917s;
            this.IJ = contents;
            super(null);
        }

        protected void m4380a(C0916r c0916r) throws RemoteException {
            this.IJ.close();
            c0916r.gk().m276a(new CloseContentsRequest(this.IJ, true), new aw(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.s.3 */
    class C12083 extends C1126a {
        final /* synthetic */ Contents IJ;
        final /* synthetic */ C0917s IZ;
        final /* synthetic */ MetadataChangeSet Ja;

        C12083(C0917s c0917s, Contents contents, MetadataChangeSet metadataChangeSet) {
            this.IZ = c0917s;
            this.IJ = contents;
            this.Ja = metadataChangeSet;
            super(null);
        }

        protected void m4382a(C0916r c0916r) throws RemoteException {
            this.IJ.close();
            c0916r.gk().m275a(new CloseContentsAndUpdateMetadataRequest(this.IZ.Hw, this.Ja.gh(), this.IJ, false, null), new aw(this));
        }
    }

    public C0917s(DriveId driveId) {
        super(driveId);
    }

    public PendingResult<Status> commitAndCloseContents(GoogleApiClient apiClient, Contents contents) {
        if (contents != null) {
            return apiClient.m140b(new C12072(this, contents));
        }
        throw new IllegalArgumentException("Contents must be provided.");
    }

    public PendingResult<Status> commitAndCloseContents(GoogleApiClient apiClient, Contents contents, MetadataChangeSet changeSet) {
        if (contents != null) {
            return apiClient.m140b(new C12083(this, contents, changeSet));
        }
        throw new IllegalArgumentException("Contents must be provided.");
    }

    public PendingResult<Status> discardContents(GoogleApiClient apiClient, Contents contents) {
        return Drive.DriveApi.discardContents(apiClient, contents);
    }

    public PendingResult<ContentsResult> openContents(GoogleApiClient apiClient, int mode, DownloadProgressListener listener) {
        if (mode == DriveFile.MODE_READ_ONLY || mode == DriveFile.MODE_WRITE_ONLY || mode == DriveFile.MODE_READ_WRITE) {
            return apiClient.m139a(new C12061(this, mode, listener));
        }
        throw new IllegalArgumentException("Invalid mode provided.");
    }
}
