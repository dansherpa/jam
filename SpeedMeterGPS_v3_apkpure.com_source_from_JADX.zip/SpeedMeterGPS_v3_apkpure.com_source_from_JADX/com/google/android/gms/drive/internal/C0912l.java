package com.google.android.gms.drive.internal;

import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

/* renamed from: com.google.android.gms.drive.internal.l */
public final class C0912l extends Metadata {
    private final MetadataBundle IF;

    public C0912l(MetadataBundle metadataBundle) {
        this.IF = metadataBundle;
    }

    protected <T> T m3198a(MetadataField<T> metadataField) {
        return this.IF.m2089a((MetadataField) metadataField);
    }

    public /* synthetic */ Object freeze() {
        return gg();
    }

    public Metadata gg() {
        return new C0912l(MetadataBundle.m2088a(this.IF));
    }

    public boolean isDataValid() {
        return this.IF != null;
    }

    public String toString() {
        return "Metadata [mImpl=" + this.IF + "]";
    }
}
