package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnListEntriesResponse implements SafeParcelable {
    public static final Creator<OnListEntriesResponse> CREATOR;
    final boolean IM;
    final DataHolder Jx;
    final int xJ;

    static {
        CREATOR = new ak();
    }

    OnListEntriesResponse(int versionCode, DataHolder entries, boolean moreEntriesMayExist) {
        this.xJ = versionCode;
        this.Jx = entries;
        this.IM = moreEntriesMayExist;
    }

    public int describeContents() {
        return 0;
    }

    public DataHolder gt() {
        return this.Jx;
    }

    public boolean gu() {
        return this.IM;
    }

    public void writeToParcel(Parcel dest, int flags) {
        ak.m317a(this, dest, flags);
    }
}
