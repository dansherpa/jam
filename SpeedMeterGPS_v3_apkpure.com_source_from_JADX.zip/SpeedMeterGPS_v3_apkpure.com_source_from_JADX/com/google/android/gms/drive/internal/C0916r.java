package com.google.android.gms.drive.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.C0081b;
import com.google.android.gms.drive.events.DriveEvent;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.C0520p.C1124j;
import com.google.android.gms.drive.internal.C0520p.C1203k;
import com.google.android.gms.drive.internal.aa.C0515a;
import com.google.android.gms.internal.gz;
import com.google.android.gms.internal.hc;
import com.google.android.gms.internal.hc.C0993e;
import com.google.android.gms.internal.hi;
import com.google.android.gms.internal.hj;
import com.google.android.gms.internal.hn;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.internal.r */
public class C0916r extends hc<aa> {
    private final String IN;
    private final Bundle IO;
    private DriveId IP;
    private DriveId IQ;
    final ConnectionCallbacks IR;
    Map<DriveId, Map<Listener<?>, C0922x<?>>> IS;
    private final String yN;

    /* renamed from: com.google.android.gms.drive.internal.r.1 */
    class C12041 extends C1124j {
        final /* synthetic */ DriveId IT;
        final /* synthetic */ int IU;
        final /* synthetic */ C0922x IV;
        final /* synthetic */ C0916r IW;

        C12041(C0916r c0916r, DriveId driveId, int i, C0922x c0922x) {
            this.IW = c0916r;
            this.IT = driveId;
            this.IU = i;
            this.IV = c0922x;
        }

        protected void m4374a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m272a(new AddEventListenerRequest(this.IT, this.IU, null), this.IV, null, new aw(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.2 */
    class C12052 extends C1124j {
        final /* synthetic */ DriveId IT;
        final /* synthetic */ int IU;
        final /* synthetic */ C0922x IV;
        final /* synthetic */ C0916r IW;

        C12052(C0916r c0916r, DriveId driveId, int i, C0922x c0922x) {
            this.IW = c0916r;
            this.IT = driveId;
            this.IU = i;
            this.IV = c0922x;
        }

        protected void m4376a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m289a(new RemoveEventListenerRequest(this.IT, this.IU), this.IV, null, new aw(this));
        }
    }

    public C0916r(Context context, Looper looper, gz gzVar, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String[] strArr, Bundle bundle) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.IS = new HashMap();
        this.yN = (String) hn.m1226b(gzVar.fe(), (Object) "Must call Api.ClientBuilder.setAccountName()");
        this.IN = gzVar.fi();
        this.IR = connectionCallbacks;
        this.IO = bundle;
    }

    protected aa m3199O(IBinder iBinder) {
        return C0515a.m2065P(iBinder);
    }

    <C extends DriveEvent> PendingResult<Status> m3200a(GoogleApiClient googleApiClient, DriveId driveId, int i, Listener<C> listener) {
        PendingResult<Status> c1203k;
        hn.m1228b(C0081b.m265a(i, driveId), (Object) "id");
        hn.m1226b((Object) listener, (Object) "listener");
        hn.m1224a(isConnected(), "Client must be connected");
        synchronized (this.IS) {
            Map map = (Map) this.IS.get(driveId);
            if (map == null) {
                map = new HashMap();
                this.IS.put(driveId, map);
            }
            if (map.containsKey(listener)) {
                c1203k = new C1203k(googleApiClient, Status.Ek);
            } else {
                C0922x c0922x = new C0922x(getLooper(), i, listener);
                map.put(listener, c0922x);
                c1203k = googleApiClient.m140b(new C12041(this, driveId, i, c0922x));
            }
        }
        return c1203k;
    }

    protected void m3201a(int i, IBinder iBinder, Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(getClass().getClassLoader());
            this.IP = (DriveId) bundle.getParcelable("com.google.android.gms.drive.root_id");
            this.IQ = (DriveId) bundle.getParcelable("com.google.android.gms.drive.appdata_id");
        }
        super.m2652a(i, iBinder, bundle);
    }

    protected void m3202a(hj hjVar, C0993e c0993e) throws RemoteException {
        String packageName = getContext().getPackageName();
        hn.m1230f(c0993e);
        hn.m1230f(packageName);
        hn.m1230f(fn());
        Bundle bundle = new Bundle();
        bundle.putString("proxy_package_name", this.IN);
        bundle.putAll(this.IO);
        hjVar.m1192a((hi) c0993e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, packageName, fn(), this.yN, bundle);
    }

    PendingResult<Status> m3203b(GoogleApiClient googleApiClient, DriveId driveId, int i, Listener<?> listener) {
        PendingResult<Status> c1203k;
        hn.m1228b(C0081b.m265a(i, driveId), (Object) "id");
        hn.m1224a(isConnected(), "Client must be connected");
        hn.m1226b((Object) listener, (Object) "listener");
        synchronized (this.IS) {
            Map map = (Map) this.IS.get(driveId);
            if (map == null) {
                c1203k = new C1203k(googleApiClient, Status.Ek);
            } else {
                C0922x c0922x = (C0922x) map.remove(listener);
                if (c0922x == null) {
                    c1203k = new C1203k(googleApiClient, Status.Ek);
                } else {
                    if (map.isEmpty()) {
                        this.IS.remove(driveId);
                    }
                    c1203k = googleApiClient.m140b(new C12052(this, driveId, i, c0922x));
                }
            }
        }
        return c1203k;
    }

    protected String bp() {
        return "com.google.android.gms.drive.ApiService.START";
    }

    protected String bq() {
        return "com.google.android.gms.drive.internal.IDriveService";
    }

    public void disconnect() {
        aa aaVar = (aa) fo();
        if (aaVar != null) {
            try {
                aaVar.m282a(new DisconnectRequest());
            } catch (RemoteException e) {
            }
        }
        super.disconnect();
        this.IS.clear();
    }

    public aa gk() {
        return (aa) fo();
    }

    public DriveId gl() {
        return this.IP;
    }

    public DriveId gm() {
        return this.IQ;
    }

    protected /* synthetic */ IInterface m3204x(IBinder iBinder) {
        return m3199O(iBinder);
    }
}
