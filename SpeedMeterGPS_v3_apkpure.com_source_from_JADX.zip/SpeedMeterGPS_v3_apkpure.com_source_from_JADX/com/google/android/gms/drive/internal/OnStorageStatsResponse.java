package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.StorageStats;

public class OnStorageStatsResponse implements SafeParcelable {
    public static final Creator<OnStorageStatsResponse> CREATOR;
    StorageStats JA;
    final int xJ;

    static {
        CREATOR = new ap();
    }

    OnStorageStatsResponse(int versionCode, StorageStats storageStats) {
        this.xJ = versionCode;
        this.JA = storageStats;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        ap.m322a(this, dest, flags);
    }
}
