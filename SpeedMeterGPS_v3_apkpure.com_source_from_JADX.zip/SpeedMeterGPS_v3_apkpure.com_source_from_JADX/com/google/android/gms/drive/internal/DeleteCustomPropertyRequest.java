package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.CustomPropertyKey;

public class DeleteCustomPropertyRequest implements SafeParcelable {
    public static final Creator<DeleteCustomPropertyRequest> CREATOR;
    final DriveId Hw;
    final CustomPropertyKey IG;
    final int xJ;

    static {
        CREATOR = new C0093m();
    }

    DeleteCustomPropertyRequest(int versionCode, DriveId driveId, CustomPropertyKey propertyKey) {
        this.xJ = versionCode;
        this.Hw = driveId;
        this.IG = propertyKey;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0093m.m349a(this, dest, flags);
    }
}
