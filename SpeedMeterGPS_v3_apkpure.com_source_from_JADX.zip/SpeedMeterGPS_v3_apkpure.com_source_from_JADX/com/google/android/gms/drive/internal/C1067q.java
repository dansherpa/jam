package com.google.android.gms.drive.internal;

import com.google.android.gms.common.api.C0053a.C0903b;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.drive.Drive;

/* renamed from: com.google.android.gms.drive.internal.q */
abstract class C1067q<R extends Result> extends C0903b<R, C0916r> {
    public C1067q() {
        super(Drive.yE);
    }
}
