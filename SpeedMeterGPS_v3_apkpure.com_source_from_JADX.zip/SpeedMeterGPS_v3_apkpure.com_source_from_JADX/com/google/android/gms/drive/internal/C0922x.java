package com.google.android.gms.drive.internal;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.drive.events.DriveEvent;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.ac.C0519a;
import com.google.android.gms.internal.hn;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.internal.x */
public class C0922x<C extends DriveEvent> extends C0519a {
    private final int In;
    private final Listener<C> Jk;
    private final C0097a<C> Jl;

    /* renamed from: com.google.android.gms.drive.internal.x.a */
    private static class C0097a<E extends DriveEvent> extends Handler {
        private C0097a(Looper looper) {
            super(looper);
        }

        public void m352a(Listener<E> listener, E e) {
            sendMessage(obtainMessage(1, new Pair(listener, e)));
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    Pair pair = (Pair) msg.obj;
                    ((Listener) pair.first).onEvent((DriveEvent) pair.second);
                default:
                    Log.wtf("EventCallback", "Don't know how to handle this event");
            }
        }
    }

    public C0922x(Looper looper, int i, Listener<C> listener) {
        this.In = i;
        this.Jk = listener;
        this.Jl = new C0097a(null);
    }

    public void m3207a(OnEventResponse onEventResponse) throws RemoteException {
        hn.m1222A(this.In == onEventResponse.getEventType());
        switch (onEventResponse.getEventType()) {
            case DataEvent.TYPE_CHANGED /*1*/:
                this.Jl.m352a(this.Jk, onEventResponse.gr());
            case DataEvent.TYPE_DELETED /*2*/:
                this.Jl.m352a(this.Jk, onEventResponse.gs());
            default:
                Log.w("EventCallback", "Unexpected event type:" + onEventResponse.getEventType());
        }
    }
}
