package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class OnMetadataResponse implements SafeParcelable {
    public static final Creator<OnMetadataResponse> CREATOR;
    final MetadataBundle IA;
    final int xJ;

    static {
        CREATOR = new am();
    }

    OnMetadataResponse(int versionCode, MetadataBundle metadata) {
        this.xJ = versionCode;
        this.IA = metadata;
    }

    public int describeContents() {
        return 0;
    }

    public MetadataBundle gw() {
        return this.IA;
    }

    public void writeToParcel(Parcel dest, int flags) {
        am.m319a(this, dest, flags);
    }
}
