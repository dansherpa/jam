package com.google.android.gms.drive.internal;

import com.google.ads.AdSize;
import com.google.android.gms.internal.lz;
import com.google.android.gms.internal.ma;
import com.google.android.gms.internal.mb;
import com.google.android.gms.internal.me;
import com.google.android.gms.internal.mf;
import com.google.android.gms.location.DetectedActivity;
import java.io.IOException;

public final class af extends mb<af> {
    public String Jq;
    public long Jr;
    public long Js;
    public int versionCode;

    public af() {
        gn();
    }

    public static af m3182g(byte[] bArr) throws me {
        return (af) mf.m1419a(new af(), bArr);
    }

    public void m3183a(ma maVar) throws IOException {
        maVar.m1410p(1, this.versionCode);
        maVar.m1404b(2, this.Jq);
        maVar.m1406c(3, this.Jr);
        maVar.m1406c(4, this.Js);
        super.m2814a(maVar);
    }

    public /* synthetic */ mf m3184b(lz lzVar) throws IOException {
        return m3186m(lzVar);
    }

    protected int m3185c() {
        return (((super.m2816c() + ma.m1389r(1, this.versionCode)) + ma.m1387h(2, this.Jq)) + ma.m1385e(3, this.Jr)) + ma.m1385e(4, this.Js);
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof af)) {
            return false;
        }
        af afVar = (af) o;
        if (this.versionCode != afVar.versionCode) {
            return false;
        }
        if (this.Jq == null) {
            if (afVar.Jq != null) {
                return false;
            }
        } else if (!this.Jq.equals(afVar.Jq)) {
            return false;
        }
        if (this.Jr != afVar.Jr || this.Js != afVar.Js) {
            return false;
        }
        if (this.amU == null || this.amU.isEmpty()) {
            return afVar.amU == null || afVar.amU.isEmpty();
        } else {
            return this.amU.equals(afVar.amU);
        }
    }

    public af gn() {
        this.versionCode = 1;
        this.Jq = "";
        this.Jr = -1;
        this.Js = -1;
        this.amU = null;
        this.amY = -1;
        return this;
    }

    public int hashCode() {
        int i = 0;
        int hashCode = ((((((this.Jq == null ? 0 : this.Jq.hashCode()) + ((this.versionCode + 527) * 31)) * 31) + ((int) (this.Jr ^ (this.Jr >>> 32)))) * 31) + ((int) (this.Js ^ (this.Js >>> 32)))) * 31;
        if (!(this.amU == null || this.amU.isEmpty())) {
            i = this.amU.hashCode();
        }
        return hashCode + i;
    }

    public af m3186m(lz lzVar) throws IOException {
        while (true) {
            int nw = lzVar.nw();
            switch (nw) {
                case DetectedActivity.IN_VEHICLE /*0*/:
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    this.versionCode = lzVar.nz();
                    continue;
                case 18:
                    this.Jq = lzVar.readString();
                    continue;
                case 24:
                    this.Jr = lzVar.nC();
                    continue;
                case AdSize.LANDSCAPE_AD_HEIGHT /*32*/:
                    this.Js = lzVar.nC();
                    continue;
                default:
                    if (!m2815a(lzVar, nw)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }
}
