package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveFolder.DriveFileResult;
import com.google.android.gms.drive.DriveFolder.DriveFolderResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.query.Filters;
import com.google.android.gms.drive.query.Query;
import com.google.android.gms.drive.query.Query.Builder;
import com.google.android.gms.drive.query.SearchableField;

/* renamed from: com.google.android.gms.drive.internal.u */
public class C0920u extends C0522v implements DriveFolder {

    /* renamed from: com.google.android.gms.drive.internal.u.d */
    private static class C0918d implements DriveFileResult {
        private final DriveFile Jg;
        private final Status yw;

        public C0918d(Status status, DriveFile driveFile) {
            this.yw = status;
            this.Jg = driveFile;
        }

        public DriveFile getDriveFile() {
            return this.Jg;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.e */
    private static class C0919e implements DriveFolderResult {
        private final DriveFolder Jh;
        private final Status yw;

        public C0919e(Status status, DriveFolder driveFolder) {
            this.yw = status;
            this.Jh = driveFolder;
        }

        public DriveFolder getDriveFolder() {
            return this.Jh;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.a */
    private static class C1069a extends C0911c {
        private final C0052d<DriveFileResult> yO;

        public C1069a(C0052d<DriveFileResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3901a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.yO.m147a(new C0918d(Status.Ek, new C0917s(onDriveIdResponse.getDriveId())));
        }

        public void m3902o(Status status) throws RemoteException {
            this.yO.m147a(new C0918d(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.b */
    private static class C1070b extends C0911c {
        private final C0052d<DriveFolderResult> yO;

        public C1070b(C0052d<DriveFolderResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3903a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.yO.m147a(new C0919e(Status.Ek, new C0920u(onDriveIdResponse.getDriveId())));
        }

        public void m3904o(Status status) throws RemoteException {
            this.yO.m147a(new C0919e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.1 */
    class C11291 extends C1067q<DriveFileResult> {
        final /* synthetic */ Contents IJ;
        final /* synthetic */ MetadataChangeSet Ja;
        final /* synthetic */ int Jc;
        final /* synthetic */ boolean Jd;
        final /* synthetic */ String Je;
        final /* synthetic */ C0920u Jf;

        C11291(C0920u c0920u, Contents contents, MetadataChangeSet metadataChangeSet, int i, boolean z, String str) {
            this.Jf = c0920u;
            this.IJ = contents;
            this.Ja = metadataChangeSet;
            this.Jc = i;
            this.Jd = z;
            this.Je = str;
        }

        protected void m4126a(C0916r c0916r) throws RemoteException {
            if (this.IJ != null) {
                this.IJ.close();
            }
            c0916r.gk().m278a(new CreateFileRequest(this.Jf.getDriveId(), this.Ja.gh(), this.IJ, this.Jc, this.Jd, this.Je), new C1069a(this));
        }

        public /* synthetic */ Result m4127c(Status status) {
            return m4128s(status);
        }

        public DriveFileResult m4128s(Status status) {
            return new C0918d(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.c */
    private abstract class C1130c extends C1067q<DriveFolderResult> {
        final /* synthetic */ C0920u Jf;

        private C1130c(C0920u c0920u) {
            this.Jf = c0920u;
        }

        public /* synthetic */ Result m4129c(Status status) {
            return m4130t(status);
        }

        public DriveFolderResult m4130t(Status status) {
            return new C0919e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.u.2 */
    class C12092 extends C1130c {
        final /* synthetic */ MetadataChangeSet Ja;
        final /* synthetic */ C0920u Jf;

        C12092(C0920u c0920u, MetadataChangeSet metadataChangeSet) {
            this.Jf = c0920u;
            this.Ja = metadataChangeSet;
            super(null);
        }

        protected void m4384a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m279a(new CreateFolderRequest(this.Jf.getDriveId(), this.Ja.gh()), new C1070b(this));
        }
    }

    public C0920u(DriveId driveId) {
        super(driveId);
    }

    private PendingResult<DriveFileResult> m3205a(GoogleApiClient googleApiClient, MetadataChangeSet metadataChangeSet, Contents contents, int i, boolean z, String str) {
        return googleApiClient.m140b(new C11291(this, contents, metadataChangeSet, i, z, str));
    }

    private PendingResult<DriveFileResult> m3206a(GoogleApiClient googleApiClient, MetadataChangeSet metadataChangeSet, Contents contents, boolean z, String str) {
        if (metadataChangeSet == null) {
            throw new IllegalArgumentException("MetadataChangeSet must be provided.");
        } else if (contents == null) {
            throw new IllegalArgumentException("Contents must be provided.");
        } else if (!DriveFolder.MIME_TYPE.equals(metadataChangeSet.getMimeType())) {
            return m3205a(googleApiClient, metadataChangeSet, contents, 0, z, str);
        } else {
            throw new IllegalArgumentException("May not create folders (mimetype: application/vnd.google-apps.folder) using this method. Use DriveFolder.createFolder() instead.");
        }
    }

    public PendingResult<DriveFileResult> createFile(GoogleApiClient apiClient, MetadataChangeSet changeSet, Contents contents) {
        return m3206a(apiClient, changeSet, contents, false, null);
    }

    public PendingResult<DriveFolderResult> createFolder(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        if (changeSet == null) {
            throw new IllegalArgumentException("MetadataChangeSet must be provided.");
        } else if (changeSet.getMimeType() == null || changeSet.getMimeType().equals(DriveFolder.MIME_TYPE)) {
            return apiClient.m140b(new C12092(this, changeSet));
        } else {
            throw new IllegalArgumentException("The mimetype must be of type application/vnd.google-apps.folder");
        }
    }

    public PendingResult<MetadataBufferResult> listChildren(GoogleApiClient apiClient) {
        return queryChildren(apiClient, null);
    }

    public PendingResult<MetadataBufferResult> queryChildren(GoogleApiClient apiClient, Query query) {
        Builder addFilter = new Builder().addFilter(Filters.in(SearchableField.PARENTS, getDriveId()));
        if (query != null) {
            if (query.getFilter() != null) {
                addFilter.addFilter(query.getFilter());
            }
            addFilter.setPageToken(query.getPageToken());
            addFilter.setSortOrder(query.getSortOrder());
        }
        return new C0520p().query(apiClient, addFilter.build());
    }
}
