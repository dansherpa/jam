package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0051c;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.CreateFileActivityBuilder;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveApi.DriveIdResult;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.drive.query.Query;

/* renamed from: com.google.android.gms.drive.internal.p */
public class C0520p implements DriveApi {

    /* renamed from: com.google.android.gms.drive.internal.p.a */
    public static class C0913a implements ContentsResult {
        private final Contents HD;
        private final Status yw;

        public C0913a(Status status, Contents contents) {
            this.yw = status;
            this.HD = contents;
        }

        public Contents getContents() {
            return this.HD;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.c */
    static class C0914c implements DriveIdResult {
        private final DriveId Hw;
        private final Status yw;

        public C0914c(Status status, DriveId driveId) {
            this.yw = status;
            this.Hw = driveId;
        }

        public DriveId getDriveId() {
            return this.Hw;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.e */
    static class C0915e implements MetadataBufferResult {
        private final MetadataBuffer IL;
        private final boolean IM;
        private final Status yw;

        public C0915e(Status status, MetadataBuffer metadataBuffer, boolean z) {
            this.yw = status;
            this.IL = metadataBuffer;
            this.IM = z;
        }

        public MetadataBuffer getMetadataBuffer() {
            return this.IL;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.b */
    private static class C1064b extends C0911c {
        private final C0052d<DriveIdResult> yO;

        public C1064b(C0052d<DriveIdResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3891a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.yO.m147a(new C0914c(Status.Ek, onDriveIdResponse.getDriveId()));
        }

        public void m3892a(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.yO.m147a(new C0914c(Status.Ek, new C0912l(onMetadataResponse.gw()).getDriveId()));
        }

        public void m3893o(Status status) throws RemoteException {
            this.yO.m147a(new C0914c(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.f */
    private static class C1065f extends C0911c {
        private final C0052d<ContentsResult> yO;

        public C1065f(C0052d<ContentsResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3894a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.yO.m147a(new C0913a(Status.Ek, onContentsResponse.go()));
        }

        public void m3895o(Status status) throws RemoteException {
            this.yO.m147a(new C0913a(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.h */
    static class C1066h extends C0911c {
        private final C0052d<MetadataBufferResult> yO;

        public C1066h(C0052d<MetadataBufferResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3896a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
            this.yO.m147a(new C0915e(Status.Ek, new MetadataBuffer(onListEntriesResponse.gt(), null), onListEntriesResponse.gu()));
        }

        public void m3897o(Status status) throws RemoteException {
            this.yO.m147a(new C0915e(status, null, false));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.d */
    abstract class C1121d extends C1067q<DriveIdResult> {
        final /* synthetic */ C0520p II;

        C1121d(C0520p c0520p) {
            this.II = c0520p;
        }

        public /* synthetic */ Result m4109c(Status status) {
            return m4110p(status);
        }

        public DriveIdResult m4110p(Status status) {
            return new C0914c(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.g */
    abstract class C1122g extends C1067q<ContentsResult> {
        final /* synthetic */ C0520p II;

        C1122g(C0520p c0520p) {
            this.II = c0520p;
        }

        public /* synthetic */ Result m4111c(Status status) {
            return m4112q(status);
        }

        public ContentsResult m4112q(Status status) {
            return new C0913a(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.i */
    abstract class C1123i extends C1067q<MetadataBufferResult> {
        final /* synthetic */ C0520p II;

        C1123i(C0520p c0520p) {
            this.II = c0520p;
        }

        public /* synthetic */ Result m4113c(Status status) {
            return m4114r(status);
        }

        public MetadataBufferResult m4114r(Status status) {
            return new C0915e(status, null, false);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.j */
    static abstract class C1124j extends C1067q<Status> {
        C1124j() {
        }

        public /* synthetic */ Result m4115c(Status status) {
            return m4116d(status);
        }

        public Status m4116d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.l */
    abstract class C1125l extends C1067q<Status> {
        final /* synthetic */ C0520p II;

        C1125l(C0520p c0520p) {
            this.II = c0520p;
        }

        public /* synthetic */ Result m4117c(Status status) {
            return m4118d(status);
        }

        public Status m4118d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.1 */
    class C11981 extends C1123i {
        final /* synthetic */ Query IH;
        final /* synthetic */ C0520p II;

        C11981(C0520p c0520p, Query query) {
            this.II = c0520p;
            this.IH = query;
            super(c0520p);
        }

        protected void m4362a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m288a(new QueryRequest(this.IH), new C1066h(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.2 */
    class C11992 extends C1122g {
        final /* synthetic */ C0520p II;

        C11992(C0520p c0520p) {
            this.II = c0520p;
            super(c0520p);
        }

        protected void m4364a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m277a(new CreateContentsRequest(), new C1065f(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.3 */
    class C12003 extends C1124j {
        final /* synthetic */ C0520p II;
        final /* synthetic */ Contents IJ;

        C12003(C0520p c0520p, Contents contents) {
            this.II = c0520p;
            this.IJ = contents;
        }

        protected void m4366a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m276a(new CloseContentsRequest(this.IJ, false), new aw(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.4 */
    class C12014 extends C1121d {
        final /* synthetic */ C0520p II;
        final /* synthetic */ String IK;

        C12014(C0520p c0520p, String str) {
            this.II = c0520p;
            this.IK = str;
            super(c0520p);
        }

        protected void m4368a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m284a(new GetMetadataRequest(DriveId.aL(this.IK)), new C1064b(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.5 */
    class C12025 extends C1125l {
        final /* synthetic */ C0520p II;

        C12025(C0520p c0520p) {
            this.II = c0520p;
            super(c0520p);
        }

        protected void m4370a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m293a(new aw(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.p.k */
    static class C1203k extends C1124j {
        C1203k(GoogleApiClient googleApiClient, Status status) {
            m1985a(new C0051c(((C0916r) googleApiClient.m138a(Drive.yE)).getLooper()));
            m1988b(status);
        }

        protected void m4372a(C0916r c0916r) {
        }
    }

    public PendingResult<Status> discardContents(GoogleApiClient apiClient, Contents contents) {
        return apiClient.m140b(new C12003(this, contents));
    }

    public PendingResult<DriveIdResult> fetchDriveId(GoogleApiClient apiClient, String resourceId) {
        return apiClient.m139a(new C12014(this, resourceId));
    }

    public DriveFolder getAppFolder(GoogleApiClient apiClient) {
        if (apiClient.isConnected()) {
            DriveId gm = ((C0916r) apiClient.m138a(Drive.yE)).gm();
            return gm != null ? new C0920u(gm) : null;
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFile getFile(GoogleApiClient apiClient, DriveId id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (apiClient.isConnected()) {
            return new C0917s(id);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getFolder(GoogleApiClient apiClient, DriveId id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (apiClient.isConnected()) {
            return new C0920u(id);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getRootFolder(GoogleApiClient apiClient) {
        if (apiClient.isConnected()) {
            return new C0920u(((C0916r) apiClient.m138a(Drive.yE)).gl());
        }
        throw new IllegalStateException("Client must be connected");
    }

    public PendingResult<ContentsResult> newContents(GoogleApiClient apiClient) {
        return apiClient.m139a(new C11992(this));
    }

    public CreateFileActivityBuilder newCreateFileActivityBuilder() {
        return new CreateFileActivityBuilder();
    }

    public OpenFileActivityBuilder newOpenFileActivityBuilder() {
        return new OpenFileActivityBuilder();
    }

    public PendingResult<MetadataBufferResult> query(GoogleApiClient apiClient, Query query) {
        if (query != null) {
            return apiClient.m139a(new C11981(this, query));
        }
        throw new IllegalArgumentException("Query must be provided.");
    }

    public PendingResult<Status> requestSync(GoogleApiClient client) {
        return client.m140b(new C12025(this));
    }
}
