package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.internal.f */
public class C0087f implements Creator<CloseContentsRequest> {
    static void m337a(CloseContentsRequest closeContentsRequest, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, closeContentsRequest.xJ);
        C0072b.m236a(parcel, 2, closeContentsRequest.It, i, false);
        C0072b.m237a(parcel, 3, closeContentsRequest.Iw, false);
        C0072b.m228G(parcel, C);
    }

    public CloseContentsRequest m338V(Parcel parcel) {
        Boolean bool = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        Contents contents = null;
        while (parcel.dataPosition() < B) {
            Contents contents2;
            int g;
            Boolean bool2;
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    Boolean bool3 = bool;
                    contents2 = contents;
                    g = C0071a.m205g(parcel, A);
                    bool2 = bool3;
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    g = i;
                    Contents contents3 = (Contents) C0071a.m194a(parcel, A, Contents.CREATOR);
                    bool2 = bool;
                    contents2 = contents3;
                    break;
                case DetectedActivity.STILL /*3*/:
                    bool2 = C0071a.m202d(parcel, A);
                    contents2 = contents;
                    g = i;
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    bool2 = bool;
                    contents2 = contents;
                    g = i;
                    break;
            }
            i = g;
            contents = contents2;
            bool = bool2;
        }
        if (parcel.dataPosition() == B) {
            return new CloseContentsRequest(i, contents, bool);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public CloseContentsRequest[] aQ(int i) {
        return new CloseContentsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m338V(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aQ(x0);
    }
}
