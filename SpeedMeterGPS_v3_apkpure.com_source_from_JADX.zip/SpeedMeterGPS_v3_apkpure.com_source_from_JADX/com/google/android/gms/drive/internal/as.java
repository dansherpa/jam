package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

public class as implements Creator<OpenFileIntentSenderRequest> {
    static void m325a(OpenFileIntentSenderRequest openFileIntentSenderRequest, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, openFileIntentSenderRequest.xJ);
        C0072b.m240a(parcel, 2, openFileIntentSenderRequest.HV, false);
        C0072b.m247a(parcel, 3, openFileIntentSenderRequest.HW, false);
        C0072b.m236a(parcel, 4, openFileIntentSenderRequest.HX, i, false);
        C0072b.m228G(parcel, C);
    }

    public OpenFileIntentSenderRequest at(Parcel parcel) {
        DriveId driveId = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        String[] strArr = null;
        String str = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    strArr = C0071a.m188A(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    driveId = (DriveId) C0071a.m194a(parcel, A, DriveId.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new OpenFileIntentSenderRequest(i, str, strArr, driveId);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public OpenFileIntentSenderRequest[] bp(int i) {
        return new OpenFileIntentSenderRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return at(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bp(x0);
    }
}
