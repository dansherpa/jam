package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.internal.k */
public class C0092k implements Creator<CreateFolderRequest> {
    static void m347a(CreateFolderRequest createFolderRequest, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, createFolderRequest.xJ);
        C0072b.m236a(parcel, 2, createFolderRequest.IC, i, false);
        C0072b.m236a(parcel, 3, createFolderRequest.IA, i, false);
        C0072b.m228G(parcel, C);
    }

    public CreateFolderRequest m348Z(Parcel parcel) {
        MetadataBundle metadataBundle = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        DriveId driveId = null;
        while (parcel.dataPosition() < B) {
            DriveId driveId2;
            int g;
            MetadataBundle metadataBundle2;
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    MetadataBundle metadataBundle3 = metadataBundle;
                    driveId2 = driveId;
                    g = C0071a.m205g(parcel, A);
                    metadataBundle2 = metadataBundle3;
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    g = i;
                    DriveId driveId3 = (DriveId) C0071a.m194a(parcel, A, DriveId.CREATOR);
                    metadataBundle2 = metadataBundle;
                    driveId2 = driveId3;
                    break;
                case DetectedActivity.STILL /*3*/:
                    metadataBundle2 = (MetadataBundle) C0071a.m194a(parcel, A, MetadataBundle.CREATOR);
                    driveId2 = driveId;
                    g = i;
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    metadataBundle2 = metadataBundle;
                    driveId2 = driveId;
                    g = i;
                    break;
            }
            i = g;
            driveId = driveId2;
            metadataBundle = metadataBundle2;
        }
        if (parcel.dataPosition() == B) {
            return new CreateFolderRequest(i, driveId, metadataBundle);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public CreateFolderRequest[] aV(int i) {
        return new CreateFolderRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m348Z(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aV(x0);
    }
}
