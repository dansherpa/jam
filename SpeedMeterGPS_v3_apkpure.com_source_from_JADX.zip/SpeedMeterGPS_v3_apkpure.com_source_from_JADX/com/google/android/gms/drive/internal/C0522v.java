package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.DriveResource;
import com.google.android.gms.drive.DriveResource.MetadataResult;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.C0520p.C0915e;

/* renamed from: com.google.android.gms.drive.internal.v */
public class C0522v implements DriveResource {
    protected final DriveId Hw;

    /* renamed from: com.google.android.gms.drive.internal.v.e */
    private static class C0921e implements MetadataResult {
        private final Metadata Jj;
        private final Status yw;

        public C0921e(Status status, Metadata metadata) {
            this.yw = status;
            this.Jj = metadata;
        }

        public Metadata getMetadata() {
            return this.Jj;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.b */
    private static class C1071b extends C0911c {
        private final C0052d<MetadataBufferResult> yO;

        public C1071b(C0052d<MetadataBufferResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3905a(OnListParentsResponse onListParentsResponse) throws RemoteException {
            this.yO.m147a(new C0915e(Status.Ek, new MetadataBuffer(onListParentsResponse.gv(), null), false));
        }

        public void m3906o(Status status) throws RemoteException {
            this.yO.m147a(new C0915e(status, null, false));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.d */
    private static class C1072d extends C0911c {
        private final C0052d<MetadataResult> yO;

        public C1072d(C0052d<MetadataResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3907a(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.yO.m147a(new C0921e(Status.Ek, new C0912l(onMetadataResponse.gw())));
        }

        public void m3908o(Status status) throws RemoteException {
            this.yO.m147a(new C0921e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.a */
    private abstract class C1131a extends C1067q<MetadataResult> {
        final /* synthetic */ C0522v Ji;

        private C1131a(C0522v c0522v) {
            this.Ji = c0522v;
        }

        public /* synthetic */ Result m4131c(Status status) {
            return m4132u(status);
        }

        public MetadataResult m4132u(Status status) {
            return new C0921e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.c */
    private abstract class C1132c extends C1067q<MetadataBufferResult> {
        final /* synthetic */ C0522v Ji;

        private C1132c(C0522v c0522v) {
            this.Ji = c0522v;
        }

        public /* synthetic */ Result m4133c(Status status) {
            return m4134r(status);
        }

        public MetadataBufferResult m4134r(Status status) {
            return new C0915e(status, null, false);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.f */
    private abstract class C1133f extends C1067q<MetadataResult> {
        final /* synthetic */ C0522v Ji;

        private C1133f(C0522v c0522v) {
            this.Ji = c0522v;
        }

        public /* synthetic */ Result m4135c(Status status) {
            return m4136u(status);
        }

        public MetadataResult m4136u(Status status) {
            return new C0921e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.1 */
    class C12101 extends C1131a {
        final /* synthetic */ C0522v Ji;

        C12101(C0522v c0522v) {
            this.Ji = c0522v;
            super(null);
        }

        protected void m4386a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m284a(new GetMetadataRequest(this.Ji.Hw), new C1072d(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.2 */
    class C12112 extends C1132c {
        final /* synthetic */ C0522v Ji;

        C12112(C0522v c0522v) {
            this.Ji = c0522v;
            super(null);
        }

        protected void m4388a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m285a(new ListParentsRequest(this.Ji.Hw), new C1071b(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.v.3 */
    class C12123 extends C1133f {
        final /* synthetic */ MetadataChangeSet Ja;
        final /* synthetic */ C0522v Ji;

        C12123(C0522v c0522v, MetadataChangeSet metadataChangeSet) {
            this.Ji = c0522v;
            this.Ja = metadataChangeSet;
            super(null);
        }

        protected void m4390a(C0916r c0916r) throws RemoteException {
            c0916r.gk().m292a(new UpdateMetadataRequest(this.Ji.Hw, this.Ja.gh()), new C1072d(this));
        }
    }

    protected C0522v(DriveId driveId) {
        this.Hw = driveId;
    }

    public PendingResult<Status> addChangeListener(GoogleApiClient apiClient, Listener<ChangeEvent> listener) {
        return ((C0916r) apiClient.m138a(Drive.yE)).m3200a(apiClient, this.Hw, 1, listener);
    }

    public DriveId getDriveId() {
        return this.Hw;
    }

    public PendingResult<MetadataResult> getMetadata(GoogleApiClient apiClient) {
        return apiClient.m139a(new C12101(this));
    }

    public PendingResult<MetadataBufferResult> listParents(GoogleApiClient apiClient) {
        return apiClient.m139a(new C12112(this));
    }

    public PendingResult<Status> removeChangeListener(GoogleApiClient apiClient, Listener<ChangeEvent> listener) {
        return ((C0916r) apiClient.m138a(Drive.yE)).m3203b(apiClient, this.Hw, 1, listener);
    }

    public PendingResult<MetadataResult> updateMetadata(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        if (changeSet != null) {
            return apiClient.m140b(new C12123(this, changeSet));
        }
        throw new IllegalArgumentException("ChangeSet must be provided.");
    }
}
