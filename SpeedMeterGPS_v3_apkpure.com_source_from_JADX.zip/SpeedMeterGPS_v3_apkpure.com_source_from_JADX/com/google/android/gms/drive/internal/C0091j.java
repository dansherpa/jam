package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.internal.j */
public class C0091j implements Creator<CreateFileRequest> {
    static void m345a(CreateFileRequest createFileRequest, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, createFileRequest.xJ);
        C0072b.m236a(parcel, 2, createFileRequest.IC, i, false);
        C0072b.m236a(parcel, 3, createFileRequest.IA, i, false);
        C0072b.m236a(parcel, 4, createFileRequest.It, i, false);
        C0072b.m238a(parcel, 5, createFileRequest.IB, false);
        C0072b.m243a(parcel, 6, createFileRequest.IE);
        C0072b.m240a(parcel, 7, createFileRequest.Iv, false);
        C0072b.m228G(parcel, C);
    }

    public CreateFileRequest m346Y(Parcel parcel) {
        boolean z = false;
        String str = null;
        int B = C0071a.m189B(parcel);
        Integer num = null;
        Contents contents = null;
        MetadataBundle metadataBundle = null;
        DriveId driveId = null;
        int i = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    driveId = (DriveId) C0071a.m194a(parcel, A, DriveId.CREATOR);
                    break;
                case DetectedActivity.STILL /*3*/:
                    metadataBundle = (MetadataBundle) C0071a.m194a(parcel, A, MetadataBundle.CREATOR);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    contents = (Contents) C0071a.m194a(parcel, A, Contents.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    num = C0071a.m206h(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new CreateFileRequest(i, driveId, metadataBundle, contents, num, z, str);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public CreateFileRequest[] aU(int i) {
        return new CreateFileRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m346Y(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aU(x0);
    }
}
