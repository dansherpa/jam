package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.internal.ab.C0517a;
import com.google.android.gms.drive.realtime.internal.C0143m;

/* renamed from: com.google.android.gms.drive.internal.c */
public class C0911c extends C0517a {
    public void m3187a(OnContentsResponse onContentsResponse) throws RemoteException {
    }

    public void m3188a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
    }

    public void m3189a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
    }

    public void m3190a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
    }

    public void m3191a(OnListParentsResponse onListParentsResponse) throws RemoteException {
    }

    public void m3192a(OnLoadRealtimeResponse onLoadRealtimeResponse, C0143m c0143m) throws RemoteException {
    }

    public void m3193a(OnMetadataResponse onMetadataResponse) throws RemoteException {
    }

    public void m3194a(OnResourceIdSetResponse onResourceIdSetResponse) throws RemoteException {
    }

    public void m3195a(OnStorageStatsResponse onStorageStatsResponse) throws RemoteException {
    }

    public void m3196a(OnSyncMoreResponse onSyncMoreResponse) throws RemoteException {
    }

    public void m3197o(Status status) throws RemoteException {
    }

    public void onSuccess() throws RemoteException {
    }
}
