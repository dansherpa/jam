package com.google.android.gms.drive;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.C0048b;
import com.google.android.gms.common.api.Api.C0049c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.drive.internal.C0520p;
import com.google.android.gms.drive.internal.C0521t;
import com.google.android.gms.drive.internal.C0523w;
import com.google.android.gms.drive.internal.C0916r;
import com.google.android.gms.internal.gz;
import java.util.List;

public final class Drive {
    public static final Api<NoOptions> API;
    public static final DriveApi DriveApi;
    public static final Scope HE;
    public static final Scope HF;
    public static final Api<C1063b> HG;
    public static final C0075b HH;
    public static final C0077d HI;
    public static final Scope SCOPE_APPFOLDER;
    public static final Scope SCOPE_FILE;
    public static final C0049c<C0916r> yE;

    /* renamed from: com.google.android.gms.drive.Drive.a */
    public static abstract class C0513a<O extends ApiOptions> implements C0048b<C0916r, O> {
        protected abstract Bundle m2031a(O o);

        public C0916r m2033a(Context context, Looper looper, gz gzVar, O o, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            List fg = gzVar.fg();
            return new C0916r(context, looper, gzVar, connectionCallbacks, onConnectionFailedListener, (String[]) fg.toArray(new String[fg.size()]), m2031a(o));
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    /* renamed from: com.google.android.gms.drive.Drive.1 */
    static class C09081 extends C0513a<NoOptions> {
        C09081() {
        }

        protected Bundle m3176a(NoOptions noOptions) {
            return new Bundle();
        }
    }

    /* renamed from: com.google.android.gms.drive.Drive.2 */
    static class C09092 extends C0513a<C1063b> {
        C09092() {
        }

        protected Bundle m3179a(C1063b c1063b) {
            return c1063b == null ? new Bundle() : c1063b.ge();
        }
    }

    /* renamed from: com.google.android.gms.drive.Drive.b */
    public static class C1063b implements Optional {
        private final Bundle HJ;

        private C1063b() {
            this(new Bundle());
        }

        private C1063b(Bundle bundle) {
            this.HJ = bundle;
        }

        public Bundle ge() {
            return this.HJ;
        }
    }

    static {
        yE = new C0049c();
        SCOPE_FILE = new Scope(Scopes.DRIVE_FILE);
        SCOPE_APPFOLDER = new Scope(Scopes.DRIVE_APPFOLDER);
        HE = new Scope("https://www.googleapis.com/auth/drive");
        HF = new Scope("https://www.googleapis.com/auth/drive.apps");
        API = new Api(new C09081(), yE, new Scope[0]);
        HG = new Api(new C09092(), yE, new Scope[0]);
        DriveApi = new C0520p();
        HH = new C0521t();
        HI = new C0523w();
    }

    private Drive() {
    }
}
