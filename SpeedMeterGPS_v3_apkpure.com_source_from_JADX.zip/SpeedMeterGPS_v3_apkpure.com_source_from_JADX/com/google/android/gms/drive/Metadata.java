package com.google.android.gms.drive;

import com.google.android.gms.common.data.Freezable;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.ir;
import com.google.android.gms.internal.it;
import com.google.android.gms.internal.iv;
import java.util.Date;

public abstract class Metadata implements Freezable<Metadata> {
    public static final int CONTENT_AVAILABLE_LOCALLY = 1;
    public static final int CONTENT_NOT_AVAILABLE_LOCALLY = 0;

    protected abstract <T> T m2035a(MetadataField<T> metadataField);

    public String getAlternateLink() {
        return (String) m2035a(ir.JR);
    }

    public int getContentAvailability() {
        Integer num = (Integer) m2035a(iv.Kz);
        return num == null ? 0 : num.intValue();
    }

    public Date getCreatedDate() {
        return (Date) m2035a(it.Kt);
    }

    public String getDescription() {
        return (String) m2035a(ir.JT);
    }

    public DriveId getDriveId() {
        return (DriveId) m2035a(ir.JQ);
    }

    public String getEmbedLink() {
        return (String) m2035a(ir.JU);
    }

    public String getFileExtension() {
        return (String) m2035a(ir.JV);
    }

    public long getFileSize() {
        return ((Long) m2035a(ir.JW)).longValue();
    }

    public Date getLastViewedByMeDate() {
        return (Date) m2035a(it.Ku);
    }

    public String getMimeType() {
        return (String) m2035a(ir.Kh);
    }

    public Date getModifiedByMeDate() {
        return (Date) m2035a(it.Kw);
    }

    public Date getModifiedDate() {
        return (Date) m2035a(it.Kv);
    }

    public String getOriginalFilename() {
        return (String) m2035a(ir.Ki);
    }

    public long getQuotaBytesUsed() {
        return ((Long) m2035a(ir.Kl)).longValue();
    }

    public Date getSharedWithMeDate() {
        return (Date) m2035a(it.Kx);
    }

    public String getTitle() {
        return (String) m2035a(ir.Ko);
    }

    public String getWebContentLink() {
        return (String) m2035a(ir.Kq);
    }

    public String getWebViewLink() {
        return (String) m2035a(ir.Kr);
    }

    public boolean isEditable() {
        Boolean bool = (Boolean) m2035a(ir.Kb);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isFolder() {
        return DriveFolder.MIME_TYPE.equals(getMimeType());
    }

    public boolean isInAppFolder() {
        Boolean bool = (Boolean) m2035a(ir.JZ);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isPinnable() {
        Boolean bool = (Boolean) m2035a(iv.KA);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isPinned() {
        Boolean bool = (Boolean) m2035a(ir.Kc);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isRestricted() {
        Boolean bool = (Boolean) m2035a(ir.Kd);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isShared() {
        Boolean bool = (Boolean) m2035a(ir.Ke);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isStarred() {
        Boolean bool = (Boolean) m2035a(ir.Km);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isTrashed() {
        Boolean bool = (Boolean) m2035a(ir.Kp);
        return bool == null ? false : bool.booleanValue();
    }

    public boolean isViewed() {
        Boolean bool = (Boolean) m2035a(ir.Kg);
        return bool == null ? false : bool.booleanValue();
    }
}
