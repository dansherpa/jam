package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.c */
public class C0076c implements Creator<DriveId> {
    static void m257a(DriveId driveId, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, driveId.xJ);
        C0072b.m240a(parcel, 2, driveId.HK, false);
        C0072b.m232a(parcel, 3, driveId.HL);
        C0072b.m232a(parcel, 4, driveId.HM);
        C0072b.m228G(parcel, C);
    }

    public DriveId m258N(Parcel parcel) {
        long j = 0;
        int B = C0071a.m189B(parcel);
        int i = 0;
        String str = null;
        long j2 = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    j2 = C0071a.m207i(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    j = C0071a.m207i(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new DriveId(i, str, j2, j);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public DriveId[] aH(int i) {
        return new DriveId[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m258N(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aH(x0);
    }
}
