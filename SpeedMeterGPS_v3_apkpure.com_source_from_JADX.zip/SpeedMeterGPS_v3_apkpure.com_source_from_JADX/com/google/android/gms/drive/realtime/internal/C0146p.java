package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.drive.realtime.internal.p */
public class C0146p implements Creator<ParcelableCollaborator> {
    static void m447a(ParcelableCollaborator parcelableCollaborator, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, parcelableCollaborator.xJ);
        C0072b.m243a(parcel, 2, parcelableCollaborator.Lh);
        C0072b.m243a(parcel, 3, parcelableCollaborator.Li);
        C0072b.m240a(parcel, 4, parcelableCollaborator.rO, false);
        C0072b.m240a(parcel, 5, parcelableCollaborator.Lj, false);
        C0072b.m240a(parcel, 6, parcelableCollaborator.Lk, false);
        C0072b.m240a(parcel, 7, parcelableCollaborator.Ll, false);
        C0072b.m240a(parcel, 8, parcelableCollaborator.Lm, false);
        C0072b.m228G(parcel, C);
    }

    public ParcelableCollaborator aR(Parcel parcel) {
        boolean z = false;
        String str = null;
        int B = C0071a.m189B(parcel);
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    z2 = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    str5 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str4 = C0071a.m213o(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str3 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new ParcelableCollaborator(i, z2, z, str5, str4, str3, str2, str);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public ParcelableCollaborator[] bO(int i) {
        return new ParcelableCollaborator[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aR(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bO(x0);
    }
}
