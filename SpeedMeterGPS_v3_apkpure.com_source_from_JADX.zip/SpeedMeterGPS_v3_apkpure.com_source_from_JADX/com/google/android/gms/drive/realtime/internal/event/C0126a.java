package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;

/* renamed from: com.google.android.gms.drive.realtime.internal.event.a */
public class C0126a implements Creator<ParcelableEvent> {
    static void m385a(ParcelableEvent parcelableEvent, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, parcelableEvent.xJ);
        C0072b.m240a(parcel, 2, parcelableEvent.rO, false);
        C0072b.m240a(parcel, 3, parcelableEvent.Lj, false);
        C0072b.m243a(parcel, 4, parcelableEvent.Lp);
        C0072b.m240a(parcel, 5, parcelableEvent.Ln, false);
        C0072b.m240a(parcel, 6, parcelableEvent.Lq, false);
        C0072b.m236a(parcel, 7, parcelableEvent.Lr, i, false);
        C0072b.m236a(parcel, 8, parcelableEvent.Ls, i, false);
        C0072b.m236a(parcel, 9, parcelableEvent.Lt, i, false);
        C0072b.m236a(parcel, 10, parcelableEvent.Lu, i, false);
        C0072b.m236a(parcel, 11, parcelableEvent.Lv, i, false);
        C0072b.m236a(parcel, 12, parcelableEvent.Lw, i, false);
        C0072b.m236a(parcel, 13, parcelableEvent.Lx, i, false);
        C0072b.m228G(parcel, C);
    }

    public ParcelableEvent aT(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        boolean z = false;
        String str3 = null;
        String str4 = null;
        TextInsertedDetails textInsertedDetails = null;
        TextDeletedDetails textDeletedDetails = null;
        ValuesAddedDetails valuesAddedDetails = null;
        ValuesRemovedDetails valuesRemovedDetails = null;
        ValuesSetDetails valuesSetDetails = null;
        ValueChangedDetails valueChangedDetails = null;
        ReferenceShiftedDetails referenceShiftedDetails = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str3 = C0071a.m213o(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str4 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    textInsertedDetails = (TextInsertedDetails) C0071a.m194a(parcel, A, TextInsertedDetails.CREATOR);
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    textDeletedDetails = (TextDeletedDetails) C0071a.m194a(parcel, A, TextDeletedDetails.CREATOR);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    valuesAddedDetails = (ValuesAddedDetails) C0071a.m194a(parcel, A, ValuesAddedDetails.CREATOR);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    valuesRemovedDetails = (ValuesRemovedDetails) C0071a.m194a(parcel, A, ValuesRemovedDetails.CREATOR);
                    break;
                case C0450R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    valuesSetDetails = (ValuesSetDetails) C0071a.m194a(parcel, A, ValuesSetDetails.CREATOR);
                    break;
                case C0450R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    valueChangedDetails = (ValueChangedDetails) C0071a.m194a(parcel, A, ValueChangedDetails.CREATOR);
                    break;
                case C0450R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    referenceShiftedDetails = (ReferenceShiftedDetails) C0071a.m194a(parcel, A, ReferenceShiftedDetails.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new ParcelableEvent(i, str, str2, z, str3, str4, textInsertedDetails, textDeletedDetails, valuesAddedDetails, valuesRemovedDetails, valuesSetDetails, valueChangedDetails, referenceShiftedDetails);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public ParcelableEvent[] bQ(int i) {
        return new ParcelableEvent[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aT(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bQ(x0);
    }
}
