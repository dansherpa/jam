package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ReferenceShiftedDetails implements SafeParcelable {
    public static final Creator<ReferenceShiftedDetails> CREATOR;
    final String LE;
    final String LF;
    final int LG;
    final int LH;
    final int xJ;

    static {
        CREATOR = new C0129d();
    }

    ReferenceShiftedDetails(int versionCode, String oldObjectId, String newObjectId, int oldIndex, int newIndex) {
        this.xJ = versionCode;
        this.LE = oldObjectId;
        this.LF = newObjectId;
        this.LG = oldIndex;
        this.LH = newIndex;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0129d.m388a(this, dest, flags);
    }
}
