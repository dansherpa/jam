package com.google.android.gms.drive.realtime.internal.event;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class ParcelableEventList implements SafeParcelable {
    public static final Creator<ParcelableEventList> CREATOR;
    final boolean LA;
    final ParcelableObjectChangedEvent[] LB;
    final ParcelableEvent[] Ly;
    final DataHolder Lz;
    final int xJ;

    static {
        CREATOR = new C0127b();
    }

    ParcelableEventList(int versionCode, ParcelableEvent[] events, DataHolder eventData, boolean undoRedoStateChanged, ParcelableObjectChangedEvent[] objectChangedEvents) {
        this.xJ = versionCode;
        this.Ly = events;
        this.Lz = eventData;
        this.LA = undoRedoStateChanged;
        this.LB = objectChangedEvents;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0127b.m386a(this, dest, flags);
    }
}
