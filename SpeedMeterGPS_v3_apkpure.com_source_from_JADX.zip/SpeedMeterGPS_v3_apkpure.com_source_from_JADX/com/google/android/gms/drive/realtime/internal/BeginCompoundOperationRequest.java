package com.google.android.gms.drive.realtime.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class BeginCompoundOperationRequest implements SafeParcelable {
    public static final Creator<BeginCompoundOperationRequest> CREATOR;
    final boolean Lg;
    final String mName;
    final int xJ;

    static {
        CREATOR = new C0121a();
    }

    BeginCompoundOperationRequest(int versionCode, boolean isCreation, String name) {
        this.xJ = versionCode;
        this.Lg = isCreation;
        this.mName = name;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0121a.m377a(this, dest, flags);
    }
}
