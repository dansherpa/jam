package com.google.android.gms.drive;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.internal.C0912l;
import com.google.android.gms.drive.metadata.C0923b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.C0105e;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.ir;
import java.util.ArrayList;
import java.util.List;

public final class MetadataBuffer extends DataBuffer<Metadata> {
    private static final String[] HO;
    private final String HP;
    private C0910a HQ;

    /* renamed from: com.google.android.gms.drive.MetadataBuffer.a */
    private static class C0910a extends Metadata {
        private final DataHolder DD;
        private final int EA;
        private final int HR;

        public C0910a(DataHolder dataHolder, int i) {
            this.DD = dataHolder;
            this.HR = i;
            this.EA = dataHolder.ae(i);
        }

        protected <T> T m3181a(MetadataField<T> metadataField) {
            return metadataField.m355a(this.DD, this.HR, this.EA);
        }

        public /* synthetic */ Object freeze() {
            return gg();
        }

        public Metadata gg() {
            MetadataBundle gA = MetadataBundle.gA();
            for (MetadataField metadataField : C0105e.gz()) {
                if (!((metadataField instanceof C0923b) || metadataField == ir.Kn)) {
                    metadataField.m356a(this.DD, gA, this.HR, this.EA);
                }
            }
            return new C0912l(gA);
        }

        public boolean isDataValid() {
            return !this.DD.isClosed();
        }
    }

    static {
        List arrayList = new ArrayList();
        for (MetadataField gx : C0105e.gz()) {
            arrayList.addAll(gx.gx());
        }
        HO = (String[]) arrayList.toArray(new String[0]);
    }

    public MetadataBuffer(DataHolder dataHolder, String nextPageToken) {
        super(dataHolder);
        this.HP = nextPageToken;
        dataHolder.eP().setClassLoader(MetadataBuffer.class.getClassLoader());
    }

    public Metadata get(int row) {
        C0910a c0910a = this.HQ;
        if (c0910a != null && c0910a.HR == row) {
            return c0910a;
        }
        Metadata c0910a2 = new C0910a(this.DD, row);
        this.HQ = c0910a2;
        return c0910a2;
    }

    public String getNextPageToken() {
        return this.HP;
    }
}
