package com.google.android.gms.drive;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.internal.C0916r;
import com.google.android.gms.drive.internal.OpenFileIntentSenderRequest;
import com.google.android.gms.internal.hn;

public class OpenFileActivityBuilder {
    public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
    private String HV;
    private String[] HW;
    private DriveId HX;

    public IntentSender build(GoogleApiClient apiClient) {
        hn.m1224a(apiClient.isConnected(), "Client must be connected");
        if (this.HW == null) {
            this.HW = new String[0];
        }
        try {
            return ((C0916r) apiClient.m138a(Drive.yE)).gk().m271a(new OpenFileIntentSenderRequest(this.HV, this.HW, this.HX));
        } catch (Throwable e) {
            throw new RuntimeException("Unable to connect Drive Play Service", e);
        }
    }

    public OpenFileActivityBuilder setActivityStartFolder(DriveId folder) {
        this.HX = (DriveId) hn.m1230f(folder);
        return this;
    }

    public OpenFileActivityBuilder setActivityTitle(String title) {
        this.HV = (String) hn.m1230f(title);
        return this;
    }

    public OpenFileActivityBuilder setMimeType(String[] mimeTypes) {
        hn.m1228b(mimeTypes != null, (Object) "mimeTypes may not be null");
        this.HW = mimeTypes;
        return this;
    }
}
