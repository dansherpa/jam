package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.gj;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CastDevice implements SafeParcelable {
    public static final Creator<CastDevice> CREATOR;
    private String Ae;
    String Af;
    private Inet4Address Ag;
    private String Ah;
    private String Ai;
    private String Aj;
    private int Ak;
    private List<WebImage> Al;
    private int Am;
    private final int xJ;

    static {
        CREATOR = new C0044b();
    }

    private CastDevice() {
        this(2, null, null, null, null, null, -1, new ArrayList(), 0);
    }

    CastDevice(int versionCode, String deviceId, String hostAddress, String friendlyName, String modelName, String deviceVersion, int servicePort, List<WebImage> icons, int capabilities) {
        this.xJ = versionCode;
        this.Ae = deviceId;
        this.Af = hostAddress;
        if (this.Af != null) {
            try {
                InetAddress byName = InetAddress.getByName(this.Af);
                if (byName instanceof Inet4Address) {
                    this.Ag = (Inet4Address) byName;
                }
            } catch (UnknownHostException e) {
                this.Ag = null;
            }
        }
        this.Ah = friendlyName;
        this.Ai = modelName;
        this.Aj = deviceVersion;
        this.Ak = servicePort;
        this.Al = icons;
        this.Am = capabilities;
    }

    public static CastDevice getFromBundle(Bundle extras) {
        if (extras == null) {
            return null;
        }
        extras.setClassLoader(CastDevice.class.getClassLoader());
        return (CastDevice) extras.getParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE");
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CastDevice)) {
            return false;
        }
        CastDevice castDevice = (CastDevice) obj;
        return getDeviceId() == null ? castDevice.getDeviceId() == null : gj.m1104a(this.Ae, castDevice.Ae) && gj.m1104a(this.Ag, castDevice.Ag) && gj.m1104a(this.Ai, castDevice.Ai) && gj.m1104a(this.Ah, castDevice.Ah) && gj.m1104a(this.Aj, castDevice.Aj) && this.Ak == castDevice.Ak && gj.m1104a(this.Al, castDevice.Al) && this.Am == castDevice.Am;
    }

    public int getCapabilities() {
        return this.Am;
    }

    public String getDeviceId() {
        return this.Ae;
    }

    public String getDeviceVersion() {
        return this.Aj;
    }

    public String getFriendlyName() {
        return this.Ah;
    }

    public WebImage getIcon(int preferredWidth, int preferredHeight) {
        WebImage webImage = null;
        if (this.Al.isEmpty()) {
            return null;
        }
        if (preferredWidth <= 0 || preferredHeight <= 0) {
            return (WebImage) this.Al.get(0);
        }
        WebImage webImage2 = null;
        for (WebImage webImage3 : this.Al) {
            WebImage webImage32;
            int width = webImage32.getWidth();
            int height = webImage32.getHeight();
            if (width < preferredWidth || height < preferredHeight) {
                if (width < preferredWidth && height < preferredHeight && (webImage == null || (webImage.getWidth() < width && webImage.getHeight() < height))) {
                    webImage = webImage2;
                }
                webImage32 = webImage;
                webImage = webImage2;
            } else {
                if (webImage2 == null || (webImage2.getWidth() > width && webImage2.getHeight() > height)) {
                    WebImage webImage4 = webImage;
                    webImage = webImage32;
                    webImage32 = webImage4;
                }
                webImage32 = webImage;
                webImage = webImage2;
            }
            webImage2 = webImage;
            webImage = webImage32;
        }
        if (webImage2 == null) {
            webImage2 = webImage != null ? webImage : (WebImage) this.Al.get(0);
        }
        return webImage2;
    }

    public List<WebImage> getIcons() {
        return Collections.unmodifiableList(this.Al);
    }

    public Inet4Address getIpAddress() {
        return this.Ag;
    }

    public String getModelName() {
        return this.Ai;
    }

    public int getServicePort() {
        return this.Ak;
    }

    int getVersionCode() {
        return this.xJ;
    }

    public boolean hasIcons() {
        return !this.Al.isEmpty();
    }

    public int hashCode() {
        return this.Ae == null ? 0 : this.Ae.hashCode();
    }

    public boolean isSameDevice(CastDevice castDevice) {
        if (castDevice == null) {
            return false;
        }
        if (getDeviceId() == null) {
            return castDevice.getDeviceId() == null;
        } else {
            return gj.m1104a(getDeviceId(), castDevice.getDeviceId());
        }
    }

    public void putInBundle(Bundle bundle) {
        if (bundle != null) {
            bundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", this);
        }
    }

    public String toString() {
        return String.format("\"%s\" (%s)", new Object[]{this.Ah, this.Ae});
    }

    public void writeToParcel(Parcel out, int flags) {
        C0044b.m109a(this, out, flags);
    }
}
