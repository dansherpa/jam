package com.google.android.gms.cast;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.internal.gt;
import com.google.android.gms.plus.PlusShare;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaMetadata {
    private static final C0042a AA;
    private static final String[] Az;
    public static final String KEY_ALBUM_ARTIST = "com.google.android.gms.cast.metadata.ALBUM_ARTIST";
    public static final String KEY_ALBUM_TITLE = "com.google.android.gms.cast.metadata.ALBUM_TITLE";
    public static final String KEY_ARTIST = "com.google.android.gms.cast.metadata.ARTIST";
    public static final String KEY_BROADCAST_DATE = "com.google.android.gms.cast.metadata.BROADCAST_DATE";
    public static final String KEY_COMPOSER = "com.google.android.gms.cast.metadata.COMPOSER";
    public static final String KEY_CREATION_DATE = "com.google.android.gms.cast.metadata.CREATION_DATE";
    public static final String KEY_DISC_NUMBER = "com.google.android.gms.cast.metadata.DISC_NUMBER";
    public static final String KEY_EPISODE_NUMBER = "com.google.android.gms.cast.metadata.EPISODE_NUMBER";
    public static final String KEY_HEIGHT = "com.google.android.gms.cast.metadata.HEIGHT";
    public static final String KEY_LOCATION_LATITUDE = "com.google.android.gms.cast.metadata.LOCATION_LATITUDE";
    public static final String KEY_LOCATION_LONGITUDE = "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE";
    public static final String KEY_LOCATION_NAME = "com.google.android.gms.cast.metadata.LOCATION_NAME";
    public static final String KEY_RELEASE_DATE = "com.google.android.gms.cast.metadata.RELEASE_DATE";
    public static final String KEY_SEASON_NUMBER = "com.google.android.gms.cast.metadata.SEASON_NUMBER";
    public static final String KEY_SERIES_TITLE = "com.google.android.gms.cast.metadata.SERIES_TITLE";
    public static final String KEY_STUDIO = "com.google.android.gms.cast.metadata.STUDIO";
    public static final String KEY_SUBTITLE = "com.google.android.gms.cast.metadata.SUBTITLE";
    public static final String KEY_TITLE = "com.google.android.gms.cast.metadata.TITLE";
    public static final String KEY_TRACK_NUMBER = "com.google.android.gms.cast.metadata.TRACK_NUMBER";
    public static final String KEY_WIDTH = "com.google.android.gms.cast.metadata.WIDTH";
    public static final int MEDIA_TYPE_GENERIC = 0;
    public static final int MEDIA_TYPE_MOVIE = 1;
    public static final int MEDIA_TYPE_MUSIC_TRACK = 3;
    public static final int MEDIA_TYPE_PHOTO = 4;
    public static final int MEDIA_TYPE_TV_SHOW = 2;
    public static final int MEDIA_TYPE_USER = 100;
    private final Bundle AB;
    private int AC;
    private final List<WebImage> zN;

    /* renamed from: com.google.android.gms.cast.MediaMetadata.a */
    private static class C0042a {
        private final Map<String, String> AD;
        private final Map<String, String> AE;
        private final Map<String, Integer> AF;

        public C0042a() {
            this.AD = new HashMap();
            this.AE = new HashMap();
            this.AF = new HashMap();
        }

        public C0042a m95a(String str, String str2, int i) {
            this.AD.put(str, str2);
            this.AE.put(str2, str);
            this.AF.put(str, Integer.valueOf(i));
            return this;
        }

        public String ae(String str) {
            return (String) this.AD.get(str);
        }

        public String af(String str) {
            return (String) this.AE.get(str);
        }

        public int ag(String str) {
            Integer num = (Integer) this.AF.get(str);
            return num != null ? num.intValue() : MediaMetadata.MEDIA_TYPE_GENERIC;
        }
    }

    static {
        Az = new String[]{null, "String", "int", "double", "ISO-8601 date String"};
        AA = new C0042a().m95a(KEY_CREATION_DATE, "creationDateTime", MEDIA_TYPE_PHOTO).m95a(KEY_RELEASE_DATE, "releaseDate", MEDIA_TYPE_PHOTO).m95a(KEY_BROADCAST_DATE, "originalAirdate", MEDIA_TYPE_PHOTO).m95a(KEY_TITLE, PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, MEDIA_TYPE_MOVIE).m95a(KEY_SUBTITLE, "subtitle", MEDIA_TYPE_MOVIE).m95a(KEY_ARTIST, "artist", MEDIA_TYPE_MOVIE).m95a(KEY_ALBUM_ARTIST, "albumArtist", MEDIA_TYPE_MOVIE).m95a(KEY_ALBUM_TITLE, "albumName", MEDIA_TYPE_MOVIE).m95a(KEY_COMPOSER, "composer", MEDIA_TYPE_MOVIE).m95a(KEY_DISC_NUMBER, "discNumber", MEDIA_TYPE_TV_SHOW).m95a(KEY_TRACK_NUMBER, "trackNumber", MEDIA_TYPE_TV_SHOW).m95a(KEY_SEASON_NUMBER, "season", MEDIA_TYPE_TV_SHOW).m95a(KEY_EPISODE_NUMBER, "episode", MEDIA_TYPE_TV_SHOW).m95a(KEY_SERIES_TITLE, "seriesTitle", MEDIA_TYPE_MOVIE).m95a(KEY_STUDIO, "studio", MEDIA_TYPE_MOVIE).m95a(KEY_WIDTH, "width", MEDIA_TYPE_TV_SHOW).m95a(KEY_HEIGHT, "height", MEDIA_TYPE_TV_SHOW).m95a(KEY_LOCATION_NAME, "location", MEDIA_TYPE_MOVIE).m95a(KEY_LOCATION_LATITUDE, "latitude", MEDIA_TYPE_MUSIC_TRACK).m95a(KEY_LOCATION_LONGITUDE, "longitude", MEDIA_TYPE_MUSIC_TRACK);
    }

    public MediaMetadata() {
        this(MEDIA_TYPE_GENERIC);
    }

    public MediaMetadata(int mediaType) {
        this.zN = new ArrayList();
        this.AB = new Bundle();
        this.AC = mediaType;
    }

    private void m96a(JSONObject jSONObject, String... strArr) {
        try {
            int length = strArr.length;
            for (int i = MEDIA_TYPE_GENERIC; i < length; i += MEDIA_TYPE_MOVIE) {
                String str = strArr[i];
                if (this.AB.containsKey(str)) {
                    switch (AA.ag(str)) {
                        case MEDIA_TYPE_MOVIE /*1*/:
                        case MEDIA_TYPE_PHOTO /*4*/:
                            jSONObject.put(AA.ae(str), this.AB.getString(str));
                            break;
                        case MEDIA_TYPE_TV_SHOW /*2*/:
                            jSONObject.put(AA.ae(str), this.AB.getInt(str));
                            break;
                        case MEDIA_TYPE_MUSIC_TRACK /*3*/:
                            jSONObject.put(AA.ae(str), this.AB.getDouble(str));
                            break;
                        default:
                            break;
                    }
                }
            }
            for (String str2 : this.AB.keySet()) {
                if (!str2.startsWith("com.google.")) {
                    Object obj = this.AB.get(str2);
                    if (obj instanceof String) {
                        jSONObject.put(str2, obj);
                    } else if (obj instanceof Integer) {
                        jSONObject.put(str2, obj);
                    } else if (obj instanceof Double) {
                        jSONObject.put(str2, obj);
                    }
                }
            }
        } catch (JSONException e) {
        }
    }

    private boolean m97a(Bundle bundle, Bundle bundle2) {
        if (bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            Object obj = bundle.get(str);
            Object obj2 = bundle2.get(str);
            if ((obj instanceof Bundle) && (obj2 instanceof Bundle) && !m97a((Bundle) obj, (Bundle) obj2)) {
                return false;
            }
            if (obj == null) {
                if (obj2 != null || !bundle2.containsKey(str)) {
                    return false;
                }
            } else if (!obj.equals(obj2)) {
                return false;
            }
        }
        return true;
    }

    private void m98b(JSONObject jSONObject, String... strArr) {
        Set hashSet = new HashSet(Arrays.asList(strArr));
        try {
            Iterator keys = jSONObject.keys();
            while (keys.hasNext()) {
                String str = (String) keys.next();
                if (!"metadataType".equals(str)) {
                    String af = AA.af(str);
                    if (af == null) {
                        Object obj = jSONObject.get(str);
                        if (obj instanceof String) {
                            this.AB.putString(str, (String) obj);
                        } else if (obj instanceof Integer) {
                            this.AB.putInt(str, ((Integer) obj).intValue());
                        } else if (obj instanceof Double) {
                            this.AB.putDouble(str, ((Double) obj).doubleValue());
                        }
                    } else if (hashSet.contains(af)) {
                        try {
                            Object obj2 = jSONObject.get(str);
                            if (obj2 != null) {
                                switch (AA.ag(af)) {
                                    case MEDIA_TYPE_MOVIE /*1*/:
                                        if (!(obj2 instanceof String)) {
                                            break;
                                        }
                                        this.AB.putString(af, (String) obj2);
                                        break;
                                    case MEDIA_TYPE_TV_SHOW /*2*/:
                                        if (!(obj2 instanceof Integer)) {
                                            break;
                                        }
                                        this.AB.putInt(af, ((Integer) obj2).intValue());
                                        break;
                                    case MEDIA_TYPE_MUSIC_TRACK /*3*/:
                                        if (!(obj2 instanceof Double)) {
                                            break;
                                        }
                                        this.AB.putDouble(af, ((Double) obj2).doubleValue());
                                        break;
                                    case MEDIA_TYPE_PHOTO /*4*/:
                                        if (!(obj2 instanceof String)) {
                                            break;
                                        }
                                        if (gt.aq((String) obj2) == null) {
                                            break;
                                        }
                                        this.AB.putString(af, (String) obj2);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        } catch (JSONException e) {
                        }
                    }
                }
            }
        } catch (JSONException e2) {
        }
    }

    private void m99d(String str, int i) throws IllegalArgumentException {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("null and empty keys are not allowed");
        }
        int ag = AA.ag(str);
        if (ag != i && ag != 0) {
            throw new IllegalArgumentException("Value for " + str + " must be a " + Az[i]);
        }
    }

    public void addImage(WebImage image) {
        this.zN.add(image);
    }

    public void m100b(JSONObject jSONObject) {
        clear();
        this.AC = MEDIA_TYPE_GENERIC;
        try {
            this.AC = jSONObject.getInt("metadataType");
        } catch (JSONException e) {
        }
        gt.m1145a(this.zN, jSONObject);
        String[] strArr;
        switch (this.AC) {
            case MEDIA_TYPE_GENERIC /*0*/:
                strArr = new String[MEDIA_TYPE_PHOTO];
                strArr[MEDIA_TYPE_GENERIC] = KEY_TITLE;
                strArr[MEDIA_TYPE_MOVIE] = KEY_ARTIST;
                strArr[MEDIA_TYPE_TV_SHOW] = KEY_SUBTITLE;
                strArr[MEDIA_TYPE_MUSIC_TRACK] = KEY_RELEASE_DATE;
                m98b(jSONObject, strArr);
            case MEDIA_TYPE_MOVIE /*1*/:
                strArr = new String[MEDIA_TYPE_PHOTO];
                strArr[MEDIA_TYPE_GENERIC] = KEY_TITLE;
                strArr[MEDIA_TYPE_MOVIE] = KEY_STUDIO;
                strArr[MEDIA_TYPE_TV_SHOW] = KEY_SUBTITLE;
                strArr[MEDIA_TYPE_MUSIC_TRACK] = KEY_RELEASE_DATE;
                m98b(jSONObject, strArr);
            case MEDIA_TYPE_TV_SHOW /*2*/:
                m98b(jSONObject, KEY_TITLE, KEY_SERIES_TITLE, KEY_SEASON_NUMBER, KEY_EPISODE_NUMBER, KEY_BROADCAST_DATE);
            case MEDIA_TYPE_MUSIC_TRACK /*3*/:
                m98b(jSONObject, KEY_TITLE, KEY_ALBUM_TITLE, KEY_ARTIST, KEY_ALBUM_ARTIST, KEY_COMPOSER, KEY_TRACK_NUMBER, KEY_DISC_NUMBER, KEY_RELEASE_DATE);
            case MEDIA_TYPE_PHOTO /*4*/:
                m98b(jSONObject, KEY_TITLE, KEY_ARTIST, KEY_LOCATION_NAME, KEY_LOCATION_LATITUDE, KEY_LOCATION_LONGITUDE, KEY_WIDTH, KEY_HEIGHT, KEY_CREATION_DATE);
            default:
                m98b(jSONObject, new String[MEDIA_TYPE_GENERIC]);
        }
    }

    public void clear() {
        this.AB.clear();
        this.zN.clear();
    }

    public void clearImages() {
        this.zN.clear();
    }

    public boolean containsKey(String key) {
        return this.AB.containsKey(key);
    }

    public JSONObject dU() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("metadataType", this.AC);
        } catch (JSONException e) {
        }
        gt.m1146a(jSONObject, this.zN);
        String[] strArr;
        switch (this.AC) {
            case MEDIA_TYPE_GENERIC /*0*/:
                strArr = new String[MEDIA_TYPE_PHOTO];
                strArr[MEDIA_TYPE_GENERIC] = KEY_TITLE;
                strArr[MEDIA_TYPE_MOVIE] = KEY_ARTIST;
                strArr[MEDIA_TYPE_TV_SHOW] = KEY_SUBTITLE;
                strArr[MEDIA_TYPE_MUSIC_TRACK] = KEY_RELEASE_DATE;
                m96a(jSONObject, strArr);
                break;
            case MEDIA_TYPE_MOVIE /*1*/:
                strArr = new String[MEDIA_TYPE_PHOTO];
                strArr[MEDIA_TYPE_GENERIC] = KEY_TITLE;
                strArr[MEDIA_TYPE_MOVIE] = KEY_STUDIO;
                strArr[MEDIA_TYPE_TV_SHOW] = KEY_SUBTITLE;
                strArr[MEDIA_TYPE_MUSIC_TRACK] = KEY_RELEASE_DATE;
                m96a(jSONObject, strArr);
                break;
            case MEDIA_TYPE_TV_SHOW /*2*/:
                m96a(jSONObject, KEY_TITLE, KEY_SERIES_TITLE, KEY_SEASON_NUMBER, KEY_EPISODE_NUMBER, KEY_BROADCAST_DATE);
                break;
            case MEDIA_TYPE_MUSIC_TRACK /*3*/:
                m96a(jSONObject, KEY_TITLE, KEY_ARTIST, KEY_ALBUM_TITLE, KEY_ALBUM_ARTIST, KEY_COMPOSER, KEY_TRACK_NUMBER, KEY_DISC_NUMBER, KEY_RELEASE_DATE);
                break;
            case MEDIA_TYPE_PHOTO /*4*/:
                m96a(jSONObject, KEY_TITLE, KEY_ARTIST, KEY_LOCATION_NAME, KEY_LOCATION_LATITUDE, KEY_LOCATION_LONGITUDE, KEY_WIDTH, KEY_HEIGHT, KEY_CREATION_DATE);
                break;
            default:
                m96a(jSONObject, new String[MEDIA_TYPE_GENERIC]);
                break;
        }
        return jSONObject;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MediaMetadata)) {
            return false;
        }
        MediaMetadata mediaMetadata = (MediaMetadata) other;
        return m97a(this.AB, mediaMetadata.AB) && this.zN.equals(mediaMetadata.zN);
    }

    public Calendar getDate(String key) {
        m99d(key, MEDIA_TYPE_PHOTO);
        String string = this.AB.getString(key);
        return string != null ? gt.aq(string) : null;
    }

    public String getDateAsString(String key) {
        m99d(key, MEDIA_TYPE_PHOTO);
        return this.AB.getString(key);
    }

    public double getDouble(String key) {
        m99d(key, MEDIA_TYPE_MUSIC_TRACK);
        return this.AB.getDouble(key);
    }

    public List<WebImage> getImages() {
        return this.zN;
    }

    public int getInt(String key) {
        m99d(key, MEDIA_TYPE_TV_SHOW);
        return this.AB.getInt(key);
    }

    public int getMediaType() {
        return this.AC;
    }

    public String getString(String key) {
        m99d(key, MEDIA_TYPE_MOVIE);
        return this.AB.getString(key);
    }

    public boolean hasImages() {
        return (this.zN == null || this.zN.isEmpty()) ? false : true;
    }

    public int hashCode() {
        int i = 17;
        for (String str : this.AB.keySet()) {
            i *= 31;
            i = this.AB.get(str).hashCode() + i;
        }
        return (i * 31) + this.zN.hashCode();
    }

    public Set<String> keySet() {
        return this.AB.keySet();
    }

    public void putDate(String key, Calendar value) {
        m99d(key, MEDIA_TYPE_PHOTO);
        this.AB.putString(key, gt.m1144a(value));
    }

    public void putDouble(String key, double value) {
        m99d(key, MEDIA_TYPE_MUSIC_TRACK);
        this.AB.putDouble(key, value);
    }

    public void putInt(String key, int value) {
        m99d(key, MEDIA_TYPE_TV_SHOW);
        this.AB.putInt(key, value);
    }

    public void putString(String key, String value) {
        m99d(key, MEDIA_TYPE_MOVIE);
        this.AB.putString(key, value);
    }
}
