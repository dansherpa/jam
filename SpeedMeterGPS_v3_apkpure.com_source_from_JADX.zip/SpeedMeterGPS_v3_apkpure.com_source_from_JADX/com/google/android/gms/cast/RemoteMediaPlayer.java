package com.google.android.gms.cast;

import com.google.android.gms.cast.Cast.C1062a;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.gi;
import com.google.android.gms.internal.gp;
import com.google.android.gms.internal.gq;
import com.google.android.gms.internal.gr;
import java.io.IOException;
import org.json.JSONObject;

public class RemoteMediaPlayer implements MessageReceivedCallback {
    public static final int RESUME_STATE_PAUSE = 2;
    public static final int RESUME_STATE_PLAY = 1;
    public static final int RESUME_STATE_UNCHANGED = 0;
    public static final int STATUS_CANCELED = 2;
    public static final int STATUS_FAILED = 1;
    public static final int STATUS_REPLACED = 4;
    public static final int STATUS_SUCCEEDED = 0;
    public static final int STATUS_TIMED_OUT = 3;
    private final gp AT;
    private final C0497a AU;
    private OnMetadataUpdatedListener AV;
    private OnStatusUpdatedListener AW;
    private final Object lq;

    public interface OnMetadataUpdatedListener {
        void onMetadataUpdated();
    }

    public interface OnStatusUpdatedListener {
        void onStatusUpdated();
    }

    public interface MediaChannelResult extends Result {
        JSONObject getCustomData();
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.a */
    private class C0497a implements gq {
        final /* synthetic */ RemoteMediaPlayer AX;
        private GoogleApiClient Bj;
        private long Bk;

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.a.a */
        private final class C0496a implements ResultCallback<Status> {
            private final long Bl;
            final /* synthetic */ C0497a Bm;

            C0496a(C0497a c0497a, long j) {
                this.Bm = c0497a;
                this.Bl = j;
            }

            public void m1971k(Status status) {
                if (!status.isSuccess()) {
                    this.Bm.AX.AT.m2635a(this.Bl, status.getStatusCode());
                }
            }

            public /* synthetic */ void onResult(Result x0) {
                m1971k((Status) x0);
            }
        }

        public C0497a(RemoteMediaPlayer remoteMediaPlayer) {
            this.AX = remoteMediaPlayer;
            this.Bk = 0;
        }

        public void m1972a(String str, String str2, long j, String str3) throws IOException {
            if (this.Bj == null) {
                throw new IOException("No GoogleApiClient available");
            }
            Cast.CastApi.sendMessage(this.Bj, str, str2).setResultCallback(new C0496a(this, j));
        }

        public void m1973b(GoogleApiClient googleApiClient) {
            this.Bj = googleApiClient;
        }

        public long dW() {
            long j = this.Bk + 1;
            this.Bk = j;
            return j;
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.1 */
    class C09001 extends gp {
        final /* synthetic */ RemoteMediaPlayer AX;

        C09001(RemoteMediaPlayer remoteMediaPlayer) {
            this.AX = remoteMediaPlayer;
        }

        protected void onMetadataUpdated() {
            this.AX.onMetadataUpdated();
        }

        protected void onStatusUpdated() {
            this.AX.onStatusUpdated();
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.c */
    private static final class C0902c implements MediaChannelResult {
        private final JSONObject Ax;
        private final Status yw;

        C0902c(Status status, JSONObject jSONObject) {
            this.yw = status;
            this.Ax = jSONObject;
        }

        public JSONObject getCustomData() {
            return this.Ax;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b */
    private static abstract class C1120b extends C1062a<MediaChannelResult> {
        gr Bn;

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b.1 */
        class C04981 implements gr {
            final /* synthetic */ C1120b Bo;

            C04981(C1120b c1120b) {
                this.Bo = c1120b;
            }

            public void m1974a(long j, int i, JSONObject jSONObject) {
                this.Bo.m1988b(new C0902c(new Status(i), jSONObject));
            }

            public void m1975n(long j) {
                this.Bo.m1988b(this.Bo.m4108l(new Status(RemoteMediaPlayer.STATUS_REPLACED)));
            }
        }

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b.2 */
        class C09012 implements MediaChannelResult {
            final /* synthetic */ C1120b Bo;
            final /* synthetic */ Status yG;

            C09012(C1120b c1120b, Status status) {
                this.Bo = c1120b;
                this.yG = status;
            }

            public JSONObject getCustomData() {
                return null;
            }

            public Status getStatus() {
                return this.yG;
            }
        }

        C1120b() {
            this.Bn = new C04981(this);
        }

        public /* synthetic */ Result m4107c(Status status) {
            return m4108l(status);
        }

        public MediaChannelResult m4108l(Status status) {
            return new C09012(this, status);
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.10 */
    class AnonymousClass10 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ JSONObject Be;
        final /* synthetic */ boolean Bi;

        AnonymousClass10(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, boolean z, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Bi = z;
            this.Be = jSONObject;
        }

        protected void m4342a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2633a(this.Bn, this.Bi, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IllegalStateException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (IOException e2) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.11 */
    class AnonymousClass11 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;

        AnonymousClass11(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
        }

        protected void m4344a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2627a(this.Bn);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.2 */
    class C11902 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ long[] AZ;

        C11902(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, long[] jArr) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.AZ = jArr;
        }

        protected void m4346a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2634a(this.Bn, this.AZ);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.3 */
    class C11913 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ TextTrackStyle Ba;

        C11913(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, TextTrackStyle textTrackStyle) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Ba = textTrackStyle;
        }

        protected void m4348a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2631a(this.Bn, this.Ba);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.4 */
    class C11924 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ MediaInfo Bb;
        final /* synthetic */ boolean Bc;
        final /* synthetic */ long Bd;
        final /* synthetic */ JSONObject Be;

        C11924(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, MediaInfo mediaInfo, boolean z, long j, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Bb = mediaInfo;
            this.Bc = z;
            this.Bd = j;
            this.Be = jSONObject;
        }

        protected void m4350a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2630a(this.Bn, this.Bb, this.Bc, this.Bd, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.5 */
    class C11935 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ JSONObject Be;

        C11935(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Be = jSONObject;
        }

        protected void m4352a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2632a(this.Bn, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.6 */
    class C11946 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ JSONObject Be;

        C11946(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Be = jSONObject;
        }

        protected void m4354a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2636b(this.Bn, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.7 */
    class C11957 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ JSONObject Be;

        C11957(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Be = jSONObject;
        }

        protected void m4356a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2637c(this.Bn, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.8 */
    class C11968 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ JSONObject Be;
        final /* synthetic */ long Bf;
        final /* synthetic */ int Bg;

        C11968(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, long j, int i, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Bf = j;
            this.Bg = i;
            this.Be = jSONObject;
        }

        protected void m4358a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2629a(this.Bn, this.Bf, this.Bg, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IOException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.9 */
    class C11979 extends C1120b {
        final /* synthetic */ RemoteMediaPlayer AX;
        final /* synthetic */ GoogleApiClient AY;
        final /* synthetic */ JSONObject Be;
        final /* synthetic */ double Bh;

        C11979(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, double d, JSONObject jSONObject) {
            this.AX = remoteMediaPlayer;
            this.AY = googleApiClient;
            this.Bh = d;
            this.Be = jSONObject;
        }

        protected void m4360a(gi giVar) {
            synchronized (this.AX.lq) {
                this.AX.AU.m1973b(this.AY);
                try {
                    this.AX.AT.m2628a(this.Bn, this.Bh, this.Be);
                    this.AX.AU.m1973b(null);
                } catch (IllegalStateException e) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (IllegalArgumentException e2) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (IOException e3) {
                    m1988b(m4108l(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                    this.AX.AU.m1973b(null);
                } catch (Throwable th) {
                    this.AX.AU.m1973b(null);
                }
            }
        }
    }

    public RemoteMediaPlayer() {
        this.lq = new Object();
        this.AU = new C0497a(this);
        this.AT = new C09001(this);
        this.AT.m1102a(this.AU);
    }

    private void onMetadataUpdated() {
        if (this.AV != null) {
            this.AV.onMetadataUpdated();
        }
    }

    private void onStatusUpdated() {
        if (this.AW != null) {
            this.AW.onStatusUpdated();
        }
    }

    public long getApproximateStreamPosition() {
        long approximateStreamPosition;
        synchronized (this.lq) {
            approximateStreamPosition = this.AT.getApproximateStreamPosition();
        }
        return approximateStreamPosition;
    }

    public MediaInfo getMediaInfo() {
        MediaInfo mediaInfo;
        synchronized (this.lq) {
            mediaInfo = this.AT.getMediaInfo();
        }
        return mediaInfo;
    }

    public MediaStatus getMediaStatus() {
        MediaStatus mediaStatus;
        synchronized (this.lq) {
            mediaStatus = this.AT.getMediaStatus();
        }
        return mediaStatus;
    }

    public String getNamespace() {
        return this.AT.getNamespace();
    }

    public long getStreamDuration() {
        long streamDuration;
        synchronized (this.lq) {
            streamDuration = this.AT.getStreamDuration();
        }
        return streamDuration;
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo) {
        return load(apiClient, mediaInfo, true, 0, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay) {
        return load(apiClient, mediaInfo, autoplay, 0, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition) {
        return load(apiClient, mediaInfo, autoplay, playPosition, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition, JSONObject customData) {
        return apiClient.m140b(new C11924(this, apiClient, mediaInfo, autoplay, playPosition, customData));
    }

    public void onMessageReceived(CastDevice castDevice, String namespace, String message) {
        this.AT.ai(message);
    }

    public PendingResult<MediaChannelResult> pause(GoogleApiClient apiClient) {
        return pause(apiClient, null);
    }

    public PendingResult<MediaChannelResult> pause(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m140b(new C11935(this, apiClient, customData));
    }

    public PendingResult<MediaChannelResult> play(GoogleApiClient apiClient) {
        return play(apiClient, null);
    }

    public PendingResult<MediaChannelResult> play(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m140b(new C11957(this, apiClient, customData));
    }

    public PendingResult<MediaChannelResult> requestStatus(GoogleApiClient apiClient) {
        return apiClient.m140b(new AnonymousClass11(this, apiClient));
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position) {
        return seek(apiClient, position, STATUS_SUCCEEDED, null);
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position, int resumeState) {
        return seek(apiClient, position, resumeState, null);
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position, int resumeState, JSONObject customData) {
        return apiClient.m140b(new C11968(this, apiClient, position, resumeState, customData));
    }

    public PendingResult<MediaChannelResult> setActiveMediaTracks(GoogleApiClient apiClient, long[] trackIds) {
        return apiClient.m140b(new C11902(this, apiClient, trackIds));
    }

    public void setOnMetadataUpdatedListener(OnMetadataUpdatedListener listener) {
        this.AV = listener;
    }

    public void setOnStatusUpdatedListener(OnStatusUpdatedListener listener) {
        this.AW = listener;
    }

    public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient apiClient, boolean muteState) {
        return setStreamMute(apiClient, muteState, null);
    }

    public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient apiClient, boolean muteState, JSONObject customData) {
        return apiClient.m140b(new AnonymousClass10(this, apiClient, muteState, customData));
    }

    public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient apiClient, double volume) throws IllegalArgumentException {
        return setStreamVolume(apiClient, volume, null);
    }

    public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient apiClient, double volume, JSONObject customData) throws IllegalArgumentException {
        if (!Double.isInfinite(volume) && !Double.isNaN(volume)) {
            return apiClient.m140b(new C11979(this, apiClient, volume, customData));
        }
        throw new IllegalArgumentException("Volume cannot be " + volume);
    }

    public PendingResult<MediaChannelResult> setTextTrackStyle(GoogleApiClient apiClient, TextTrackStyle trackStyle) {
        return apiClient.m140b(new C11913(this, apiClient, trackStyle));
    }

    public PendingResult<MediaChannelResult> stop(GoogleApiClient apiClient) {
        return stop(apiClient, null);
    }

    public PendingResult<MediaChannelResult> stop(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m140b(new C11946(this, apiClient, customData));
    }
}
