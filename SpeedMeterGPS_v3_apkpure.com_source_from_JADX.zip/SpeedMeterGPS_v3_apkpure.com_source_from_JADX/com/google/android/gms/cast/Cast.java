package com.google.android.gms.cast;

import android.content.Context;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.cast.LaunchOptions.Builder;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.HasOptions;
import com.google.android.gms.common.api.Api.C0048b;
import com.google.android.gms.common.api.Api.C0049c;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.C0053a.C0903b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.gi;
import com.google.android.gms.internal.gz;
import com.google.android.gms.internal.hn;
import java.io.IOException;

public final class Cast {
    public static final Api<CastOptions> API;
    public static final CastApi CastApi;
    public static final String EXTRA_APP_NO_LONGER_RUNNING = "com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING";
    public static final int MAX_MESSAGE_LENGTH = 65536;
    public static final int MAX_NAMESPACE_LENGTH = 128;
    static final C0049c<gi> yE;
    private static final C0048b<gi, CastOptions> yF;

    public interface CastApi {

        /* renamed from: com.google.android.gms.cast.Cast.CastApi.a */
        public static final class C0495a implements CastApi {

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.1 */
            class C11811 extends C1118b {
                final /* synthetic */ String zR;
                final /* synthetic */ String zS;
                final /* synthetic */ C0495a zT;

                C11811(C0495a c0495a, String str, String str2) {
                    this.zT = c0495a;
                    this.zR = str;
                    this.zS = str2;
                    super();
                }

                protected void m4324a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3635a(this.zR, this.zS, (C0052d) this);
                    } catch (IllegalArgumentException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    } catch (IllegalStateException e2) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.2 */
            class C11822 extends C1119c {
                final /* synthetic */ C0495a zT;
                final /* synthetic */ String zU;

                C11822(C0495a c0495a, String str) {
                    this.zT = c0495a;
                    this.zU = str;
                    super();
                }

                protected void m4326a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3636a(this.zU, false, (C0052d) this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.3 */
            class C11833 extends C1119c {
                final /* synthetic */ C0495a zT;
                final /* synthetic */ String zU;
                final /* synthetic */ LaunchOptions zV;

                C11833(C0495a c0495a, String str, LaunchOptions launchOptions) {
                    this.zT = c0495a;
                    this.zU = str;
                    this.zV = launchOptions;
                    super();
                }

                protected void m4328a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3633a(this.zU, this.zV, (C0052d) this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.4 */
            class C11844 extends C1119c {
                final /* synthetic */ C0495a zT;
                final /* synthetic */ String zU;
                final /* synthetic */ String zW;

                C11844(C0495a c0495a, String str, String str2) {
                    this.zT = c0495a;
                    this.zU = str;
                    this.zW = str2;
                    super();
                }

                protected void m4330a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3637b(this.zU, this.zW, this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.5 */
            class C11855 extends C1119c {
                final /* synthetic */ C0495a zT;
                final /* synthetic */ String zU;

                C11855(C0495a c0495a, String str) {
                    this.zT = c0495a;
                    this.zU = str;
                    super();
                }

                protected void m4332a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3637b(this.zU, null, this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.6 */
            class C11866 extends C1119c {
                final /* synthetic */ C0495a zT;

                C11866(C0495a c0495a) {
                    this.zT = c0495a;
                    super();
                }

                protected void m4334a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3637b(null, null, this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.7 */
            class C11877 extends C1118b {
                final /* synthetic */ C0495a zT;

                C11877(C0495a c0495a) {
                    this.zT = c0495a;
                    super();
                }

                protected void m4336a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3638d((C0052d) this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.8 */
            class C11888 extends C1118b {
                final /* synthetic */ C0495a zT;

                C11888(C0495a c0495a) {
                    this.zT = c0495a;
                    super();
                }

                protected void m4338a(gi giVar) throws RemoteException {
                    try {
                        giVar.m3634a("", (C0052d) this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.9 */
            class C11899 extends C1118b {
                final /* synthetic */ C0495a zT;
                final /* synthetic */ String zW;

                C11899(C0495a c0495a, String str) {
                    this.zT = c0495a;
                    this.zW = str;
                    super();
                }

                protected void m4340a(gi giVar) throws RemoteException {
                    if (TextUtils.isEmpty(this.zW)) {
                        m3889c(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE, "IllegalArgument: sessionId cannot be null or empty");
                        return;
                    }
                    try {
                        giVar.m3634a(this.zW, (C0052d) this);
                    } catch (IllegalStateException e) {
                        m3888N(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            public ApplicationMetadata getApplicationMetadata(GoogleApiClient client) throws IllegalStateException {
                return ((gi) client.m138a(Cast.yE)).getApplicationMetadata();
            }

            public String getApplicationStatus(GoogleApiClient client) throws IllegalStateException {
                return ((gi) client.m138a(Cast.yE)).getApplicationStatus();
            }

            public double getVolume(GoogleApiClient client) throws IllegalStateException {
                return ((gi) client.m138a(Cast.yE)).ec();
            }

            public boolean isMute(GoogleApiClient client) throws IllegalStateException {
                return ((gi) client.m138a(Cast.yE)).isMute();
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client) {
                return client.m140b(new C11866(this));
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client, String applicationId) {
                return client.m140b(new C11855(this, applicationId));
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client, String applicationId, String sessionId) {
                return client.m140b(new C11844(this, applicationId, sessionId));
            }

            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId) {
                return client.m140b(new C11822(this, applicationId));
            }

            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId, LaunchOptions options) {
                return client.m140b(new C11833(this, applicationId, options));
            }

            @Deprecated
            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId, boolean relaunchIfRunning) {
                return launchApplication(client, applicationId, new Builder().setRelaunchIfRunning(relaunchIfRunning).build());
            }

            public PendingResult<Status> leaveApplication(GoogleApiClient client) {
                return client.m140b(new C11877(this));
            }

            public void removeMessageReceivedCallbacks(GoogleApiClient client, String namespace) throws IOException, IllegalArgumentException {
                try {
                    ((gi) client.m138a(Cast.yE)).aj(namespace);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void requestStatus(GoogleApiClient client) throws IOException, IllegalStateException {
                try {
                    ((gi) client.m138a(Cast.yE)).eb();
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public PendingResult<Status> sendMessage(GoogleApiClient client, String namespace, String message) {
                return client.m140b(new C11811(this, namespace, message));
            }

            public void setMessageReceivedCallbacks(GoogleApiClient client, String namespace, MessageReceivedCallback callbacks) throws IOException, IllegalStateException {
                try {
                    ((gi) client.m138a(Cast.yE)).m3632a(namespace, callbacks);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void setMute(GoogleApiClient client, boolean mute) throws IOException, IllegalStateException {
                try {
                    ((gi) client.m138a(Cast.yE)).m3640y(mute);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void setVolume(GoogleApiClient client, double volume) throws IOException, IllegalArgumentException, IllegalStateException {
                try {
                    ((gi) client.m138a(Cast.yE)).m3629a(volume);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public PendingResult<Status> stopApplication(GoogleApiClient client) {
                return client.m140b(new C11888(this));
            }

            public PendingResult<Status> stopApplication(GoogleApiClient client, String sessionId) {
                return client.m140b(new C11899(this, sessionId));
            }
        }

        ApplicationMetadata getApplicationMetadata(GoogleApiClient googleApiClient) throws IllegalStateException;

        String getApplicationStatus(GoogleApiClient googleApiClient) throws IllegalStateException;

        double getVolume(GoogleApiClient googleApiClient) throws IllegalStateException;

        boolean isMute(GoogleApiClient googleApiClient) throws IllegalStateException;

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient);

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str);

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str, String str2);

        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str);

        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, LaunchOptions launchOptions);

        @Deprecated
        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, boolean z);

        PendingResult<Status> leaveApplication(GoogleApiClient googleApiClient);

        void removeMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str) throws IOException, IllegalArgumentException;

        void requestStatus(GoogleApiClient googleApiClient) throws IOException, IllegalStateException;

        PendingResult<Status> sendMessage(GoogleApiClient googleApiClient, String str, String str2);

        void setMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str, MessageReceivedCallback messageReceivedCallback) throws IOException, IllegalStateException;

        void setMute(GoogleApiClient googleApiClient, boolean z) throws IOException, IllegalStateException;

        void setVolume(GoogleApiClient googleApiClient, double d) throws IOException, IllegalArgumentException, IllegalStateException;

        PendingResult<Status> stopApplication(GoogleApiClient googleApiClient);

        PendingResult<Status> stopApplication(GoogleApiClient googleApiClient, String str);
    }

    public static class Listener {
        public void m90O(int i) {
        }

        public void onApplicationDisconnected(int statusCode) {
        }

        public void onApplicationStatusChanged() {
        }

        public void onVolumeChanged() {
        }
    }

    public interface MessageReceivedCallback {
        void onMessageReceived(CastDevice castDevice, String str, String str2);
    }

    /* renamed from: com.google.android.gms.cast.Cast.1 */
    static class C04941 implements C0048b<gi, CastOptions> {
        C04941() {
        }

        public gi m1970a(Context context, Looper looper, gz gzVar, CastOptions castOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            hn.m1226b((Object) castOptions, (Object) "Setting the API options is required.");
            return new gi(context, looper, castOptions.zX, (long) castOptions.zZ, castOptions.zY, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    public interface ApplicationConnectionResult extends Result {
        ApplicationMetadata getApplicationMetadata();

        String getApplicationStatus();

        String getSessionId();

        boolean getWasLaunched();
    }

    public static final class CastOptions implements HasOptions {
        final CastDevice zX;
        final Listener zY;
        private final int zZ;

        public static final class Builder {
            CastDevice Aa;
            Listener Ab;
            private int Ac;

            private Builder(CastDevice castDevice, Listener castListener) {
                hn.m1226b((Object) castDevice, (Object) "CastDevice parameter cannot be null");
                hn.m1226b((Object) castListener, (Object) "CastListener parameter cannot be null");
                this.Aa = castDevice;
                this.Ab = castListener;
                this.Ac = 0;
            }

            public CastOptions build() {
                return new CastOptions();
            }

            public Builder setVerboseLoggingEnabled(boolean enabled) {
                if (enabled) {
                    this.Ac |= 1;
                } else {
                    this.Ac &= -2;
                }
                return this;
            }
        }

        private CastOptions(Builder builder) {
            this.zX = builder.Aa;
            this.zY = builder.Ab;
            this.zZ = builder.Ac;
        }

        public static Builder builder(CastDevice castDevice, Listener castListener) {
            return new Builder(castListener, null);
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.a */
    protected static abstract class C1062a<R extends Result> extends C0903b<R, gi> {
        public C1062a() {
            super(Cast.yE);
        }

        public void m3888N(int i) {
            m1988b(m1989c(new Status(i)));
        }

        public void m3889c(int i, String str) {
            m1988b(m1989c(new Status(i, str, null)));
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.b */
    private static abstract class C1118b extends C1062a<Status> {
        private C1118b() {
        }

        public /* synthetic */ Result m4103c(Status status) {
            return m4104d(status);
        }

        public Status m4104d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.c */
    private static abstract class C1119c extends C1062a<ApplicationConnectionResult> {

        /* renamed from: com.google.android.gms.cast.Cast.c.1 */
        class C08991 implements ApplicationConnectionResult {
            final /* synthetic */ C1119c Ad;
            final /* synthetic */ Status yG;

            C08991(C1119c c1119c, Status status) {
                this.Ad = c1119c;
                this.yG = status;
            }

            public ApplicationMetadata getApplicationMetadata() {
                return null;
            }

            public String getApplicationStatus() {
                return null;
            }

            public String getSessionId() {
                return null;
            }

            public Status getStatus() {
                return this.yG;
            }

            public boolean getWasLaunched() {
                return false;
            }
        }

        private C1119c() {
        }

        public /* synthetic */ Result m4105c(Status status) {
            return m4106j(status);
        }

        public ApplicationConnectionResult m4106j(Status status) {
            return new C08991(this, status);
        }
    }

    static {
        yE = new C0049c();
        yF = new C04941();
        API = new Api(yF, yE, new Scope[0]);
        CastApi = new C0495a();
    }

    private Cast() {
    }
}
