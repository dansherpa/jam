package com.google.android.gms.cast;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.accessibility.CaptioningManager;
import android.view.accessibility.CaptioningManager.CaptionStyle;
import com.google.android.gms.internal.gj;
import com.google.android.gms.internal.hl;
import com.google.android.gms.internal.io;
import com.google.android.gms.internal.iq;
import org.json.JSONException;
import org.json.JSONObject;

public final class TextTrackStyle {
    public static final int COLOR_UNSPECIFIED = 0;
    public static final float DEFAULT_FONT_SCALE = 1.0f;
    public static final int EDGE_TYPE_DEPRESSED = 4;
    public static final int EDGE_TYPE_DROP_SHADOW = 2;
    public static final int EDGE_TYPE_NONE = 0;
    public static final int EDGE_TYPE_OUTLINE = 1;
    public static final int EDGE_TYPE_RAISED = 3;
    public static final int EDGE_TYPE_UNSPECIFIED = -1;
    public static final int FONT_FAMILY_CASUAL = 4;
    public static final int FONT_FAMILY_CURSIVE = 5;
    public static final int FONT_FAMILY_MONOSPACED_SANS_SERIF = 1;
    public static final int FONT_FAMILY_MONOSPACED_SERIF = 3;
    public static final int FONT_FAMILY_SANS_SERIF = 0;
    public static final int FONT_FAMILY_SERIF = 2;
    public static final int FONT_FAMILY_SMALL_CAPITALS = 6;
    public static final int FONT_FAMILY_UNSPECIFIED = -1;
    public static final int FONT_STYLE_BOLD = 1;
    public static final int FONT_STYLE_BOLD_ITALIC = 3;
    public static final int FONT_STYLE_ITALIC = 2;
    public static final int FONT_STYLE_NORMAL = 0;
    public static final int FONT_STYLE_UNSPECIFIED = -1;
    public static final int WINDOW_TYPE_NONE = 0;
    public static final int WINDOW_TYPE_NORMAL = 1;
    public static final int WINDOW_TYPE_ROUNDED = 2;
    public static final int WINDOW_TYPE_UNSPECIFIED = -1;
    private JSONObject Ax;
    private float Bp;
    private int Bq;
    private int Br;
    private int Bs;
    private int Bt;
    private int Bu;
    private int Bv;
    private String Bw;
    private int Bx;
    private int By;
    private int ta;

    public TextTrackStyle() {
        clear();
    }

    private int ah(String str) {
        int i = WINDOW_TYPE_NONE;
        if (str != null && str.length() == 9 && str.charAt(i) == '#') {
            try {
                i = Color.argb(Integer.parseInt(str.substring(7, 9), 16), Integer.parseInt(str.substring(WINDOW_TYPE_NORMAL, FONT_STYLE_BOLD_ITALIC), 16), Integer.parseInt(str.substring(FONT_STYLE_BOLD_ITALIC, FONT_FAMILY_CURSIVE), 16), Integer.parseInt(str.substring(FONT_FAMILY_CURSIVE, 7), 16));
            } catch (NumberFormatException e) {
            }
        }
        return i;
    }

    private void clear() {
        this.Bp = DEFAULT_FONT_SCALE;
        this.Bq = WINDOW_TYPE_NONE;
        this.ta = WINDOW_TYPE_NONE;
        this.Br = WINDOW_TYPE_UNSPECIFIED;
        this.Bs = WINDOW_TYPE_NONE;
        this.Bt = WINDOW_TYPE_UNSPECIFIED;
        this.Bu = WINDOW_TYPE_NONE;
        this.Bv = WINDOW_TYPE_NONE;
        this.Bw = null;
        this.Bx = WINDOW_TYPE_UNSPECIFIED;
        this.By = WINDOW_TYPE_UNSPECIFIED;
        this.Ax = null;
    }

    public static TextTrackStyle fromSystemSettings(Context context) {
        TextTrackStyle textTrackStyle = new TextTrackStyle();
        if (!iq.gd()) {
            return textTrackStyle;
        }
        CaptioningManager captioningManager = (CaptioningManager) context.getSystemService("captioning");
        textTrackStyle.setFontScale(captioningManager.getFontScale());
        CaptionStyle userStyle = captioningManager.getUserStyle();
        textTrackStyle.setBackgroundColor(userStyle.backgroundColor);
        textTrackStyle.setForegroundColor(userStyle.foregroundColor);
        switch (userStyle.edgeType) {
            case WINDOW_TYPE_NORMAL /*1*/:
                textTrackStyle.setEdgeType(WINDOW_TYPE_NORMAL);
                break;
            case WINDOW_TYPE_ROUNDED /*2*/:
                textTrackStyle.setEdgeType(WINDOW_TYPE_ROUNDED);
                break;
            default:
                textTrackStyle.setEdgeType(WINDOW_TYPE_NONE);
                break;
        }
        textTrackStyle.setEdgeColor(userStyle.edgeColor);
        Typeface typeface = userStyle.getTypeface();
        if (typeface != null) {
            if (Typeface.MONOSPACE.equals(typeface)) {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_NORMAL);
            } else if (Typeface.SANS_SERIF.equals(typeface)) {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_NONE);
            } else if (Typeface.SERIF.equals(typeface)) {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_ROUNDED);
            } else {
                textTrackStyle.setFontGenericFamily(WINDOW_TYPE_NONE);
            }
            boolean isBold = typeface.isBold();
            boolean isItalic = typeface.isItalic();
            if (isBold && isItalic) {
                textTrackStyle.setFontStyle(FONT_STYLE_BOLD_ITALIC);
            } else if (isBold) {
                textTrackStyle.setFontStyle(WINDOW_TYPE_NORMAL);
            } else if (isItalic) {
                textTrackStyle.setFontStyle(WINDOW_TYPE_ROUNDED);
            } else {
                textTrackStyle.setFontStyle(WINDOW_TYPE_NONE);
            }
        }
        return textTrackStyle;
    }

    private String m104o(int i) {
        Object[] objArr = new Object[FONT_FAMILY_CASUAL];
        objArr[WINDOW_TYPE_NONE] = Integer.valueOf(Color.red(i));
        objArr[WINDOW_TYPE_NORMAL] = Integer.valueOf(Color.green(i));
        objArr[WINDOW_TYPE_ROUNDED] = Integer.valueOf(Color.blue(i));
        objArr[FONT_STYLE_BOLD_ITALIC] = Integer.valueOf(Color.alpha(i));
        return String.format("#%02X%02X%02X%02X", objArr);
    }

    public void m105b(JSONObject jSONObject) throws JSONException {
        String string;
        clear();
        this.Bp = (float) jSONObject.optDouble("fontScale", 1.0d);
        this.Bq = ah(jSONObject.optString("foregroundColor"));
        this.ta = ah(jSONObject.optString("backgroundColor"));
        if (jSONObject.has("edgeType")) {
            string = jSONObject.getString("edgeType");
            if ("NONE".equals(string)) {
                this.Br = WINDOW_TYPE_NONE;
            } else if ("OUTLINE".equals(string)) {
                this.Br = WINDOW_TYPE_NORMAL;
            } else if ("DROP_SHADOW".equals(string)) {
                this.Br = WINDOW_TYPE_ROUNDED;
            } else if ("RAISED".equals(string)) {
                this.Br = FONT_STYLE_BOLD_ITALIC;
            } else if ("DEPRESSED".equals(string)) {
                this.Br = FONT_FAMILY_CASUAL;
            }
        }
        this.Bs = ah(jSONObject.optString("edgeColor"));
        if (jSONObject.has("windowType")) {
            string = jSONObject.getString("windowType");
            if ("NONE".equals(string)) {
                this.Bt = WINDOW_TYPE_NONE;
            } else if ("NORMAL".equals(string)) {
                this.Bt = WINDOW_TYPE_NORMAL;
            } else if ("ROUNDED_CORNERS".equals(string)) {
                this.Bt = WINDOW_TYPE_ROUNDED;
            }
        }
        this.Bu = ah(jSONObject.optString("windowColor"));
        if (this.Bt == WINDOW_TYPE_ROUNDED) {
            this.Bv = jSONObject.optInt("windowRoundedCornerRadius", WINDOW_TYPE_NONE);
        }
        this.Bw = jSONObject.optString("fontFamily", null);
        if (jSONObject.has("fontGenericFamily")) {
            string = jSONObject.getString("fontGenericFamily");
            if ("SANS_SERIF".equals(string)) {
                this.Bx = WINDOW_TYPE_NONE;
            } else if ("MONOSPACED_SANS_SERIF".equals(string)) {
                this.Bx = WINDOW_TYPE_NORMAL;
            } else if ("SERIF".equals(string)) {
                this.Bx = WINDOW_TYPE_ROUNDED;
            } else if ("MONOSPACED_SERIF".equals(string)) {
                this.Bx = FONT_STYLE_BOLD_ITALIC;
            } else if ("CASUAL".equals(string)) {
                this.Bx = FONT_FAMILY_CASUAL;
            } else if ("CURSIVE".equals(string)) {
                this.Bx = FONT_FAMILY_CURSIVE;
            } else if ("SMALL_CAPITALS".equals(string)) {
                this.Bx = FONT_FAMILY_SMALL_CAPITALS;
            }
        }
        if (jSONObject.has("fontStyle")) {
            string = jSONObject.getString("fontStyle");
            if ("NORMAL".equals(string)) {
                this.By = WINDOW_TYPE_NONE;
            } else if ("BOLD".equals(string)) {
                this.By = WINDOW_TYPE_NORMAL;
            } else if ("ITALIC".equals(string)) {
                this.By = WINDOW_TYPE_ROUNDED;
            } else if ("BOLD_ITALIC".equals(string)) {
                this.By = FONT_STYLE_BOLD_ITALIC;
            }
        }
        this.Ax = jSONObject.optJSONObject("customData");
    }

    public JSONObject dU() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("fontScale", (double) this.Bp);
            if (this.Bq != 0) {
                jSONObject.put("foregroundColor", m104o(this.Bq));
            }
            if (this.ta != 0) {
                jSONObject.put("backgroundColor", m104o(this.ta));
            }
            switch (this.Br) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("edgeType", "NONE");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("edgeType", "OUTLINE");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("edgeType", "DROP_SHADOW");
                    break;
                case FONT_STYLE_BOLD_ITALIC /*3*/:
                    jSONObject.put("edgeType", "RAISED");
                    break;
                case FONT_FAMILY_CASUAL /*4*/:
                    jSONObject.put("edgeType", "DEPRESSED");
                    break;
            }
            if (this.Bs != 0) {
                jSONObject.put("edgeColor", m104o(this.Bs));
            }
            switch (this.Bt) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("windowType", "NONE");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("windowType", "NORMAL");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("windowType", "ROUNDED_CORNERS");
                    break;
            }
            if (this.Bu != 0) {
                jSONObject.put("windowColor", m104o(this.Bu));
            }
            if (this.Bt == WINDOW_TYPE_ROUNDED) {
                jSONObject.put("windowRoundedCornerRadius", this.Bv);
            }
            if (this.Bw != null) {
                jSONObject.put("fontFamily", this.Bw);
            }
            switch (this.Bx) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("fontGenericFamily", "SANS_SERIF");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("fontGenericFamily", "MONOSPACED_SANS_SERIF");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("fontGenericFamily", "SERIF");
                    break;
                case FONT_STYLE_BOLD_ITALIC /*3*/:
                    jSONObject.put("fontGenericFamily", "MONOSPACED_SERIF");
                    break;
                case FONT_FAMILY_CASUAL /*4*/:
                    jSONObject.put("fontGenericFamily", "CASUAL");
                    break;
                case FONT_FAMILY_CURSIVE /*5*/:
                    jSONObject.put("fontGenericFamily", "CURSIVE");
                    break;
                case FONT_FAMILY_SMALL_CAPITALS /*6*/:
                    jSONObject.put("fontGenericFamily", "SMALL_CAPITALS");
                    break;
            }
            switch (this.By) {
                case WINDOW_TYPE_NONE /*0*/:
                    jSONObject.put("fontStyle", "NORMAL");
                    break;
                case WINDOW_TYPE_NORMAL /*1*/:
                    jSONObject.put("fontStyle", "BOLD");
                    break;
                case WINDOW_TYPE_ROUNDED /*2*/:
                    jSONObject.put("fontStyle", "ITALIC");
                    break;
                case FONT_STYLE_BOLD_ITALIC /*3*/:
                    jSONObject.put("fontStyle", "BOLD_ITALIC");
                    break;
            }
            if (this.Ax != null) {
                jSONObject.put("customData", this.Ax);
            }
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public boolean equals(Object other) {
        boolean z = true;
        if (this == other) {
            return true;
        }
        if (!(other instanceof TextTrackStyle)) {
            return false;
        }
        TextTrackStyle textTrackStyle = (TextTrackStyle) other;
        if ((this.Ax == null ? WINDOW_TYPE_NORMAL : false) != (textTrackStyle.Ax == null ? WINDOW_TYPE_NORMAL : false)) {
            return false;
        }
        if (this.Ax != null && textTrackStyle.Ax != null && !io.m1274d(this.Ax, textTrackStyle.Ax)) {
            return false;
        }
        if (!(this.Bp == textTrackStyle.Bp && this.Bq == textTrackStyle.Bq && this.ta == textTrackStyle.ta && this.Br == textTrackStyle.Br && this.Bs == textTrackStyle.Bs && this.Bt == textTrackStyle.Bt && this.Bv == textTrackStyle.Bv && gj.m1104a(this.Bw, textTrackStyle.Bw) && this.Bx == textTrackStyle.Bx && this.By == textTrackStyle.By)) {
            z = false;
        }
        return z;
    }

    public int getBackgroundColor() {
        return this.ta;
    }

    public JSONObject getCustomData() {
        return this.Ax;
    }

    public int getEdgeColor() {
        return this.Bs;
    }

    public int getEdgeType() {
        return this.Br;
    }

    public String getFontFamily() {
        return this.Bw;
    }

    public int getFontGenericFamily() {
        return this.Bx;
    }

    public float getFontScale() {
        return this.Bp;
    }

    public int getFontStyle() {
        return this.By;
    }

    public int getForegroundColor() {
        return this.Bq;
    }

    public int getWindowColor() {
        return this.Bu;
    }

    public int getWindowCornerRadius() {
        return this.Bv;
    }

    public int getWindowType() {
        return this.Bt;
    }

    public int hashCode() {
        return hl.hashCode(Float.valueOf(this.Bp), Integer.valueOf(this.Bq), Integer.valueOf(this.ta), Integer.valueOf(this.Br), Integer.valueOf(this.Bs), Integer.valueOf(this.Bt), Integer.valueOf(this.Bu), Integer.valueOf(this.Bv), this.Bw, Integer.valueOf(this.Bx), Integer.valueOf(this.By), this.Ax);
    }

    public void setBackgroundColor(int backgroundColor) {
        this.ta = backgroundColor;
    }

    public void setCustomData(JSONObject customData) {
        this.Ax = customData;
    }

    public void setEdgeColor(int edgeColor) {
        this.Bs = edgeColor;
    }

    public void setEdgeType(int edgeType) {
        if (edgeType < 0 || edgeType > FONT_FAMILY_CASUAL) {
            throw new IllegalArgumentException("invalid edgeType");
        }
        this.Br = edgeType;
    }

    public void setFontFamily(String fontFamily) {
        this.Bw = fontFamily;
    }

    public void setFontGenericFamily(int fontGenericFamily) {
        if (fontGenericFamily < 0 || fontGenericFamily > FONT_FAMILY_SMALL_CAPITALS) {
            throw new IllegalArgumentException("invalid fontGenericFamily");
        }
        this.Bx = fontGenericFamily;
    }

    public void setFontScale(float fontScale) {
        this.Bp = fontScale;
    }

    public void setFontStyle(int fontStyle) {
        if (fontStyle < 0 || fontStyle > FONT_STYLE_BOLD_ITALIC) {
            throw new IllegalArgumentException("invalid fontStyle");
        }
        this.By = fontStyle;
    }

    public void setForegroundColor(int foregroundColor) {
        this.Bq = foregroundColor;
    }

    public void setWindowColor(int windowColor) {
        this.Bu = windowColor;
    }

    public void setWindowCornerRadius(int windowCornerRadius) {
        if (windowCornerRadius < 0) {
            throw new IllegalArgumentException("invalid windowCornerRadius");
        }
        this.Bv = windowCornerRadius;
    }

    public void setWindowType(int windowType) {
        if (windowType < 0 || windowType > WINDOW_TYPE_ROUNDED) {
            throw new IllegalArgumentException("invalid windowType");
        }
        this.Bt = windowType;
    }
}
