package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.gj;
import com.google.android.gms.internal.hl;
import java.util.ArrayList;
import java.util.List;

public final class ApplicationMetadata implements SafeParcelable {
    public static final Creator<ApplicationMetadata> CREATOR;
    String mName;
    private final int xJ;
    String zM;
    List<WebImage> zN;
    List<String> zO;
    String zP;
    Uri zQ;

    static {
        CREATOR = new C0043a();
    }

    private ApplicationMetadata() {
        this.xJ = 1;
        this.zN = new ArrayList();
        this.zO = new ArrayList();
    }

    ApplicationMetadata(int versionCode, String applicationId, String name, List<WebImage> images, List<String> namespaces, String senderAppIdentifier, Uri senderAppLaunchUrl) {
        this.xJ = versionCode;
        this.zM = applicationId;
        this.mName = name;
        this.zN = images;
        this.zO = namespaces;
        this.zP = senderAppIdentifier;
        this.zQ = senderAppLaunchUrl;
    }

    public boolean areNamespacesSupported(List<String> namespaces) {
        return this.zO != null && this.zO.containsAll(namespaces);
    }

    public Uri dS() {
        return this.zQ;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ApplicationMetadata)) {
            return false;
        }
        ApplicationMetadata applicationMetadata = (ApplicationMetadata) obj;
        return gj.m1104a(this.zM, applicationMetadata.zM) && gj.m1104a(this.zN, applicationMetadata.zN) && gj.m1104a(this.mName, applicationMetadata.mName) && gj.m1104a(this.zO, applicationMetadata.zO) && gj.m1104a(this.zP, applicationMetadata.zP) && gj.m1104a(this.zQ, applicationMetadata.zQ);
    }

    public String getApplicationId() {
        return this.zM;
    }

    public List<WebImage> getImages() {
        return this.zN;
    }

    public String getName() {
        return this.mName;
    }

    public String getSenderAppIdentifier() {
        return this.zP;
    }

    int getVersionCode() {
        return this.xJ;
    }

    public int hashCode() {
        return hl.hashCode(Integer.valueOf(this.xJ), this.zM, this.mName, this.zN, this.zO, this.zP, this.zQ);
    }

    public boolean isNamespaceSupported(String namespace) {
        return this.zO != null && this.zO.contains(namespace);
    }

    public String toString() {
        return this.mName;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0043a.m106a(this, out, flags);
    }
}
