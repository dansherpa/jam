package com.google.android.gms.internal;

import com.google.android.gms.wallet.wobs.C0428r;

public class lv implements C0428r {
}
