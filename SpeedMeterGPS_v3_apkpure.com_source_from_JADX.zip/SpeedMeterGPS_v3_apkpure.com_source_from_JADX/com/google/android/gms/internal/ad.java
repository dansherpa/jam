package com.google.android.gms.internal;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.ViewTreeObserver.OnScrollChangedListener;
import android.view.WindowManager;
import com.google.android.gms.internal.af.C0170a;
import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class ad implements OnGlobalLayoutListener, OnScrollChangedListener {
    private static final long lE;
    private final WindowManager lA;
    private final PowerManager lB;
    private final KeyguardManager lC;
    private ae lD;
    private boolean lF;
    private long lG;
    private boolean lH;
    private BroadcastReceiver lI;
    private HashSet<aa> lJ;
    private boolean lh;
    private final Object lq;
    private final WeakReference<eg> lt;
    private WeakReference<ViewTreeObserver> lu;
    private final WeakReference<View> lv;
    private final ab lw;
    private final Context lx;
    private final af ly;
    private boolean lz;

    /* renamed from: com.google.android.gms.internal.ad.2 */
    class C01692 extends BroadcastReceiver {
        final /* synthetic */ ad lK;

        C01692(ad adVar) {
            this.lK = adVar;
        }

        public void onReceive(Context context, Intent intent) {
            this.lK.m767e(false);
        }
    }

    /* renamed from: com.google.android.gms.internal.ad.1 */
    class C05651 implements C0170a {
        final /* synthetic */ ad lK;

        C05651(ad adVar) {
            this.lK = adVar;
        }

        public void az() {
            this.lK.lz = true;
            this.lK.m767e(false);
            this.lK.aq();
        }
    }

    /* renamed from: com.google.android.gms.internal.ad.3 */
    class C05663 implements bd {
        final /* synthetic */ ad lK;

        C05663(ad adVar) {
            this.lK = adVar;
        }

        public void m2445b(ey eyVar, Map<String, String> map) {
            this.lK.m760a(eyVar, (Map) map);
        }
    }

    /* renamed from: com.google.android.gms.internal.ad.4 */
    class C05674 implements bd {
        final /* synthetic */ ad lK;

        C05674(ad adVar) {
            this.lK = adVar;
        }

        public void m2446b(ey eyVar, Map<String, String> map) {
            if (map.containsKey("pingType") && "unloadPing".equals(map.get("pingType"))) {
                this.lK.m765c(this.lK.ly);
                ev.m1011B("Unregistered GMSG handlers for: " + this.lK.lw.ap());
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.ad.5 */
    class C05685 implements bd {
        final /* synthetic */ ad lK;

        C05685(ad adVar) {
            this.lK = adVar;
        }

        public void m2447b(ey eyVar, Map<String, String> map) {
            if (map.containsKey("isVisible")) {
                boolean z = "1".equals(map.get("isVisible")) || "true".equals(map.get("isVisible"));
                this.lK.m766d(Boolean.valueOf(z).booleanValue());
            }
        }
    }

    static {
        lE = TimeUnit.MILLISECONDS.toNanos(100);
    }

    public ad(am amVar, eg egVar) {
        this(amVar, egVar, egVar.ow.bY(), egVar.ow, new ag(egVar.ow.getContext(), egVar.ow.bY()));
    }

    public ad(am amVar, eg egVar, ew ewVar, View view, af afVar) {
        this.lq = new Object();
        this.lh = false;
        this.lF = false;
        this.lG = Long.MIN_VALUE;
        this.lJ = new HashSet();
        this.lt = new WeakReference(egVar);
        this.lv = new WeakReference(view);
        this.lu = new WeakReference(null);
        this.lH = true;
        this.lw = new ab(Integer.toString(egVar.hashCode()), ewVar, amVar.mc, egVar.rv);
        this.ly = afVar;
        this.lA = (WindowManager) view.getContext().getSystemService("window");
        this.lB = (PowerManager) view.getContext().getApplicationContext().getSystemService("power");
        this.lC = (KeyguardManager) view.getContext().getSystemService("keyguard");
        this.lx = view.getContext().getApplicationContext();
        m759a(afVar);
        this.ly.m769a(new C05651(this));
        m763b(this.ly);
        ev.m1011B("Tracking ad unit: " + this.lw.ap());
    }

    protected int m756a(int i, DisplayMetrics displayMetrics) {
        return (int) (((float) i) / displayMetrics.density);
    }

    public void m757a(aa aaVar) {
        this.lJ.add(aaVar);
    }

    public void m758a(ae aeVar) {
        synchronized (this.lq) {
            this.lD = aeVar;
        }
    }

    protected void m759a(af afVar) {
        afVar.m772d("http://googleads.g.doubleclick.net/mads/static/sdk/native/sdk-core-v40.html");
    }

    protected void m760a(ey eyVar, Map<String, String> map) {
        m767e(false);
    }

    protected void m761a(JSONObject jSONObject) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        JSONObject jSONObject2 = new JSONObject();
        jSONArray.put(jSONObject);
        jSONObject2.put("units", jSONArray);
        this.ly.m771a("AFMA_updateActiveView", jSONObject2);
    }

    protected boolean m762a(View view, boolean z) {
        return view.getVisibility() == 0 && z && view.isShown() && this.lB.isScreenOn() && !this.lC.inKeyguardRestrictedInputMode();
    }

    protected void aq() {
        synchronized (this.lq) {
            if (this.lI != null) {
                return;
            }
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.SCREEN_ON");
            intentFilter.addAction("android.intent.action.SCREEN_OFF");
            this.lI = new C01692(this);
            this.lx.registerReceiver(this.lI, intentFilter);
        }
    }

    protected void ar() {
        synchronized (this.lq) {
            if (this.lI != null) {
                this.lx.unregisterReceiver(this.lI);
                this.lI = null;
            }
        }
    }

    public void as() {
        synchronized (this.lq) {
            if (this.lH) {
                aw();
                ar();
                try {
                    m761a(ay());
                } catch (Throwable e) {
                    ev.m1015b("JSON Failure while processing active view data.", e);
                }
                this.lH = false;
                at();
                ev.m1011B("Untracked ad unit: " + this.lw.ap());
            }
        }
    }

    protected void at() {
        if (this.lD != null) {
            this.lD.m768a(this);
        }
    }

    public boolean au() {
        boolean z;
        synchronized (this.lq) {
            z = this.lH;
        }
        return z;
    }

    protected void av() {
        View view = (View) this.lv.get();
        if (view != null) {
            ViewTreeObserver viewTreeObserver = (ViewTreeObserver) this.lu.get();
            ViewTreeObserver viewTreeObserver2 = view.getViewTreeObserver();
            if (viewTreeObserver2 != viewTreeObserver) {
                this.lu = new WeakReference(viewTreeObserver2);
                viewTreeObserver2.addOnScrollChangedListener(this);
                viewTreeObserver2.addOnGlobalLayoutListener(this);
            }
        }
    }

    protected void aw() {
        ViewTreeObserver viewTreeObserver = (ViewTreeObserver) this.lu.get();
        if (viewTreeObserver != null && viewTreeObserver.isAlive()) {
            viewTreeObserver.removeOnScrollChangedListener(this);
            viewTreeObserver.removeGlobalOnLayoutListener(this);
        }
    }

    protected JSONObject ax() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("afmaVersion", this.lw.an()).put("activeViewJSON", this.lw.ao()).put("timestamp", TimeUnit.NANOSECONDS.toMillis(System.nanoTime())).put("adFormat", this.lw.am()).put("hashCode", this.lw.ap());
        return jSONObject;
    }

    protected JSONObject ay() throws JSONException {
        JSONObject ax = ax();
        ax.put("doneReasonCode", "u");
        return ax;
    }

    protected void m763b(af afVar) {
        afVar.m770a("/updateActiveView", new C05663(this));
        afVar.m770a("/activeViewPingSent", new C05674(this));
        afVar.m770a("/visibilityChanged", new C05685(this));
        afVar.m770a("/viewabilityChanged", bc.mR);
    }

    protected JSONObject m764c(View view) throws JSONException {
        int[] iArr = new int[2];
        int[] iArr2 = new int[2];
        view.getLocationOnScreen(iArr);
        view.getLocationInWindow(iArr2);
        JSONObject ax = ax();
        DisplayMetrics displayMetrics = view.getContext().getResources().getDisplayMetrics();
        Rect rect = new Rect();
        rect.left = iArr[0];
        rect.top = iArr[1];
        rect.right = rect.left + view.getWidth();
        rect.bottom = rect.top + view.getHeight();
        Rect rect2 = new Rect();
        rect2.right = this.lA.getDefaultDisplay().getWidth();
        rect2.bottom = this.lA.getDefaultDisplay().getHeight();
        Rect rect3 = new Rect();
        boolean globalVisibleRect = view.getGlobalVisibleRect(rect3, null);
        Rect rect4 = new Rect();
        view.getLocalVisibleRect(rect4);
        ax.put("viewBox", new JSONObject().put("top", m756a(rect2.top, displayMetrics)).put("bottom", m756a(rect2.bottom, displayMetrics)).put("left", m756a(rect2.left, displayMetrics)).put("right", m756a(rect2.right, displayMetrics))).put("adBox", new JSONObject().put("top", m756a(rect.top, displayMetrics)).put("bottom", m756a(rect.bottom, displayMetrics)).put("left", m756a(rect.left, displayMetrics)).put("right", m756a(rect.right, displayMetrics))).put("globalVisibleBox", new JSONObject().put("top", m756a(rect3.top, displayMetrics)).put("bottom", m756a(rect3.bottom, displayMetrics)).put("left", m756a(rect3.left, displayMetrics)).put("right", m756a(rect3.right, displayMetrics))).put("localVisibleBox", new JSONObject().put("top", m756a(rect4.top, displayMetrics)).put("bottom", m756a(rect4.bottom, displayMetrics)).put("left", m756a(rect4.left, displayMetrics)).put("right", m756a(rect4.right, displayMetrics))).put("screenDensity", (double) displayMetrics.density).put("isVisible", m762a(view, globalVisibleRect)).put("isStopped", this.lF).put("isPaused", this.lh);
        return ax;
    }

    protected void m765c(af afVar) {
        afVar.m773e("/viewabilityChanged");
        afVar.m773e("/visibilityChanged");
        afVar.m773e("/activeViewPingSent");
        afVar.m773e("/updateActiveView");
    }

    protected void m766d(boolean z) {
        Iterator it = this.lJ.iterator();
        while (it.hasNext()) {
            ((aa) it.next()).m752a(this, z);
        }
    }

    protected void m767e(boolean z) {
        synchronized (this.lq) {
            if (this.lz && this.lH) {
                long nanoTime = System.nanoTime();
                if (!z || this.lG + lE <= nanoTime) {
                    this.lG = nanoTime;
                    View view = (View) this.lv.get();
                    Object obj = (view == null || ((eg) this.lt.get()) == null) ? 1 : null;
                    if (obj != null) {
                        as();
                        return;
                    }
                    try {
                        m761a(m764c(view));
                    } catch (Throwable e) {
                        ev.m1015b("Active view update failed.", e);
                    }
                    av();
                    at();
                    return;
                }
                return;
            }
        }
    }

    public void onGlobalLayout() {
        m767e(false);
    }

    public void onScrollChanged() {
        m767e(true);
    }

    public void pause() {
        synchronized (this.lq) {
            this.lh = true;
            m767e(false);
            this.ly.pause();
        }
    }

    public void resume() {
        synchronized (this.lq) {
            this.ly.resume();
            this.lh = false;
            m767e(false);
        }
    }

    public void stop() {
        synchronized (this.lq) {
            this.lF = true;
            m767e(false);
            this.ly.pause();
        }
    }
}
