package com.google.android.gms.internal;

import android.accounts.Account;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.hc.C0993e;
import com.google.android.gms.internal.ln.C0687a;
import com.google.android.gms.internal.lq.C0693a;
import com.google.android.gms.wallet.FullWallet;
import com.google.android.gms.wallet.FullWalletRequest;
import com.google.android.gms.wallet.MaskedWallet;
import com.google.android.gms.wallet.MaskedWalletRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest;
import com.google.android.gms.wallet.WalletConstants;

public class ls extends hc<ln> {
    private final int ajY;
    private final int mTheme;
    private final Activity oe;
    private final String yN;

    /* renamed from: com.google.android.gms.internal.ls.a */
    private static class C1016a extends C0693a {
        private C1016a() {
        }

        public void m3705a(int i, FullWallet fullWallet, Bundle bundle) {
        }

        public void m3706a(int i, MaskedWallet maskedWallet, Bundle bundle) {
        }

        public void m3707a(int i, boolean z, Bundle bundle) {
        }

        public void m3708a(Status status, lj ljVar, Bundle bundle) {
        }

        public void m3709i(int i, Bundle bundle) {
        }
    }

    /* renamed from: com.google.android.gms.internal.ls.b */
    final class C1093b extends C1016a {
        private final int FT;
        final /* synthetic */ ls akJ;

        public C1093b(ls lsVar, int i) {
            this.akJ = lsVar;
            super();
            this.FT = i;
        }

        public void m4063a(int i, FullWallet fullWallet, Bundle bundle) {
            PendingIntent pendingIntent = null;
            if (bundle != null) {
                pendingIntent = (PendingIntent) bundle.getParcelable("com.google.android.gms.wallet.EXTRA_PENDING_INTENT");
            }
            ConnectionResult connectionResult = new ConnectionResult(i, pendingIntent);
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(this.akJ.oe, this.FT);
                    return;
                } catch (Throwable e) {
                    Log.w("WalletClientImpl", "Exception starting pending intent", e);
                    return;
                }
            }
            int i2;
            Intent intent = new Intent();
            if (connectionResult.isSuccess()) {
                i2 = -1;
                intent.putExtra(WalletConstants.EXTRA_FULL_WALLET, fullWallet);
            } else {
                i2 = i == 408 ? 0 : 1;
                intent.putExtra(WalletConstants.EXTRA_ERROR_CODE, i);
            }
            PendingIntent createPendingResult = this.akJ.oe.createPendingResult(this.FT, intent, 1073741824);
            if (createPendingResult == null) {
                Log.w("WalletClientImpl", "Null pending result returned for onFullWalletLoaded");
                return;
            }
            try {
                createPendingResult.send(i2);
            } catch (Throwable e2) {
                Log.w("WalletClientImpl", "Exception setting pending result", e2);
            }
        }

        public void m4064a(int i, MaskedWallet maskedWallet, Bundle bundle) {
            PendingIntent pendingIntent = null;
            if (bundle != null) {
                pendingIntent = (PendingIntent) bundle.getParcelable("com.google.android.gms.wallet.EXTRA_PENDING_INTENT");
            }
            ConnectionResult connectionResult = new ConnectionResult(i, pendingIntent);
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(this.akJ.oe, this.FT);
                    return;
                } catch (Throwable e) {
                    Log.w("WalletClientImpl", "Exception starting pending intent", e);
                    return;
                }
            }
            int i2;
            Intent intent = new Intent();
            if (connectionResult.isSuccess()) {
                i2 = -1;
                intent.putExtra(WalletConstants.EXTRA_MASKED_WALLET, maskedWallet);
            } else {
                i2 = i == 408 ? 0 : 1;
                intent.putExtra(WalletConstants.EXTRA_ERROR_CODE, i);
            }
            PendingIntent createPendingResult = this.akJ.oe.createPendingResult(this.FT, intent, 1073741824);
            if (createPendingResult == null) {
                Log.w("WalletClientImpl", "Null pending result returned for onMaskedWalletLoaded");
                return;
            }
            try {
                createPendingResult.send(i2);
            } catch (Throwable e2) {
                Log.w("WalletClientImpl", "Exception setting pending result", e2);
            }
        }

        public void m4065a(int i, boolean z, Bundle bundle) {
            Intent intent = new Intent();
            intent.putExtra(WalletConstants.EXTRA_IS_USER_PREAUTHORIZED, z);
            PendingIntent createPendingResult = this.akJ.oe.createPendingResult(this.FT, intent, 1073741824);
            if (createPendingResult == null) {
                Log.w("WalletClientImpl", "Null pending result returned for onPreAuthorizationDetermined");
                return;
            }
            try {
                createPendingResult.send(-1);
            } catch (Throwable e) {
                Log.w("WalletClientImpl", "Exception setting pending result", e);
            }
        }

        public void m4066i(int i, Bundle bundle) {
            hn.m1226b((Object) bundle, (Object) "Bundle should not be null");
            ConnectionResult connectionResult = new ConnectionResult(i, (PendingIntent) bundle.getParcelable("com.google.android.gms.wallet.EXTRA_PENDING_INTENT"));
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(this.akJ.oe, this.FT);
                    return;
                } catch (Throwable e) {
                    Log.w("WalletClientImpl", "Exception starting pending intent", e);
                    return;
                }
            }
            Log.e("WalletClientImpl", "Create Wallet Objects confirmation UI will not be shown connection result: " + connectionResult);
            Intent intent = new Intent();
            intent.putExtra(WalletConstants.EXTRA_ERROR_CODE, WalletConstants.ERROR_CODE_UNKNOWN);
            PendingIntent createPendingResult = this.akJ.oe.createPendingResult(this.FT, intent, 1073741824);
            if (createPendingResult == null) {
                Log.w("WalletClientImpl", "Null pending result returned for onWalletObjectsCreated");
                return;
            }
            try {
                createPendingResult.send(1);
            } catch (Throwable e2) {
                Log.w("WalletClientImpl", "Exception setting pending result", e2);
            }
        }
    }

    public ls(Activity activity, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, int i, String str, int i2) {
        super(activity, looper, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.oe = activity;
        this.ajY = i;
        this.yN = str;
        this.mTheme = i2;
    }

    public static Bundle m3710a(int i, String str, String str2, int i2) {
        Bundle bundle = new Bundle();
        bundle.putInt("com.google.android.gms.wallet.EXTRA_ENVIRONMENT", i);
        bundle.putString("androidPackageName", str);
        if (!TextUtils.isEmpty(str2)) {
            bundle.putParcelable("com.google.android.gms.wallet.EXTRA_BUYER_ACCOUNT", new Account(str2, GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE));
        }
        bundle.putInt("com.google.android.gms.wallet.EXTRA_THEME", i2);
        return bundle;
    }

    private Bundle nd() {
        return m3710a(this.ajY, this.oe.getPackageName(), this.yN, this.mTheme);
    }

    protected void m3712a(hj hjVar, C0993e c0993e) throws RemoteException {
        hjVar.m1182a(c0993e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE);
    }

    public void m3713a(FullWalletRequest fullWalletRequest, int i) {
        lq c1093b = new C1093b(this, i);
        try {
            ((ln) fo()).m1342a(fullWalletRequest, nd(), c1093b);
        } catch (Throwable e) {
            Log.e("WalletClientImpl", "RemoteException getting full wallet", e);
            c1093b.m4063a(8, null, Bundle.EMPTY);
        }
    }

    public void m3714a(MaskedWalletRequest maskedWalletRequest, int i) {
        Bundle nd = nd();
        lq c1093b = new C1093b(this, i);
        try {
            ((ln) fo()).m1344a(maskedWalletRequest, nd, c1093b);
        } catch (Throwable e) {
            Log.e("WalletClientImpl", "RemoteException getting masked wallet", e);
            c1093b.m4064a(8, null, Bundle.EMPTY);
        }
    }

    public void m3715a(NotifyTransactionStatusRequest notifyTransactionStatusRequest) {
        try {
            ((ln) fo()).m1345a(notifyTransactionStatusRequest, nd());
        } catch (RemoteException e) {
        }
    }

    protected String bp() {
        return "com.google.android.gms.wallet.service.BIND";
    }

    protected String bq() {
        return "com.google.android.gms.wallet.internal.IOwService";
    }

    protected ln bu(IBinder iBinder) {
        return C0687a.bq(iBinder);
    }

    public void m3716d(String str, String str2, int i) {
        Bundle nd = nd();
        Object c1093b = new C1093b(this, i);
        try {
            ((ln) fo()).m1347a(str, str2, nd, c1093b);
        } catch (Throwable e) {
            Log.e("WalletClientImpl", "RemoteException changing masked wallet", e);
            c1093b.m4064a(8, null, Bundle.EMPTY);
        }
    }

    public void dQ(int i) {
        Bundle nd = nd();
        lq c1093b = new C1093b(this, i);
        try {
            ((ln) fo()).m1340a(nd, c1093b);
        } catch (Throwable e) {
            Log.e("WalletClientImpl", "RemoteException during checkForPreAuthorization", e);
            c1093b.m4065a(8, false, Bundle.EMPTY);
        }
    }

    protected /* synthetic */ IInterface m3717x(IBinder iBinder) {
        return bu(iBinder);
    }
}
