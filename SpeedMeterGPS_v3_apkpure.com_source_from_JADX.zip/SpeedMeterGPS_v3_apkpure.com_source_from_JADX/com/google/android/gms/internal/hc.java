package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.Api.C0047a;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.hd.C0248b;
import com.google.android.gms.internal.hi.C0651a;
import com.google.android.gms.internal.hj.C0653a;
import com.google.android.gms.location.DetectedActivity;
import com.mochii.speedmo.C0450R;
import java.util.ArrayList;

public abstract class hc<T extends IInterface> implements C0047a, C0248b {
    public static final String[] Ge;
    private final Looper DC;
    private final hd DP;
    private T FY;
    private final ArrayList<C0245b<?>> FZ;
    private C0246f Ga;
    private volatile int Gb;
    private final String[] Gc;
    boolean Gd;
    private final Context mContext;
    final Handler mHandler;

    /* renamed from: com.google.android.gms.internal.hc.a */
    final class C0244a extends Handler {
        final /* synthetic */ hc Gf;

        public C0244a(hc hcVar, Looper looper) {
            this.Gf = hcVar;
            super(looper);
        }

        public void handleMessage(Message msg) {
            C0245b c0245b;
            if (msg.what == 1 && !this.Gf.isConnecting()) {
                c0245b = (C0245b) msg.obj;
                c0245b.fp();
                c0245b.unregister();
            } else if (msg.what == 3) {
                this.Gf.DP.m1162a(new ConnectionResult(((Integer) msg.obj).intValue(), null));
            } else if (msg.what == 4) {
                this.Gf.am(1);
                this.Gf.FY = null;
                this.Gf.DP.ao(((Integer) msg.obj).intValue());
            } else if (msg.what == 2 && !this.Gf.isConnected()) {
                c0245b = (C0245b) msg.obj;
                c0245b.fp();
                c0245b.unregister();
            } else if (msg.what == 2 || msg.what == 1) {
                ((C0245b) msg.obj).fq();
            } else {
                Log.wtf("GmsClient", "Don't know how to handle this message.");
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.b */
    protected abstract class C0245b<TListener> {
        final /* synthetic */ hc Gf;
        private boolean Gg;
        private TListener mListener;

        public C0245b(hc hcVar, TListener tListener) {
            this.Gf = hcVar;
            this.mListener = tListener;
            this.Gg = false;
        }

        protected abstract void m1159d(TListener tListener);

        protected abstract void fp();

        public void fq() {
            synchronized (this) {
                Object obj = this.mListener;
                if (this.Gg) {
                    Log.w("GmsClient", "Callback proxy " + this + " being reused. This is not safe.");
                }
            }
            if (obj != null) {
                try {
                    m1159d(obj);
                } catch (RuntimeException e) {
                    fp();
                    throw e;
                }
            }
            fp();
            synchronized (this) {
                this.Gg = true;
            }
            unregister();
        }

        public void fr() {
            synchronized (this) {
                this.mListener = null;
            }
        }

        public void unregister() {
            fr();
            synchronized (this.Gf.FZ) {
                this.Gf.FZ.remove(this);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.f */
    final class C0246f implements ServiceConnection {
        final /* synthetic */ hc Gf;

        C0246f(hc hcVar) {
            this.Gf = hcVar;
        }

        public void onServiceConnected(ComponentName component, IBinder binder) {
            this.Gf.m2651I(binder);
        }

        public void onServiceDisconnected(ComponentName component) {
            this.Gf.mHandler.sendMessage(this.Gf.mHandler.obtainMessage(4, Integer.valueOf(1)));
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.c */
    public static final class C0645c implements ConnectionCallbacks {
        private final GooglePlayServicesClient.ConnectionCallbacks Gh;

        public C0645c(GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks) {
            this.Gh = connectionCallbacks;
        }

        public boolean equals(Object other) {
            return other instanceof C0645c ? this.Gh.equals(((C0645c) other).Gh) : this.Gh.equals(other);
        }

        public void onConnected(Bundle connectionHint) {
            this.Gh.onConnected(connectionHint);
        }

        public void onConnectionSuspended(int cause) {
            this.Gh.onDisconnected();
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.d */
    public abstract class C0646d<TListener> extends C0245b<TListener> {
        private final DataHolder DD;
        final /* synthetic */ hc Gf;

        public C0646d(hc hcVar, TListener tListener, DataHolder dataHolder) {
            this.Gf = hcVar;
            super(hcVar, tListener);
            this.DD = dataHolder;
        }

        protected abstract void m2639a(TListener tListener, DataHolder dataHolder);

        protected final void m2640d(TListener tListener) {
            m2639a(tListener, this.DD);
        }

        protected void fp() {
            if (this.DD != null) {
                this.DD.close();
            }
        }

        public /* bridge */ /* synthetic */ void fq() {
            super.fq();
        }

        public /* bridge */ /* synthetic */ void fr() {
            super.fr();
        }

        public /* bridge */ /* synthetic */ void unregister() {
            super.unregister();
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.h */
    protected final class C0647h extends C0245b<Boolean> {
        final /* synthetic */ hc Gf;
        public final Bundle Gk;
        public final IBinder Gl;
        public final int statusCode;

        public C0647h(hc hcVar, int i, IBinder iBinder, Bundle bundle) {
            this.Gf = hcVar;
            super(hcVar, Boolean.valueOf(true));
            this.statusCode = i;
            this.Gl = iBinder;
            this.Gk = bundle;
        }

        protected void m2641b(Boolean bool) {
            if (bool == null) {
                this.Gf.am(1);
                return;
            }
            switch (this.statusCode) {
                case DetectedActivity.IN_VEHICLE /*0*/:
                    try {
                        if (this.Gf.bq().equals(this.Gl.getInterfaceDescriptor())) {
                            this.Gf.FY = this.Gf.m2656x(this.Gl);
                            if (this.Gf.FY != null) {
                                this.Gf.am(3);
                                this.Gf.DP.ck();
                                return;
                            }
                        }
                    } catch (RemoteException e) {
                    }
                    he.m1172B(this.Gf.mContext).m1175b(this.Gf.bp(), this.Gf.Ga);
                    this.Gf.Ga = null;
                    this.Gf.am(1);
                    this.Gf.FY = null;
                    this.Gf.DP.m1162a(new ConnectionResult(8, null));
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    this.Gf.am(1);
                    throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
                default:
                    PendingIntent pendingIntent = this.Gk != null ? (PendingIntent) this.Gk.getParcelable("pendingIntent") : null;
                    if (this.Gf.Ga != null) {
                        he.m1172B(this.Gf.mContext).m1175b(this.Gf.bp(), this.Gf.Ga);
                        this.Gf.Ga = null;
                    }
                    this.Gf.am(1);
                    this.Gf.FY = null;
                    this.Gf.DP.m1162a(new ConnectionResult(this.statusCode, pendingIntent));
            }
        }

        protected /* synthetic */ void m2642d(Object obj) {
            m2641b((Boolean) obj);
        }

        protected void fp() {
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.e */
    public static final class C0993e extends C0651a {
        private hc Gi;

        public C0993e(hc hcVar) {
            this.Gi = hcVar;
        }

        public void m3641b(int i, IBinder iBinder, Bundle bundle) {
            hn.m1226b((Object) "onPostInitComplete can be called only once per call to getServiceFromBroker", this.Gi);
            this.Gi.m2652a(i, iBinder, bundle);
            this.Gi = null;
        }
    }

    /* renamed from: com.google.android.gms.internal.hc.g */
    public static final class C0994g implements OnConnectionFailedListener {
        private final GooglePlayServicesClient.OnConnectionFailedListener Gj;

        public C0994g(GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener) {
            this.Gj = onConnectionFailedListener;
        }

        public boolean equals(Object other) {
            return other instanceof C0994g ? this.Gj.equals(((C0994g) other).Gj) : this.Gj.equals(other);
        }

        public void onConnectionFailed(ConnectionResult result) {
            this.Gj.onConnectionFailed(result);
        }
    }

    static {
        Ge = new String[]{"service_esmobile", "service_googleme"};
    }

    protected hc(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String... strArr) {
        this.FZ = new ArrayList();
        this.Gb = 1;
        this.Gd = false;
        this.mContext = (Context) hn.m1230f(context);
        this.DC = (Looper) hn.m1226b((Object) looper, (Object) "Looper must not be null");
        this.DP = new hd(context, looper, this);
        this.mHandler = new C0244a(this, looper);
        m2655b(strArr);
        this.Gc = strArr;
        registerConnectionCallbacks((ConnectionCallbacks) hn.m1230f(connectionCallbacks));
        registerConnectionFailedListener((OnConnectionFailedListener) hn.m1230f(onConnectionFailedListener));
    }

    @Deprecated
    protected hc(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener, String... strArr) {
        this(context, context.getMainLooper(), new C0645c(connectionCallbacks), new C0994g(onConnectionFailedListener), strArr);
    }

    private void am(int i) {
        int i2 = this.Gb;
        this.Gb = i;
        if (i2 == i) {
            return;
        }
        if (i == 3) {
            onConnected();
        } else if (i2 == 3 && i == 1) {
            onDisconnected();
        }
    }

    protected final void m2651I(IBinder iBinder) {
        try {
            m2654a(C0653a.m2695L(iBinder), new C0993e(this));
        } catch (RemoteException e) {
            Log.w("GmsClient", "service died");
        }
    }

    protected void m2652a(int i, IBinder iBinder, Bundle bundle) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(1, new C0647h(this, i, iBinder, bundle)));
    }

    @Deprecated
    public final void m2653a(C0245b<?> c0245b) {
        synchronized (this.FZ) {
            this.FZ.add(c0245b);
        }
        this.mHandler.sendMessage(this.mHandler.obtainMessage(2, c0245b));
    }

    protected abstract void m2654a(hj hjVar, C0993e c0993e) throws RemoteException;

    public void an(int i) {
        this.mHandler.sendMessage(this.mHandler.obtainMessage(4, Integer.valueOf(i)));
    }

    protected void m2655b(String... strArr) {
    }

    protected abstract String bp();

    protected abstract String bq();

    protected final void ci() {
        if (!isConnected()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    public void connect() {
        this.Gd = true;
        am(2);
        int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.mContext);
        if (isGooglePlayServicesAvailable != 0) {
            am(1);
            this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(isGooglePlayServicesAvailable)));
            return;
        }
        if (this.Ga != null) {
            Log.e("GmsClient", "Calling connect() while still connected, missing disconnect().");
            this.FY = null;
            he.m1172B(this.mContext).m1175b(bp(), this.Ga);
        }
        this.Ga = new C0246f(this);
        if (!he.m1172B(this.mContext).m1174a(bp(), this.Ga)) {
            Log.e("GmsClient", "unable to connect to service: " + bp());
            this.mHandler.sendMessage(this.mHandler.obtainMessage(3, Integer.valueOf(9)));
        }
    }

    public void disconnect() {
        this.Gd = false;
        synchronized (this.FZ) {
            int size = this.FZ.size();
            for (int i = 0; i < size; i++) {
                ((C0245b) this.FZ.get(i)).fr();
            }
            this.FZ.clear();
        }
        am(1);
        this.FY = null;
        if (this.Ga != null) {
            he.m1172B(this.mContext).m1175b(bp(), this.Ga);
            this.Ga = null;
        }
    }

    public boolean eJ() {
        return this.Gd;
    }

    public Bundle ea() {
        return null;
    }

    public final String[] fn() {
        return this.Gc;
    }

    public final T fo() {
        ci();
        return this.FY;
    }

    public final Context getContext() {
        return this.mContext;
    }

    public final Looper getLooper() {
        return this.DC;
    }

    public boolean isConnected() {
        return this.Gb == 3;
    }

    public boolean isConnecting() {
        return this.Gb == 2;
    }

    @Deprecated
    public boolean isConnectionCallbacksRegistered(GooglePlayServicesClient.ConnectionCallbacks listener) {
        return this.DP.isConnectionCallbacksRegistered(new C0645c(listener));
    }

    @Deprecated
    public boolean isConnectionFailedListenerRegistered(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        return this.DP.isConnectionFailedListenerRegistered(listener);
    }

    protected void onConnected() {
    }

    protected void onDisconnected() {
    }

    @Deprecated
    public void registerConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.DP.registerConnectionCallbacks(new C0645c(listener));
    }

    public void registerConnectionCallbacks(ConnectionCallbacks listener) {
        this.DP.registerConnectionCallbacks(listener);
    }

    @Deprecated
    public void registerConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.DP.registerConnectionFailedListener(listener);
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener listener) {
        this.DP.registerConnectionFailedListener(listener);
    }

    @Deprecated
    public void unregisterConnectionCallbacks(GooglePlayServicesClient.ConnectionCallbacks listener) {
        this.DP.unregisterConnectionCallbacks(new C0645c(listener));
    }

    @Deprecated
    public void unregisterConnectionFailedListener(GooglePlayServicesClient.OnConnectionFailedListener listener) {
        this.DP.unregisterConnectionFailedListener(listener);
    }

    protected abstract T m2656x(IBinder iBinder);
}
