package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.u */
public interface C0271u {
    void onAdClicked();
}
