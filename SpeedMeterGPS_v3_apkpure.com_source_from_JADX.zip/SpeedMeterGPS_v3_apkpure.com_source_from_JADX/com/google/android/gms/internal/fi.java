package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;

public class fi implements Creator<fh> {
    static void m1056a(fh fhVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m246a(parcel, 1, fhVar.xK, i, false);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, fhVar.xJ);
        C0072b.m240a(parcel, 2, fhVar.xL, false);
        C0072b.m243a(parcel, 3, fhVar.xM);
        C0072b.m228G(parcel, C);
    }

    public fh[] m1057D(int i) {
        return new fh[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1058l(x0);
    }

    public fh m1058l(Parcel parcel) {
        String str = null;
        boolean z = false;
        int B = C0071a.m189B(parcel);
        fl[] flVarArr = null;
        int i = 0;
        while (parcel.dataPosition() < B) {
            int i2;
            fl[] flVarArr2;
            boolean z2;
            String str2;
            int A = C0071a.m187A(parcel);
            boolean z3;
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i2 = i;
                    String str3 = str;
                    flVarArr2 = (fl[]) C0071a.m199b(parcel, A, fl.CREATOR);
                    z2 = z;
                    str2 = str3;
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    flVarArr2 = flVarArr;
                    i2 = i;
                    z3 = z;
                    str2 = C0071a.m213o(parcel, A);
                    z2 = z3;
                    break;
                case DetectedActivity.STILL /*3*/:
                    z2 = C0071a.m201c(parcel, A);
                    str2 = str;
                    flVarArr2 = flVarArr;
                    i2 = i;
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    z3 = z;
                    str2 = str;
                    flVarArr2 = flVarArr;
                    i2 = C0071a.m205g(parcel, A);
                    z2 = z3;
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    z2 = z;
                    str2 = str;
                    flVarArr2 = flVarArr;
                    i2 = i;
                    break;
            }
            i = i2;
            flVarArr = flVarArr2;
            str = str2;
            z = z2;
        }
        if (parcel.dataPosition() == B) {
            return new fh(i, flVarArr, str, z);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1057D(x0);
    }
}
