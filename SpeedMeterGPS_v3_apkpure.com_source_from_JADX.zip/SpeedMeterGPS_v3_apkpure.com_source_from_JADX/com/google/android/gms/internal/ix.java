package com.google.android.gms.internal;

import android.accounts.Account;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.identity.intents.AddressConstants.ErrorCodes;
import com.google.android.gms.identity.intents.AddressConstants.Extras;
import com.google.android.gms.identity.intents.UserAddressRequest;
import com.google.android.gms.internal.hc.C0993e;
import com.google.android.gms.internal.iy.C0663a;
import com.google.android.gms.internal.iz.C0665a;

public class ix extends hc<iz> {
    private C0997a UD;
    private final int mTheme;
    private Activity oe;
    private final String yN;

    /* renamed from: com.google.android.gms.internal.ix.a */
    public static final class C0997a extends C0663a {
        private final int FT;
        private Activity oe;

        public C0997a(int i, Activity activity) {
            this.FT = i;
            this.oe = activity;
        }

        private void setActivity(Activity activity) {
            this.oe = activity;
        }

        public void m3651g(int i, Bundle bundle) {
            PendingIntent createPendingResult;
            if (i == 1) {
                Intent intent = new Intent();
                intent.putExtras(bundle);
                createPendingResult = this.oe.createPendingResult(this.FT, intent, 1073741824);
                if (createPendingResult != null) {
                    try {
                        createPendingResult.send(1);
                        return;
                    } catch (Throwable e) {
                        Log.w("AddressClientImpl", "Exception settng pending result", e);
                        return;
                    }
                }
                return;
            }
            createPendingResult = null;
            if (bundle != null) {
                createPendingResult = (PendingIntent) bundle.getParcelable("com.google.android.gms.identity.intents.EXTRA_PENDING_INTENT");
            }
            ConnectionResult connectionResult = new ConnectionResult(i, createPendingResult);
            if (connectionResult.hasResolution()) {
                try {
                    connectionResult.startResolutionForResult(this.oe, this.FT);
                    return;
                } catch (Throwable e2) {
                    Log.w("AddressClientImpl", "Exception starting pending intent", e2);
                    return;
                }
            }
            try {
                createPendingResult = this.oe.createPendingResult(this.FT, new Intent(), 1073741824);
                if (createPendingResult != null) {
                    createPendingResult.send(1);
                }
            } catch (Throwable e22) {
                Log.w("AddressClientImpl", "Exception setting pending result", e22);
            }
        }
    }

    public ix(Activity activity, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, int i) {
        super(activity, looper, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.yN = str;
        this.oe = activity;
        this.mTheme = i;
    }

    public void m3652a(UserAddressRequest userAddressRequest, int i) {
        Bundle bundle;
        iP();
        this.UD = new C0997a(i, this.oe);
        try {
            bundle = new Bundle();
            bundle.putString("com.google.android.gms.identity.intents.EXTRA_CALLING_PACKAGE_NAME", getContext().getPackageName());
            if (!TextUtils.isEmpty(this.yN)) {
                bundle.putParcelable("com.google.android.gms.identity.intents.EXTRA_ACCOUNT", new Account(this.yN, GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE));
            }
            bundle.putInt("com.google.android.gms.identity.intents.EXTRA_THEME", this.mTheme);
            iO().m1277a(this.UD, userAddressRequest, bundle);
        } catch (Throwable e) {
            Log.e("AddressClientImpl", "Exception requesting user address", e);
            bundle = new Bundle();
            bundle.putInt(Extras.EXTRA_ERROR_CODE, ErrorCodes.ERROR_CODE_NO_APPLICABLE_ADDRESSES);
            this.UD.m3651g(1, bundle);
        }
    }

    protected void m3653a(hj hjVar, C0993e c0993e) throws RemoteException {
        hjVar.m1198d(c0993e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName());
    }

    protected iz an(IBinder iBinder) {
        return C0665a.ap(iBinder);
    }

    protected String bp() {
        return "com.google.android.gms.identity.service.BIND";
    }

    protected String bq() {
        return "com.google.android.gms.identity.intents.internal.IAddressService";
    }

    public void disconnect() {
        super.disconnect();
        if (this.UD != null) {
            this.UD.setActivity(null);
            this.UD = null;
        }
    }

    protected iz iO() {
        return (iz) super.fo();
    }

    protected void iP() {
        super.ci();
    }

    protected /* synthetic */ IInterface m3654x(IBinder iBinder) {
        return an(iBinder);
    }
}
