package com.google.android.gms.internal;

import java.util.Locale;

public class ka {
    private static final String TAG;
    private final jk<jf> VG;
    private final kb YQ;
    private final Locale YR;

    static {
        TAG = ka.class.getSimpleName();
    }

    public ka(String str, jk<jf> jkVar) {
        this.VG = jkVar;
        this.YR = Locale.getDefault();
        this.YQ = new kb(str, this.YR);
    }
}
