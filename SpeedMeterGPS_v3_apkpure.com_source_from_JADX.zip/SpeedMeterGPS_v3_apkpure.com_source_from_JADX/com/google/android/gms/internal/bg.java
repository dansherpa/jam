package com.google.android.gms.internal;

public interface bg {
    void m825b(boolean z);
}
