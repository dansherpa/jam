package com.google.android.gms.internal;

import com.google.android.gms.plus.PlusShare;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

class ec {
    private final List<String> qP;
    private final List<String> qQ;
    private final String qR;
    private final String qS;
    private final String qT;
    private final String qU;
    private final String qV;
    private final boolean qW;
    private final int qX;

    public ec(Map<String, String> map) {
        this.qV = (String) map.get(PlusShare.KEY_CALL_TO_ACTION_URL);
        this.qS = (String) map.get("base_uri");
        this.qT = (String) map.get("post_parameters");
        this.qW = parseBoolean((String) map.get("drt_include"));
        this.qR = (String) map.get("activation_overlay_url");
        this.qQ = m944t((String) map.get("check_packages"));
        this.qX = parseInt((String) map.get("request_id"));
        this.qU = (String) map.get("type");
        this.qP = m944t((String) map.get("errors"));
    }

    private static boolean parseBoolean(String bool) {
        return bool != null && (bool.equals("1") || bool.equals("true"));
    }

    private int parseInt(String i) {
        return i == null ? 0 : Integer.parseInt(i);
    }

    private List<String> m944t(String str) {
        return str == null ? null : Arrays.asList(str.split(","));
    }

    public List<String> bt() {
        return this.qP;
    }

    public String bu() {
        return this.qT;
    }

    public boolean bv() {
        return this.qW;
    }

    public String getType() {
        return this.qU;
    }

    public String getUrl() {
        return this.qV;
    }
}
