package com.google.android.gms.internal;

import android.content.Context;
import android.os.Parcel;
import android.util.DisplayMetrics;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.C0002a;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public final class am implements SafeParcelable {
    public static final an CREATOR;
    public final int height;
    public final int heightPixels;
    public final String mc;
    public final boolean md;
    public final am[] me;
    public final int versionCode;
    public final int width;
    public final int widthPixels;

    static {
        CREATOR = new an();
    }

    public am() {
        this(2, "interstitial_mb", 0, 0, true, 0, 0, null);
    }

    am(int i, String str, int i2, int i3, boolean z, int i4, int i5, am[] amVarArr) {
        this.versionCode = i;
        this.mc = str;
        this.height = i2;
        this.heightPixels = i3;
        this.md = z;
        this.width = i4;
        this.widthPixels = i5;
        this.me = amVarArr;
    }

    public am(Context context, AdSize adSize) {
        this(context, new AdSize[]{adSize});
    }

    public am(Context context, AdSize[] adSizeArr) {
        int i;
        int i2;
        int i3 = 0;
        AdSize adSize = adSizeArr[0];
        this.versionCode = 2;
        this.md = false;
        this.width = adSize.getWidth();
        this.height = adSize.getHeight();
        int i4 = this.width == -1 ? 1 : 0;
        int i5 = this.height == -2 ? 1 : 0;
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        if (i4 != 0) {
            this.widthPixels = m2458a(displayMetrics);
            i = (int) (((float) this.widthPixels) / displayMetrics.density);
        } else {
            i2 = this.width;
            this.widthPixels = eu.m1004a(displayMetrics, this.width);
            i = i2;
        }
        i2 = i5 != 0 ? m2460c(displayMetrics) : this.height;
        this.heightPixels = eu.m1004a(displayMetrics, i2);
        if (i4 == 0 && i5 == 0) {
            this.mc = adSize.toString();
        } else {
            this.mc = i + "x" + i2 + "_as";
        }
        if (adSizeArr.length > 1) {
            this.me = new am[adSizeArr.length];
            while (i3 < adSizeArr.length) {
                this.me[i3] = new am(context, adSizeArr[i3]);
                i3++;
            }
            return;
        }
        this.me = null;
    }

    public am(am amVar, am[] amVarArr) {
        this(2, amVar.mc, amVar.height, amVar.heightPixels, amVar.md, amVar.width, amVar.widthPixels, amVarArr);
    }

    public static int m2458a(DisplayMetrics displayMetrics) {
        return displayMetrics.widthPixels;
    }

    public static int m2459b(DisplayMetrics displayMetrics) {
        return (int) (((float) m2460c(displayMetrics)) * displayMetrics.density);
    }

    private static int m2460c(DisplayMetrics displayMetrics) {
        int i = (int) (((float) displayMetrics.heightPixels) / displayMetrics.density);
        return i <= 400 ? 32 : i <= 720 ? 50 : 90;
    }

    public AdSize aB() {
        return C0002a.m4a(this.width, this.height, this.mc);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        an.m778a(this, out, flags);
    }
}
