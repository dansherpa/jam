package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.dt.C0205a;

public final class dn {

    /* renamed from: com.google.android.gms.internal.dn.a */
    public interface C0197a {
        void m891a(eg egVar);
    }

    public static en m892a(Context context, C0205a c0205a, C0259l c0259l, ey eyVar, bu buVar, C0197a c0197a) {
        en c0609do = new C0609do(context, c0205a, c0259l, eyVar, buVar, c0197a);
        c0609do.start();
        return c0609do;
    }
}
