package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;

public class du implements Creator<dt> {
    static void m908a(dt dtVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, dtVar.versionCode);
        C0072b.m233a(parcel, 2, dtVar.pU, false);
        C0072b.m236a(parcel, 3, dtVar.pV, i, false);
        C0072b.m236a(parcel, 4, dtVar.kR, i, false);
        C0072b.m240a(parcel, 5, dtVar.kL, false);
        C0072b.m236a(parcel, 6, dtVar.applicationInfo, i, false);
        C0072b.m236a(parcel, 7, dtVar.pW, i, false);
        C0072b.m240a(parcel, 8, dtVar.pX, false);
        C0072b.m240a(parcel, 9, dtVar.pY, false);
        C0072b.m240a(parcel, 10, dtVar.pZ, false);
        C0072b.m236a(parcel, 11, dtVar.kO, i, false);
        C0072b.m233a(parcel, 12, dtVar.qa, false);
        C0072b.m228G(parcel, C);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m909h(x0);
    }

    public dt m909h(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        Bundle bundle = null;
        aj ajVar = null;
        am amVar = null;
        String str = null;
        ApplicationInfo applicationInfo = null;
        PackageInfo packageInfo = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        ew ewVar = null;
        Bundle bundle2 = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    bundle = C0071a.m215q(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    ajVar = (aj) C0071a.m194a(parcel, A, aj.CREATOR);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    amVar = (am) C0071a.m194a(parcel, A, am.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    applicationInfo = (ApplicationInfo) C0071a.m194a(parcel, A, ApplicationInfo.CREATOR);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    packageInfo = (PackageInfo) C0071a.m194a(parcel, A, PackageInfo.CREATOR);
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    str3 = C0071a.m213o(parcel, A);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    str4 = C0071a.m213o(parcel, A);
                    break;
                case C0450R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    ewVar = (ew) C0071a.m194a(parcel, A, ew.CREATOR);
                    break;
                case C0450R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    bundle2 = C0071a.m215q(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new dt(i, bundle, ajVar, amVar, str, applicationInfo, packageInfo, str2, str3, str4, ewVar, bundle2);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public dt[] m910m(int i) {
        return new dt[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m910m(x0);
    }
}
