package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import java.util.ArrayList;
import java.util.Iterator;

public final class hd {
    private final C0248b Gm;
    private final ArrayList<ConnectionCallbacks> Gn;
    final ArrayList<ConnectionCallbacks> Go;
    private boolean Gp;
    private final ArrayList<OnConnectionFailedListener> Gq;
    private final Handler mHandler;

    /* renamed from: com.google.android.gms.internal.hd.a */
    final class C0247a extends Handler {
        final /* synthetic */ hd Gr;

        public C0247a(hd hdVar, Looper looper) {
            this.Gr = hdVar;
            super(looper);
        }

        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                synchronized (this.Gr.Gn) {
                    if (this.Gr.Gm.eJ() && this.Gr.Gm.isConnected() && this.Gr.Gn.contains(msg.obj)) {
                        ((ConnectionCallbacks) msg.obj).onConnected(this.Gr.Gm.ea());
                    }
                }
                return;
            }
            Log.wtf("GmsClientEvents", "Don't know how to handle this message.");
        }
    }

    /* renamed from: com.google.android.gms.internal.hd.b */
    public interface C0248b {
        boolean eJ();

        Bundle ea();

        boolean isConnected();
    }

    public hd(Context context, Looper looper, C0248b c0248b) {
        this.Gn = new ArrayList();
        this.Go = new ArrayList();
        this.Gp = false;
        this.Gq = new ArrayList();
        this.Gm = c0248b;
        this.mHandler = new C0247a(this, looper);
    }

    public void m1162a(ConnectionResult connectionResult) {
        this.mHandler.removeMessages(1);
        synchronized (this.Gq) {
            Iterator it = new ArrayList(this.Gq).iterator();
            while (it.hasNext()) {
                OnConnectionFailedListener onConnectionFailedListener = (OnConnectionFailedListener) it.next();
                if (!this.Gm.eJ()) {
                    return;
                } else if (this.Gq.contains(onConnectionFailedListener)) {
                    onConnectionFailedListener.onConnectionFailed(connectionResult);
                }
            }
        }
    }

    public void ao(int i) {
        this.mHandler.removeMessages(1);
        synchronized (this.Gn) {
            this.Gp = true;
            Iterator it = new ArrayList(this.Gn).iterator();
            while (it.hasNext()) {
                ConnectionCallbacks connectionCallbacks = (ConnectionCallbacks) it.next();
                if (!this.Gm.eJ()) {
                    break;
                } else if (this.Gn.contains(connectionCallbacks)) {
                    connectionCallbacks.onConnectionSuspended(i);
                }
            }
            this.Gp = false;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m1163c(android.os.Bundle r6) {
        /*
        r5 = this;
        r1 = 0;
        r0 = 1;
        r3 = r5.Gn;
        monitor-enter(r3);
        r2 = r5.Gp;	 Catch:{ all -> 0x0062 }
        if (r2 != 0) goto L_0x0052;
    L_0x0009:
        r2 = r0;
    L_0x000a:
        com.google.android.gms.internal.hn.m1222A(r2);	 Catch:{ all -> 0x0062 }
        r2 = r5.mHandler;	 Catch:{ all -> 0x0062 }
        r4 = 1;
        r2.removeMessages(r4);	 Catch:{ all -> 0x0062 }
        r2 = 1;
        r5.Gp = r2;	 Catch:{ all -> 0x0062 }
        r2 = r5.Go;	 Catch:{ all -> 0x0062 }
        r2 = r2.size();	 Catch:{ all -> 0x0062 }
        if (r2 != 0) goto L_0x0054;
    L_0x001e:
        com.google.android.gms.internal.hn.m1222A(r0);	 Catch:{ all -> 0x0062 }
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x0062 }
        r1 = r5.Gn;	 Catch:{ all -> 0x0062 }
        r0.<init>(r1);	 Catch:{ all -> 0x0062 }
        r1 = r0.iterator();	 Catch:{ all -> 0x0062 }
    L_0x002c:
        r0 = r1.hasNext();	 Catch:{ all -> 0x0062 }
        if (r0 == 0) goto L_0x0048;
    L_0x0032:
        r0 = r1.next();	 Catch:{ all -> 0x0062 }
        r0 = (com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks) r0;	 Catch:{ all -> 0x0062 }
        r2 = r5.Gm;	 Catch:{ all -> 0x0062 }
        r2 = r2.eJ();	 Catch:{ all -> 0x0062 }
        if (r2 == 0) goto L_0x0048;
    L_0x0040:
        r2 = r5.Gm;	 Catch:{ all -> 0x0062 }
        r2 = r2.isConnected();	 Catch:{ all -> 0x0062 }
        if (r2 != 0) goto L_0x0056;
    L_0x0048:
        r0 = r5.Go;	 Catch:{ all -> 0x0062 }
        r0.clear();	 Catch:{ all -> 0x0062 }
        r0 = 0;
        r5.Gp = r0;	 Catch:{ all -> 0x0062 }
        monitor-exit(r3);	 Catch:{ all -> 0x0062 }
        return;
    L_0x0052:
        r2 = r1;
        goto L_0x000a;
    L_0x0054:
        r0 = r1;
        goto L_0x001e;
    L_0x0056:
        r2 = r5.Go;	 Catch:{ all -> 0x0062 }
        r2 = r2.contains(r0);	 Catch:{ all -> 0x0062 }
        if (r2 != 0) goto L_0x002c;
    L_0x005e:
        r0.onConnected(r6);	 Catch:{ all -> 0x0062 }
        goto L_0x002c;
    L_0x0062:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0062 }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.hd.c(android.os.Bundle):void");
    }

    protected void ck() {
        synchronized (this.Gn) {
            m1163c(this.Gm.ea());
        }
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks listener) {
        boolean contains;
        hn.m1230f(listener);
        synchronized (this.Gn) {
            contains = this.Gn.contains(listener);
        }
        return contains;
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener listener) {
        boolean contains;
        hn.m1230f(listener);
        synchronized (this.Gq) {
            contains = this.Gq.contains(listener);
        }
        return contains;
    }

    public void registerConnectionCallbacks(ConnectionCallbacks listener) {
        hn.m1230f(listener);
        synchronized (this.Gn) {
            if (this.Gn.contains(listener)) {
                Log.w("GmsClientEvents", "registerConnectionCallbacks(): listener " + listener + " is already registered");
            } else {
                this.Gn.add(listener);
            }
        }
        if (this.Gm.isConnected()) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(1, listener));
        }
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener listener) {
        hn.m1230f(listener);
        synchronized (this.Gq) {
            if (this.Gq.contains(listener)) {
                Log.w("GmsClientEvents", "registerConnectionFailedListener(): listener " + listener + " is already registered");
            } else {
                this.Gq.add(listener);
            }
        }
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks listener) {
        hn.m1230f(listener);
        synchronized (this.Gn) {
            if (this.Gn != null) {
                if (!this.Gn.remove(listener)) {
                    Log.w("GmsClientEvents", "unregisterConnectionCallbacks(): listener " + listener + " not found");
                } else if (this.Gp) {
                    this.Go.add(listener);
                }
            }
        }
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener listener) {
        hn.m1230f(listener);
        synchronized (this.Gq) {
            if (!(this.Gq == null || this.Gq.remove(listener))) {
                Log.w("GmsClientEvents", "unregisterConnectionFailedListener(): listener " + listener + " not found");
            }
        }
    }
}
