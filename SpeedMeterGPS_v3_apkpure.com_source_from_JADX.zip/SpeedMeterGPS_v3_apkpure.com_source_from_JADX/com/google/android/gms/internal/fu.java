package com.google.android.gms.internal;

import com.google.android.gms.common.api.Result;

public interface fu {

    /* renamed from: com.google.android.gms.internal.fu.a */
    public interface C0631a extends Result {
    }
}
