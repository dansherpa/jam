package com.google.android.gms.internal;

import android.os.Process;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class eo {
    private static final ThreadFactory se;
    private static final ThreadPoolExecutor sf;

    /* renamed from: com.google.android.gms.internal.eo.1 */
    static class C02091 implements Runnable {
        final /* synthetic */ Runnable sg;

        C02091(Runnable runnable) {
            this.sg = runnable;
        }

        public void run() {
            Process.setThreadPriority(10);
            this.sg.run();
        }
    }

    /* renamed from: com.google.android.gms.internal.eo.2 */
    static class C02102 implements ThreadFactory {
        private final AtomicInteger sh;

        C02102() {
            this.sh = new AtomicInteger(1);
        }

        public Thread newThread(Runnable runnable) {
            return new Thread(runnable, "AdWorker #" + this.sh.getAndIncrement());
        }
    }

    static {
        se = new C02102();
        sf = new ThreadPoolExecutor(0, 10, 65, TimeUnit.SECONDS, new SynchronousQueue(true), se);
    }

    public static void execute(Runnable task) {
        try {
            sf.execute(new C02091(task));
        } catch (Throwable e) {
            ev.m1016c("Too many background threads already running. Aborting task.  Current pool size: " + getPoolSize(), e);
        }
    }

    public static int getPoolSize() {
        return sf.getPoolSize();
    }
}
