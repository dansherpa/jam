package com.google.android.gms.internal;

import com.google.ads.AdSize;
import com.google.android.gms.games.Notifications;
import com.google.android.gms.internal.C0195d.C0983a;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.c */
public interface C0176c {

    /* renamed from: com.google.android.gms.internal.c.a */
    public static final class C0973a extends mb<C0973a> {
        public int eE;
        public int eF;
        public int level;

        public C0973a() {
            m3483b();
        }

        public C0973a m3481a(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case DetectedActivity.RUNNING /*8*/:
                        nw = lzVar.nz();
                        switch (nw) {
                            case DataEvent.TYPE_CHANGED /*1*/:
                            case DataEvent.TYPE_DELETED /*2*/:
                            case DetectedActivity.STILL /*3*/:
                                this.level = nw;
                                break;
                            default:
                                continue;
                        }
                    case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                        this.eE = lzVar.nz();
                        continue;
                    case 24:
                        this.eF = lzVar.nz();
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public void m3482a(ma maVar) throws IOException {
            if (this.level != 1) {
                maVar.m1410p(1, this.level);
            }
            if (this.eE != 0) {
                maVar.m1410p(2, this.eE);
            }
            if (this.eF != 0) {
                maVar.m1410p(3, this.eF);
            }
            super.m2814a(maVar);
        }

        public C0973a m3483b() {
            this.level = 1;
            this.eE = 0;
            this.eF = 0;
            this.amU = null;
            this.amY = -1;
            return this;
        }

        public /* synthetic */ mf m3484b(lz lzVar) throws IOException {
            return m3481a(lzVar);
        }

        protected int m3485c() {
            int c = super.m2816c();
            if (this.level != 1) {
                c += ma.m1389r(1, this.level);
            }
            if (this.eE != 0) {
                c += ma.m1389r(2, this.eE);
            }
            return this.eF != 0 ? c + ma.m1389r(3, this.eF) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0973a)) {
                return false;
            }
            C0973a c0973a = (C0973a) o;
            if (this.level != c0973a.level || this.eE != c0973a.eE || this.eF != c0973a.eF) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0973a.amU == null || c0973a.amU.isEmpty();
            } else {
                return this.amU.equals(c0973a.amU);
            }
        }

        public int hashCode() {
            int i = (((((this.level + 527) * 31) + this.eE) * 31) + this.eF) * 31;
            int hashCode = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.b */
    public static final class C0974b extends mb<C0974b> {
        private static volatile C0974b[] eG;
        public int[] eH;
        public int eI;
        public boolean eJ;
        public boolean eK;
        public int name;

        public C0974b() {
            m3491e();
        }

        public static C0974b[] m3486d() {
            if (eG == null) {
                synchronized (md.amX) {
                    if (eG == null) {
                        eG = new C0974b[0];
                    }
                }
            }
            return eG;
        }

        public void m3487a(ma maVar) throws IOException {
            if (this.eK) {
                maVar.m1399a(1, this.eK);
            }
            maVar.m1410p(2, this.eI);
            if (this.eH != null && this.eH.length > 0) {
                for (int p : this.eH) {
                    maVar.m1410p(3, p);
                }
            }
            if (this.name != 0) {
                maVar.m1410p(4, this.name);
            }
            if (this.eJ) {
                maVar.m1399a(6, this.eJ);
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3488b(lz lzVar) throws IOException {
            return m3490c(lzVar);
        }

        protected int m3489c() {
            int i = 0;
            int c = super.m2816c();
            if (this.eK) {
                c += ma.m1378b(1, this.eK);
            }
            int r = ma.m1389r(2, this.eI) + c;
            if (this.eH == null || this.eH.length <= 0) {
                c = r;
            } else {
                for (int eE : this.eH) {
                    i += ma.eE(eE);
                }
                c = (r + i) + (this.eH.length * 1);
            }
            if (this.name != 0) {
                c += ma.m1389r(4, this.name);
            }
            return this.eJ ? c + ma.m1378b(6, this.eJ) : c;
        }

        public C0974b m3490c(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                int b;
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case DetectedActivity.RUNNING /*8*/:
                        this.eK = lzVar.nA();
                        continue;
                    case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                        this.eI = lzVar.nz();
                        continue;
                    case 24:
                        b = mi.m1429b(lzVar, 24);
                        nw = this.eH == null ? 0 : this.eH.length;
                        Object obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eH, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.eH = obj;
                        continue;
                    case 26:
                        int ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.eH == null ? 0 : this.eH.length;
                        Object obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.eH, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.eH = obj2;
                        lzVar.ey(ex);
                        continue;
                    case AdSize.LANDSCAPE_AD_HEIGHT /*32*/:
                        this.name = lzVar.nz();
                        continue;
                    case 48:
                        this.eJ = lzVar.nA();
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C0974b m3491e() {
            this.eH = mi.ana;
            this.eI = 0;
            this.name = 0;
            this.eJ = false;
            this.eK = false;
            this.amU = null;
            this.amY = -1;
            return this;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0974b)) {
                return false;
            }
            C0974b c0974b = (C0974b) o;
            if (!md.equals(this.eH, c0974b.eH) || this.eI != c0974b.eI || this.name != c0974b.name || this.eJ != c0974b.eJ || this.eK != c0974b.eK) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0974b.amU == null || c0974b.amU.isEmpty();
            } else {
                return this.amU.equals(c0974b.amU);
            }
        }

        public int hashCode() {
            int i = 1231;
            int hashCode = ((this.eJ ? 1231 : 1237) + ((((((md.hashCode(this.eH) + 527) * 31) + this.eI) * 31) + this.name) * 31)) * 31;
            if (!this.eK) {
                i = 1237;
            }
            i = (hashCode + i) * 31;
            hashCode = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.c */
    public static final class C0975c extends mb<C0975c> {
        private static volatile C0975c[] eL;
        public String eM;
        public long eN;
        public long eO;
        public boolean eP;
        public long eQ;

        public C0975c() {
            m3497g();
        }

        public static C0975c[] m3492f() {
            if (eL == null) {
                synchronized (md.amX) {
                    if (eL == null) {
                        eL = new C0975c[0];
                    }
                }
            }
            return eL;
        }

        public void m3493a(ma maVar) throws IOException {
            if (!this.eM.equals("")) {
                maVar.m1404b(1, this.eM);
            }
            if (this.eN != 0) {
                maVar.m1403b(2, this.eN);
            }
            if (this.eO != 2147483647L) {
                maVar.m1403b(3, this.eO);
            }
            if (this.eP) {
                maVar.m1399a(4, this.eP);
            }
            if (this.eQ != 0) {
                maVar.m1403b(5, this.eQ);
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3494b(lz lzVar) throws IOException {
            return m3496d(lzVar);
        }

        protected int m3495c() {
            int c = super.m2816c();
            if (!this.eM.equals("")) {
                c += ma.m1387h(1, this.eM);
            }
            if (this.eN != 0) {
                c += ma.m1383d(2, this.eN);
            }
            if (this.eO != 2147483647L) {
                c += ma.m1383d(3, this.eO);
            }
            if (this.eP) {
                c += ma.m1378b(4, this.eP);
            }
            return this.eQ != 0 ? c + ma.m1383d(5, this.eQ) : c;
        }

        public C0975c m3496d(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        this.eM = lzVar.readString();
                        continue;
                    case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                        this.eN = lzVar.ny();
                        continue;
                    case 24:
                        this.eO = lzVar.ny();
                        continue;
                    case AdSize.LANDSCAPE_AD_HEIGHT /*32*/:
                        this.eP = lzVar.nA();
                        continue;
                    case 40:
                        this.eQ = lzVar.ny();
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0975c)) {
                return false;
            }
            C0975c c0975c = (C0975c) o;
            if (this.eM == null) {
                if (c0975c.eM != null) {
                    return false;
                }
            } else if (!this.eM.equals(c0975c.eM)) {
                return false;
            }
            if (this.eN != c0975c.eN || this.eO != c0975c.eO || this.eP != c0975c.eP || this.eQ != c0975c.eQ) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0975c.amU == null || c0975c.amU.isEmpty();
            } else {
                return this.amU.equals(c0975c.amU);
            }
        }

        public C0975c m3497g() {
            this.eM = "";
            this.eN = 0;
            this.eO = 2147483647L;
            this.eP = false;
            this.eQ = 0;
            this.amU = null;
            this.amY = -1;
            return this;
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((((this.eP ? 1231 : 1237) + (((((((this.eM == null ? 0 : this.eM.hashCode()) + 527) * 31) + ((int) (this.eN ^ (this.eN >>> 32)))) * 31) + ((int) (this.eO ^ (this.eO >>> 32)))) * 31)) * 31) + ((int) (this.eQ ^ (this.eQ >>> 32)))) * 31;
            if (!(this.amU == null || this.amU.isEmpty())) {
                i = this.amU.hashCode();
            }
            return hashCode + i;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.d */
    public static final class C0976d extends mb<C0976d> {
        public C0983a[] eR;
        public C0983a[] eS;
        public C0975c[] eT;

        public C0976d() {
            m3502h();
        }

        public void m3498a(ma maVar) throws IOException {
            int i = 0;
            if (this.eR != null && this.eR.length > 0) {
                for (mf mfVar : this.eR) {
                    if (mfVar != null) {
                        maVar.m1398a(1, mfVar);
                    }
                }
            }
            if (this.eS != null && this.eS.length > 0) {
                for (mf mfVar2 : this.eS) {
                    if (mfVar2 != null) {
                        maVar.m1398a(2, mfVar2);
                    }
                }
            }
            if (this.eT != null && this.eT.length > 0) {
                while (i < this.eT.length) {
                    mf mfVar3 = this.eT[i];
                    if (mfVar3 != null) {
                        maVar.m1398a(3, mfVar3);
                    }
                    i++;
                }
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3499b(lz lzVar) throws IOException {
            return m3501e(lzVar);
        }

        protected int m3500c() {
            int i;
            int i2 = 0;
            int c = super.m2816c();
            if (this.eR != null && this.eR.length > 0) {
                i = c;
                for (mf mfVar : this.eR) {
                    if (mfVar != null) {
                        i += ma.m1377b(1, mfVar);
                    }
                }
                c = i;
            }
            if (this.eS != null && this.eS.length > 0) {
                i = c;
                for (mf mfVar2 : this.eS) {
                    if (mfVar2 != null) {
                        i += ma.m1377b(2, mfVar2);
                    }
                }
                c = i;
            }
            if (this.eT != null && this.eT.length > 0) {
                while (i2 < this.eT.length) {
                    mf mfVar3 = this.eT[i2];
                    if (mfVar3 != null) {
                        c += ma.m1377b(3, mfVar3);
                    }
                    i2++;
                }
            }
            return c;
        }

        public C0976d m3501e(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                int b;
                Object obj;
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        b = mi.m1429b(lzVar, 10);
                        nw = this.eR == null ? 0 : this.eR.length;
                        obj = new C0983a[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eR, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0983a();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0983a();
                        lzVar.m1368a(obj[nw]);
                        this.eR = obj;
                        continue;
                    case 18:
                        b = mi.m1429b(lzVar, 18);
                        nw = this.eS == null ? 0 : this.eS.length;
                        obj = new C0983a[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eS, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0983a();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0983a();
                        lzVar.m1368a(obj[nw]);
                        this.eS = obj;
                        continue;
                    case 26:
                        b = mi.m1429b(lzVar, 26);
                        nw = this.eT == null ? 0 : this.eT.length;
                        obj = new C0975c[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eT, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0975c();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0975c();
                        lzVar.m1368a(obj[nw]);
                        this.eT = obj;
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0976d)) {
                return false;
            }
            C0976d c0976d = (C0976d) o;
            if (!md.equals(this.eR, c0976d.eR) || !md.equals(this.eS, c0976d.eS) || !md.equals(this.eT, c0976d.eT)) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0976d.amU == null || c0976d.amU.isEmpty();
            } else {
                return this.amU.equals(c0976d.amU);
            }
        }

        public C0976d m3502h() {
            this.eR = C0983a.m3556r();
            this.eS = C0983a.m3556r();
            this.eT = C0975c.m3492f();
            this.amU = null;
            this.amY = -1;
            return this;
        }

        public int hashCode() {
            int hashCode = (((((md.hashCode(this.eR) + 527) * 31) + md.hashCode(this.eS)) * 31) + md.hashCode(this.eT)) * 31;
            int hashCode2 = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode2 + hashCode;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.e */
    public static final class C0977e extends mb<C0977e> {
        private static volatile C0977e[] eU;
        public int key;
        public int value;

        public C0977e() {
            m3508j();
        }

        public static C0977e[] m3503i() {
            if (eU == null) {
                synchronized (md.amX) {
                    if (eU == null) {
                        eU = new C0977e[0];
                    }
                }
            }
            return eU;
        }

        public void m3504a(ma maVar) throws IOException {
            maVar.m1410p(1, this.key);
            maVar.m1410p(2, this.value);
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3505b(lz lzVar) throws IOException {
            return m3507f(lzVar);
        }

        protected int m3506c() {
            return (super.m2816c() + ma.m1389r(1, this.key)) + ma.m1389r(2, this.value);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0977e)) {
                return false;
            }
            C0977e c0977e = (C0977e) o;
            if (this.key != c0977e.key || this.value != c0977e.value) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0977e.amU == null || c0977e.amU.isEmpty();
            } else {
                return this.amU.equals(c0977e.amU);
            }
        }

        public C0977e m3507f(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case DetectedActivity.RUNNING /*8*/:
                        this.key = lzVar.nz();
                        continue;
                    case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                        this.value = lzVar.nz();
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public int hashCode() {
            int i = (((this.key + 527) * 31) + this.value) * 31;
            int hashCode = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode + i;
        }

        public C0977e m3508j() {
            this.key = 0;
            this.value = 0;
            this.amU = null;
            this.amY = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.f */
    public static final class C0978f extends mb<C0978f> {
        public String[] eV;
        public String[] eW;
        public C0983a[] eX;
        public C0977e[] eY;
        public C0974b[] eZ;
        public C0974b[] fa;
        public C0974b[] fb;
        public C0979g[] fc;
        public String fd;
        public String fe;
        public String ff;
        public String fg;
        public C0973a fh;
        public float fi;
        public boolean fj;
        public String[] fk;
        public int fl;

        public C0978f() {
            m3514k();
        }

        public static C0978f m3509a(byte[] bArr) throws me {
            return (C0978f) mf.m1419a(new C0978f(), bArr);
        }

        public void m3510a(ma maVar) throws IOException {
            int i = 0;
            if (this.eW != null && this.eW.length > 0) {
                for (String str : this.eW) {
                    if (str != null) {
                        maVar.m1404b(1, str);
                    }
                }
            }
            if (this.eX != null && this.eX.length > 0) {
                for (mf mfVar : this.eX) {
                    if (mfVar != null) {
                        maVar.m1398a(2, mfVar);
                    }
                }
            }
            if (this.eY != null && this.eY.length > 0) {
                for (mf mfVar2 : this.eY) {
                    if (mfVar2 != null) {
                        maVar.m1398a(3, mfVar2);
                    }
                }
            }
            if (this.eZ != null && this.eZ.length > 0) {
                for (mf mfVar22 : this.eZ) {
                    if (mfVar22 != null) {
                        maVar.m1398a(4, mfVar22);
                    }
                }
            }
            if (this.fa != null && this.fa.length > 0) {
                for (mf mfVar222 : this.fa) {
                    if (mfVar222 != null) {
                        maVar.m1398a(5, mfVar222);
                    }
                }
            }
            if (this.fb != null && this.fb.length > 0) {
                for (mf mfVar2222 : this.fb) {
                    if (mfVar2222 != null) {
                        maVar.m1398a(6, mfVar2222);
                    }
                }
            }
            if (this.fc != null && this.fc.length > 0) {
                for (mf mfVar22222 : this.fc) {
                    if (mfVar22222 != null) {
                        maVar.m1398a(7, mfVar22222);
                    }
                }
            }
            if (!this.fd.equals("")) {
                maVar.m1404b(9, this.fd);
            }
            if (!this.fe.equals("")) {
                maVar.m1404b(10, this.fe);
            }
            if (!this.ff.equals("0")) {
                maVar.m1404b(12, this.ff);
            }
            if (!this.fg.equals("")) {
                maVar.m1404b(13, this.fg);
            }
            if (this.fh != null) {
                maVar.m1398a(14, this.fh);
            }
            if (Float.floatToIntBits(this.fi) != Float.floatToIntBits(0.0f)) {
                maVar.m1402b(15, this.fi);
            }
            if (this.fk != null && this.fk.length > 0) {
                for (String str2 : this.fk) {
                    if (str2 != null) {
                        maVar.m1404b(16, str2);
                    }
                }
            }
            if (this.fl != 0) {
                maVar.m1410p(17, this.fl);
            }
            if (this.fj) {
                maVar.m1399a(18, this.fj);
            }
            if (this.eV != null && this.eV.length > 0) {
                while (i < this.eV.length) {
                    String str3 = this.eV[i];
                    if (str3 != null) {
                        maVar.m1404b(19, str3);
                    }
                    i++;
                }
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3511b(lz lzVar) throws IOException {
            return m3513g(lzVar);
        }

        protected int m3512c() {
            int i;
            int i2;
            int i3;
            int i4 = 0;
            int c = super.m2816c();
            if (this.eW == null || this.eW.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                i3 = 0;
                for (String str : this.eW) {
                    if (str != null) {
                        i3++;
                        i2 += ma.cz(str);
                    }
                }
                i = (c + i2) + (i3 * 1);
            }
            if (this.eX != null && this.eX.length > 0) {
                i2 = i;
                for (mf mfVar : this.eX) {
                    if (mfVar != null) {
                        i2 += ma.m1377b(2, mfVar);
                    }
                }
                i = i2;
            }
            if (this.eY != null && this.eY.length > 0) {
                i2 = i;
                for (mf mfVar2 : this.eY) {
                    if (mfVar2 != null) {
                        i2 += ma.m1377b(3, mfVar2);
                    }
                }
                i = i2;
            }
            if (this.eZ != null && this.eZ.length > 0) {
                i2 = i;
                for (mf mfVar22 : this.eZ) {
                    if (mfVar22 != null) {
                        i2 += ma.m1377b(4, mfVar22);
                    }
                }
                i = i2;
            }
            if (this.fa != null && this.fa.length > 0) {
                i2 = i;
                for (mf mfVar222 : this.fa) {
                    if (mfVar222 != null) {
                        i2 += ma.m1377b(5, mfVar222);
                    }
                }
                i = i2;
            }
            if (this.fb != null && this.fb.length > 0) {
                i2 = i;
                for (mf mfVar2222 : this.fb) {
                    if (mfVar2222 != null) {
                        i2 += ma.m1377b(6, mfVar2222);
                    }
                }
                i = i2;
            }
            if (this.fc != null && this.fc.length > 0) {
                i2 = i;
                for (mf mfVar22222 : this.fc) {
                    if (mfVar22222 != null) {
                        i2 += ma.m1377b(7, mfVar22222);
                    }
                }
                i = i2;
            }
            if (!this.fd.equals("")) {
                i += ma.m1387h(9, this.fd);
            }
            if (!this.fe.equals("")) {
                i += ma.m1387h(10, this.fe);
            }
            if (!this.ff.equals("0")) {
                i += ma.m1387h(12, this.ff);
            }
            if (!this.fg.equals("")) {
                i += ma.m1387h(13, this.fg);
            }
            if (this.fh != null) {
                i += ma.m1377b(14, this.fh);
            }
            if (Float.floatToIntBits(this.fi) != Float.floatToIntBits(0.0f)) {
                i += ma.m1381c(15, this.fi);
            }
            if (this.fk != null && this.fk.length > 0) {
                i3 = 0;
                c = 0;
                for (String str2 : this.fk) {
                    if (str2 != null) {
                        c++;
                        i3 += ma.cz(str2);
                    }
                }
                i = (i + i3) + (c * 2);
            }
            if (this.fl != 0) {
                i += ma.m1389r(17, this.fl);
            }
            if (this.fj) {
                i += ma.m1378b(18, this.fj);
            }
            if (this.eV == null || this.eV.length <= 0) {
                return i;
            }
            i2 = 0;
            i3 = 0;
            while (i4 < this.eV.length) {
                String str3 = this.eV[i4];
                if (str3 != null) {
                    i3++;
                    i2 += ma.cz(str3);
                }
                i4++;
            }
            return (i + i2) + (i3 * 2);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0978f)) {
                return false;
            }
            C0978f c0978f = (C0978f) o;
            if (!md.equals(this.eV, c0978f.eV) || !md.equals(this.eW, c0978f.eW) || !md.equals(this.eX, c0978f.eX) || !md.equals(this.eY, c0978f.eY) || !md.equals(this.eZ, c0978f.eZ) || !md.equals(this.fa, c0978f.fa) || !md.equals(this.fb, c0978f.fb) || !md.equals(this.fc, c0978f.fc)) {
                return false;
            }
            if (this.fd == null) {
                if (c0978f.fd != null) {
                    return false;
                }
            } else if (!this.fd.equals(c0978f.fd)) {
                return false;
            }
            if (this.fe == null) {
                if (c0978f.fe != null) {
                    return false;
                }
            } else if (!this.fe.equals(c0978f.fe)) {
                return false;
            }
            if (this.ff == null) {
                if (c0978f.ff != null) {
                    return false;
                }
            } else if (!this.ff.equals(c0978f.ff)) {
                return false;
            }
            if (this.fg == null) {
                if (c0978f.fg != null) {
                    return false;
                }
            } else if (!this.fg.equals(c0978f.fg)) {
                return false;
            }
            if (this.fh == null) {
                if (c0978f.fh != null) {
                    return false;
                }
            } else if (!this.fh.equals(c0978f.fh)) {
                return false;
            }
            if (Float.floatToIntBits(this.fi) != Float.floatToIntBits(c0978f.fi) || this.fj != c0978f.fj || !md.equals(this.fk, c0978f.fk) || this.fl != c0978f.fl) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0978f.amU == null || c0978f.amU.isEmpty();
            } else {
                return this.amU.equals(c0978f.amU);
            }
        }

        public C0978f m3513g(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                int b;
                Object obj;
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        b = mi.m1429b(lzVar, 10);
                        nw = this.eW == null ? 0 : this.eW.length;
                        obj = new String[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eW, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.readString();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.readString();
                        this.eW = obj;
                        continue;
                    case 18:
                        b = mi.m1429b(lzVar, 18);
                        nw = this.eX == null ? 0 : this.eX.length;
                        obj = new C0983a[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eX, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0983a();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0983a();
                        lzVar.m1368a(obj[nw]);
                        this.eX = obj;
                        continue;
                    case 26:
                        b = mi.m1429b(lzVar, 26);
                        nw = this.eY == null ? 0 : this.eY.length;
                        obj = new C0977e[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eY, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0977e();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0977e();
                        lzVar.m1368a(obj[nw]);
                        this.eY = obj;
                        continue;
                    case 34:
                        b = mi.m1429b(lzVar, 34);
                        nw = this.eZ == null ? 0 : this.eZ.length;
                        obj = new C0974b[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eZ, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0974b();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0974b();
                        lzVar.m1368a(obj[nw]);
                        this.eZ = obj;
                        continue;
                    case 42:
                        b = mi.m1429b(lzVar, 42);
                        nw = this.fa == null ? 0 : this.fa.length;
                        obj = new C0974b[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fa, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0974b();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0974b();
                        lzVar.m1368a(obj[nw]);
                        this.fa = obj;
                        continue;
                    case AdSize.PORTRAIT_AD_HEIGHT /*50*/:
                        b = mi.m1429b(lzVar, 50);
                        nw = this.fb == null ? 0 : this.fb.length;
                        obj = new C0974b[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fb, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0974b();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0974b();
                        lzVar.m1368a(obj[nw]);
                        this.fb = obj;
                        continue;
                    case 58:
                        b = mi.m1429b(lzVar, 58);
                        nw = this.fc == null ? 0 : this.fc.length;
                        obj = new C0979g[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fc, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0979g();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0979g();
                        lzVar.m1368a(obj[nw]);
                        this.fc = obj;
                        continue;
                    case 74:
                        this.fd = lzVar.readString();
                        continue;
                    case 82:
                        this.fe = lzVar.readString();
                        continue;
                    case 98:
                        this.ff = lzVar.readString();
                        continue;
                    case 106:
                        this.fg = lzVar.readString();
                        continue;
                    case 114:
                        if (this.fh == null) {
                            this.fh = new C0973a();
                        }
                        lzVar.m1368a(this.fh);
                        continue;
                    case 125:
                        this.fi = lzVar.readFloat();
                        continue;
                    case 130:
                        b = mi.m1429b(lzVar, 130);
                        nw = this.fk == null ? 0 : this.fk.length;
                        obj = new String[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fk, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.readString();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.readString();
                        this.fk = obj;
                        continue;
                    case 136:
                        this.fl = lzVar.nz();
                        continue;
                    case 144:
                        this.fj = lzVar.nA();
                        continue;
                    case 154:
                        b = mi.m1429b(lzVar, 154);
                        nw = this.eV == null ? 0 : this.eV.length;
                        obj = new String[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.eV, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.readString();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.readString();
                        this.eV = obj;
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((((((this.fj ? 1231 : 1237) + (((((this.fh == null ? 0 : this.fh.hashCode()) + (((this.fg == null ? 0 : this.fg.hashCode()) + (((this.ff == null ? 0 : this.ff.hashCode()) + (((this.fe == null ? 0 : this.fe.hashCode()) + (((this.fd == null ? 0 : this.fd.hashCode()) + ((((((((((((((((md.hashCode(this.eV) + 527) * 31) + md.hashCode(this.eW)) * 31) + md.hashCode(this.eX)) * 31) + md.hashCode(this.eY)) * 31) + md.hashCode(this.eZ)) * 31) + md.hashCode(this.fa)) * 31) + md.hashCode(this.fb)) * 31) + md.hashCode(this.fc)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31) + Float.floatToIntBits(this.fi)) * 31)) * 31) + md.hashCode(this.fk)) * 31) + this.fl) * 31;
            if (!(this.amU == null || this.amU.isEmpty())) {
                i = this.amU.hashCode();
            }
            return hashCode + i;
        }

        public C0978f m3514k() {
            this.eV = mi.anf;
            this.eW = mi.anf;
            this.eX = C0983a.m3556r();
            this.eY = C0977e.m3503i();
            this.eZ = C0974b.m3486d();
            this.fa = C0974b.m3486d();
            this.fb = C0974b.m3486d();
            this.fc = C0979g.m3515l();
            this.fd = "";
            this.fe = "";
            this.ff = "0";
            this.fg = "";
            this.fh = null;
            this.fi = 0.0f;
            this.fj = false;
            this.fk = mi.anf;
            this.fl = 0;
            this.amU = null;
            this.amY = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.g */
    public static final class C0979g extends mb<C0979g> {
        private static volatile C0979g[] fm;
        public int[] fn;
        public int[] fo;
        public int[] fp;
        public int[] fq;
        public int[] fr;
        public int[] fs;
        public int[] ft;
        public int[] fu;
        public int[] fv;
        public int[] fw;

        public C0979g() {
            m3520m();
        }

        public static C0979g[] m3515l() {
            if (fm == null) {
                synchronized (md.amX) {
                    if (fm == null) {
                        fm = new C0979g[0];
                    }
                }
            }
            return fm;
        }

        public void m3516a(ma maVar) throws IOException {
            int i = 0;
            if (this.fn != null && this.fn.length > 0) {
                for (int p : this.fn) {
                    maVar.m1410p(1, p);
                }
            }
            if (this.fo != null && this.fo.length > 0) {
                for (int p2 : this.fo) {
                    maVar.m1410p(2, p2);
                }
            }
            if (this.fp != null && this.fp.length > 0) {
                for (int p22 : this.fp) {
                    maVar.m1410p(3, p22);
                }
            }
            if (this.fq != null && this.fq.length > 0) {
                for (int p222 : this.fq) {
                    maVar.m1410p(4, p222);
                }
            }
            if (this.fr != null && this.fr.length > 0) {
                for (int p2222 : this.fr) {
                    maVar.m1410p(5, p2222);
                }
            }
            if (this.fs != null && this.fs.length > 0) {
                for (int p22222 : this.fs) {
                    maVar.m1410p(6, p22222);
                }
            }
            if (this.ft != null && this.ft.length > 0) {
                for (int p222222 : this.ft) {
                    maVar.m1410p(7, p222222);
                }
            }
            if (this.fu != null && this.fu.length > 0) {
                for (int p2222222 : this.fu) {
                    maVar.m1410p(8, p2222222);
                }
            }
            if (this.fv != null && this.fv.length > 0) {
                for (int p22222222 : this.fv) {
                    maVar.m1410p(9, p22222222);
                }
            }
            if (this.fw != null && this.fw.length > 0) {
                while (i < this.fw.length) {
                    maVar.m1410p(10, this.fw[i]);
                    i++;
                }
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3517b(lz lzVar) throws IOException {
            return m3519h(lzVar);
        }

        protected int m3518c() {
            int i;
            int i2;
            int i3 = 0;
            int c = super.m2816c();
            if (this.fn == null || this.fn.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                for (int eE : this.fn) {
                    i2 += ma.eE(eE);
                }
                i = (c + i2) + (this.fn.length * 1);
            }
            if (this.fo != null && this.fo.length > 0) {
                c = 0;
                for (int eE2 : this.fo) {
                    c += ma.eE(eE2);
                }
                i = (i + c) + (this.fo.length * 1);
            }
            if (this.fp != null && this.fp.length > 0) {
                c = 0;
                for (int eE22 : this.fp) {
                    c += ma.eE(eE22);
                }
                i = (i + c) + (this.fp.length * 1);
            }
            if (this.fq != null && this.fq.length > 0) {
                c = 0;
                for (int eE222 : this.fq) {
                    c += ma.eE(eE222);
                }
                i = (i + c) + (this.fq.length * 1);
            }
            if (this.fr != null && this.fr.length > 0) {
                c = 0;
                for (int eE2222 : this.fr) {
                    c += ma.eE(eE2222);
                }
                i = (i + c) + (this.fr.length * 1);
            }
            if (this.fs != null && this.fs.length > 0) {
                c = 0;
                for (int eE22222 : this.fs) {
                    c += ma.eE(eE22222);
                }
                i = (i + c) + (this.fs.length * 1);
            }
            if (this.ft != null && this.ft.length > 0) {
                c = 0;
                for (int eE222222 : this.ft) {
                    c += ma.eE(eE222222);
                }
                i = (i + c) + (this.ft.length * 1);
            }
            if (this.fu != null && this.fu.length > 0) {
                c = 0;
                for (int eE2222222 : this.fu) {
                    c += ma.eE(eE2222222);
                }
                i = (i + c) + (this.fu.length * 1);
            }
            if (this.fv != null && this.fv.length > 0) {
                c = 0;
                for (int eE22222222 : this.fv) {
                    c += ma.eE(eE22222222);
                }
                i = (i + c) + (this.fv.length * 1);
            }
            if (this.fw == null || this.fw.length <= 0) {
                return i;
            }
            i2 = 0;
            while (i3 < this.fw.length) {
                i2 += ma.eE(this.fw[i3]);
                i3++;
            }
            return (i + i2) + (this.fw.length * 1);
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0979g)) {
                return false;
            }
            C0979g c0979g = (C0979g) o;
            if (!md.equals(this.fn, c0979g.fn) || !md.equals(this.fo, c0979g.fo) || !md.equals(this.fp, c0979g.fp) || !md.equals(this.fq, c0979g.fq) || !md.equals(this.fr, c0979g.fr) || !md.equals(this.fs, c0979g.fs) || !md.equals(this.ft, c0979g.ft) || !md.equals(this.fu, c0979g.fu) || !md.equals(this.fv, c0979g.fv) || !md.equals(this.fw, c0979g.fw)) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0979g.amU == null || c0979g.amU.isEmpty();
            } else {
                return this.amU.equals(c0979g.amU);
            }
        }

        public C0979g m3519h(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                int b;
                Object obj;
                int ex;
                Object obj2;
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case DetectedActivity.RUNNING /*8*/:
                        b = mi.m1429b(lzVar, 8);
                        nw = this.fn == null ? 0 : this.fn.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fn, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fn = obj;
                        continue;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fn == null ? 0 : this.fn.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fn, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fn = obj2;
                        lzVar.ey(ex);
                        continue;
                    case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                        b = mi.m1429b(lzVar, 16);
                        nw = this.fo == null ? 0 : this.fo.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fo, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fo = obj;
                        continue;
                    case 18:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fo == null ? 0 : this.fo.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fo, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fo = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 24:
                        b = mi.m1429b(lzVar, 24);
                        nw = this.fp == null ? 0 : this.fp.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fp, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fp = obj;
                        continue;
                    case 26:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fp == null ? 0 : this.fp.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fp, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fp = obj2;
                        lzVar.ey(ex);
                        continue;
                    case AdSize.LANDSCAPE_AD_HEIGHT /*32*/:
                        b = mi.m1429b(lzVar, 32);
                        nw = this.fq == null ? 0 : this.fq.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fq, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fq = obj;
                        continue;
                    case 34:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fq == null ? 0 : this.fq.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fq, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fq = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 40:
                        b = mi.m1429b(lzVar, 40);
                        nw = this.fr == null ? 0 : this.fr.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fr, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fr = obj;
                        continue;
                    case 42:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fr == null ? 0 : this.fr.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fr, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fr = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 48:
                        b = mi.m1429b(lzVar, 48);
                        nw = this.fs == null ? 0 : this.fs.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fs, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fs = obj;
                        continue;
                    case AdSize.PORTRAIT_AD_HEIGHT /*50*/:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fs == null ? 0 : this.fs.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fs, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fs = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 56:
                        b = mi.m1429b(lzVar, 56);
                        nw = this.ft == null ? 0 : this.ft.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.ft, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.ft = obj;
                        continue;
                    case 58:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.ft == null ? 0 : this.ft.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.ft, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.ft = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 64:
                        b = mi.m1429b(lzVar, 64);
                        nw = this.fu == null ? 0 : this.fu.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fu, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fu = obj;
                        continue;
                    case 66:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fu == null ? 0 : this.fu.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fu, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fu = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 72:
                        b = mi.m1429b(lzVar, 72);
                        nw = this.fv == null ? 0 : this.fv.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fv, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fv = obj;
                        continue;
                    case 74:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fv == null ? 0 : this.fv.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fv, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fv = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 80:
                        b = mi.m1429b(lzVar, 80);
                        nw = this.fw == null ? 0 : this.fw.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fw, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fw = obj;
                        continue;
                    case 82:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fw == null ? 0 : this.fw.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fw, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fw = obj2;
                        lzVar.ey(ex);
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public int hashCode() {
            int hashCode = (((((((((((((((((((md.hashCode(this.fn) + 527) * 31) + md.hashCode(this.fo)) * 31) + md.hashCode(this.fp)) * 31) + md.hashCode(this.fq)) * 31) + md.hashCode(this.fr)) * 31) + md.hashCode(this.fs)) * 31) + md.hashCode(this.ft)) * 31) + md.hashCode(this.fu)) * 31) + md.hashCode(this.fv)) * 31) + md.hashCode(this.fw)) * 31;
            int hashCode2 = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode2 + hashCode;
        }

        public C0979g m3520m() {
            this.fn = mi.ana;
            this.fo = mi.ana;
            this.fp = mi.ana;
            this.fq = mi.ana;
            this.fr = mi.ana;
            this.fs = mi.ana;
            this.ft = mi.ana;
            this.fu = mi.ana;
            this.fv = mi.ana;
            this.fw = mi.ana;
            this.amU = null;
            this.amY = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.h */
    public static final class C0980h extends mb<C0980h> {
        public static final mc<C0983a, C0980h> fx;
        private static final C0980h[] fy;
        public int[] fA;
        public int[] fB;
        public int fC;
        public int[] fD;
        public int fE;
        public int fF;
        public int[] fz;

        static {
            fx = mc.m1415a(11, C0980h.class, 810);
            fy = new C0980h[0];
        }

        public C0980h() {
            m3525n();
        }

        public void m3521a(ma maVar) throws IOException {
            int i = 0;
            if (this.fz != null && this.fz.length > 0) {
                for (int p : this.fz) {
                    maVar.m1410p(1, p);
                }
            }
            if (this.fA != null && this.fA.length > 0) {
                for (int p2 : this.fA) {
                    maVar.m1410p(2, p2);
                }
            }
            if (this.fB != null && this.fB.length > 0) {
                for (int p22 : this.fB) {
                    maVar.m1410p(3, p22);
                }
            }
            if (this.fC != 0) {
                maVar.m1410p(4, this.fC);
            }
            if (this.fD != null && this.fD.length > 0) {
                while (i < this.fD.length) {
                    maVar.m1410p(5, this.fD[i]);
                    i++;
                }
            }
            if (this.fE != 0) {
                maVar.m1410p(6, this.fE);
            }
            if (this.fF != 0) {
                maVar.m1410p(7, this.fF);
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3522b(lz lzVar) throws IOException {
            return m3524i(lzVar);
        }

        protected int m3523c() {
            int i;
            int i2;
            int i3 = 0;
            int c = super.m2816c();
            if (this.fz == null || this.fz.length <= 0) {
                i = c;
            } else {
                i2 = 0;
                for (int eE : this.fz) {
                    i2 += ma.eE(eE);
                }
                i = (c + i2) + (this.fz.length * 1);
            }
            if (this.fA != null && this.fA.length > 0) {
                c = 0;
                for (int eE2 : this.fA) {
                    c += ma.eE(eE2);
                }
                i = (i + c) + (this.fA.length * 1);
            }
            if (this.fB != null && this.fB.length > 0) {
                c = 0;
                for (int eE22 : this.fB) {
                    c += ma.eE(eE22);
                }
                i = (i + c) + (this.fB.length * 1);
            }
            if (this.fC != 0) {
                i += ma.m1389r(4, this.fC);
            }
            if (this.fD != null && this.fD.length > 0) {
                i2 = 0;
                while (i3 < this.fD.length) {
                    i2 += ma.eE(this.fD[i3]);
                    i3++;
                }
                i = (i + i2) + (this.fD.length * 1);
            }
            if (this.fE != 0) {
                i += ma.m1389r(6, this.fE);
            }
            return this.fF != 0 ? i + ma.m1389r(7, this.fF) : i;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0980h)) {
                return false;
            }
            C0980h c0980h = (C0980h) o;
            if (!md.equals(this.fz, c0980h.fz) || !md.equals(this.fA, c0980h.fA) || !md.equals(this.fB, c0980h.fB) || this.fC != c0980h.fC || !md.equals(this.fD, c0980h.fD) || this.fE != c0980h.fE || this.fF != c0980h.fF) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0980h.amU == null || c0980h.amU.isEmpty();
            } else {
                return this.amU.equals(c0980h.amU);
            }
        }

        public int hashCode() {
            int hashCode = (((((((((((((md.hashCode(this.fz) + 527) * 31) + md.hashCode(this.fA)) * 31) + md.hashCode(this.fB)) * 31) + this.fC) * 31) + md.hashCode(this.fD)) * 31) + this.fE) * 31) + this.fF) * 31;
            int hashCode2 = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode2 + hashCode;
        }

        public C0980h m3524i(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                int b;
                Object obj;
                int ex;
                Object obj2;
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case DetectedActivity.RUNNING /*8*/:
                        b = mi.m1429b(lzVar, 8);
                        nw = this.fz == null ? 0 : this.fz.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fz, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fz = obj;
                        continue;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fz == null ? 0 : this.fz.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fz, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fz = obj2;
                        lzVar.ey(ex);
                        continue;
                    case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                        b = mi.m1429b(lzVar, 16);
                        nw = this.fA == null ? 0 : this.fA.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fA, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fA = obj;
                        continue;
                    case 18:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fA == null ? 0 : this.fA.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fA, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fA = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 24:
                        b = mi.m1429b(lzVar, 24);
                        nw = this.fB == null ? 0 : this.fB.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fB, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fB = obj;
                        continue;
                    case 26:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fB == null ? 0 : this.fB.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fB, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fB = obj2;
                        lzVar.ey(ex);
                        continue;
                    case AdSize.LANDSCAPE_AD_HEIGHT /*32*/:
                        this.fC = lzVar.nz();
                        continue;
                    case 40:
                        b = mi.m1429b(lzVar, 40);
                        nw = this.fD == null ? 0 : this.fD.length;
                        obj = new int[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fD, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = lzVar.nz();
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = lzVar.nz();
                        this.fD = obj;
                        continue;
                    case 42:
                        ex = lzVar.ex(lzVar.nD());
                        b = lzVar.getPosition();
                        nw = 0;
                        while (lzVar.nI() > 0) {
                            lzVar.nz();
                            nw++;
                        }
                        lzVar.ez(b);
                        b = this.fD == null ? 0 : this.fD.length;
                        obj2 = new int[(nw + b)];
                        if (b != 0) {
                            System.arraycopy(this.fD, 0, obj2, 0, b);
                        }
                        while (b < obj2.length) {
                            obj2[b] = lzVar.nz();
                            b++;
                        }
                        this.fD = obj2;
                        lzVar.ey(ex);
                        continue;
                    case 48:
                        this.fE = lzVar.nz();
                        continue;
                    case 56:
                        this.fF = lzVar.nz();
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C0980h m3525n() {
            this.fz = mi.ana;
            this.fA = mi.ana;
            this.fB = mi.ana;
            this.fC = 0;
            this.fD = mi.ana;
            this.fE = 0;
            this.fF = 0;
            this.amU = null;
            this.amY = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.i */
    public static final class C0981i extends mb<C0981i> {
        private static volatile C0981i[] fG;
        public C0983a fH;
        public C0976d fI;
        public String name;

        public C0981i() {
            m3531p();
        }

        public static C0981i[] m3526o() {
            if (fG == null) {
                synchronized (md.amX) {
                    if (fG == null) {
                        fG = new C0981i[0];
                    }
                }
            }
            return fG;
        }

        public void m3527a(ma maVar) throws IOException {
            if (!this.name.equals("")) {
                maVar.m1404b(1, this.name);
            }
            if (this.fH != null) {
                maVar.m1398a(2, this.fH);
            }
            if (this.fI != null) {
                maVar.m1398a(3, this.fI);
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3528b(lz lzVar) throws IOException {
            return m3530j(lzVar);
        }

        protected int m3529c() {
            int c = super.m2816c();
            if (!this.name.equals("")) {
                c += ma.m1387h(1, this.name);
            }
            if (this.fH != null) {
                c += ma.m1377b(2, this.fH);
            }
            return this.fI != null ? c + ma.m1377b(3, this.fI) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0981i)) {
                return false;
            }
            C0981i c0981i = (C0981i) o;
            if (this.name == null) {
                if (c0981i.name != null) {
                    return false;
                }
            } else if (!this.name.equals(c0981i.name)) {
                return false;
            }
            if (this.fH == null) {
                if (c0981i.fH != null) {
                    return false;
                }
            } else if (!this.fH.equals(c0981i.fH)) {
                return false;
            }
            if (this.fI == null) {
                if (c0981i.fI != null) {
                    return false;
                }
            } else if (!this.fI.equals(c0981i.fI)) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0981i.amU == null || c0981i.amU.isEmpty();
            } else {
                return this.amU.equals(c0981i.amU);
            }
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.fI == null ? 0 : this.fI.hashCode()) + (((this.fH == null ? 0 : this.fH.hashCode()) + (((this.name == null ? 0 : this.name.hashCode()) + 527) * 31)) * 31)) * 31;
            if (!(this.amU == null || this.amU.isEmpty())) {
                i = this.amU.hashCode();
            }
            return hashCode + i;
        }

        public C0981i m3530j(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        this.name = lzVar.readString();
                        continue;
                    case 18:
                        if (this.fH == null) {
                            this.fH = new C0983a();
                        }
                        lzVar.m1368a(this.fH);
                        continue;
                    case 26:
                        if (this.fI == null) {
                            this.fI = new C0976d();
                        }
                        lzVar.m1368a(this.fI);
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C0981i m3531p() {
            this.name = "";
            this.fH = null;
            this.fI = null;
            this.amU = null;
            this.amY = -1;
            return this;
        }
    }

    /* renamed from: com.google.android.gms.internal.c.j */
    public static final class C0982j extends mb<C0982j> {
        public C0981i[] fJ;
        public C0978f fK;
        public String fL;

        public C0982j() {
            m3537q();
        }

        public static C0982j m3532b(byte[] bArr) throws me {
            return (C0982j) mf.m1419a(new C0982j(), bArr);
        }

        public void m3533a(ma maVar) throws IOException {
            if (this.fJ != null && this.fJ.length > 0) {
                for (mf mfVar : this.fJ) {
                    if (mfVar != null) {
                        maVar.m1398a(1, mfVar);
                    }
                }
            }
            if (this.fK != null) {
                maVar.m1398a(2, this.fK);
            }
            if (!this.fL.equals("")) {
                maVar.m1404b(3, this.fL);
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3534b(lz lzVar) throws IOException {
            return m3536k(lzVar);
        }

        protected int m3535c() {
            int c = super.m2816c();
            if (this.fJ != null && this.fJ.length > 0) {
                for (mf mfVar : this.fJ) {
                    if (mfVar != null) {
                        c += ma.m1377b(1, mfVar);
                    }
                }
            }
            if (this.fK != null) {
                c += ma.m1377b(2, this.fK);
            }
            return !this.fL.equals("") ? c + ma.m1387h(3, this.fL) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0982j)) {
                return false;
            }
            C0982j c0982j = (C0982j) o;
            if (!md.equals(this.fJ, c0982j.fJ)) {
                return false;
            }
            if (this.fK == null) {
                if (c0982j.fK != null) {
                    return false;
                }
            } else if (!this.fK.equals(c0982j.fK)) {
                return false;
            }
            if (this.fL == null) {
                if (c0982j.fL != null) {
                    return false;
                }
            } else if (!this.fL.equals(c0982j.fL)) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0982j.amU == null || c0982j.amU.isEmpty();
            } else {
                return this.amU.equals(c0982j.amU);
            }
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.fL == null ? 0 : this.fL.hashCode()) + (((this.fK == null ? 0 : this.fK.hashCode()) + ((md.hashCode(this.fJ) + 527) * 31)) * 31)) * 31;
            if (!(this.amU == null || this.amU.isEmpty())) {
                i = this.amU.hashCode();
            }
            return hashCode + i;
        }

        public C0982j m3536k(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        int b = mi.m1429b(lzVar, 10);
                        nw = this.fJ == null ? 0 : this.fJ.length;
                        Object obj = new C0981i[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.fJ, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0981i();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0981i();
                        lzVar.m1368a(obj[nw]);
                        this.fJ = obj;
                        continue;
                    case 18:
                        if (this.fK == null) {
                            this.fK = new C0978f();
                        }
                        lzVar.m1368a(this.fK);
                        continue;
                    case 26:
                        this.fL = lzVar.readString();
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C0982j m3537q() {
            this.fJ = C0981i.m3526o();
            this.fK = null;
            this.fL = "";
            this.amU = null;
            this.amY = -1;
            return this;
        }
    }
}
