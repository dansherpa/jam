package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;

public class fr implements Creator<fq> {
    static void m1074a(fq fqVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m240a(parcel, 1, fqVar.name, false);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, fqVar.xJ);
        C0072b.m240a(parcel, 2, fqVar.xY, false);
        C0072b.m243a(parcel, 3, fqVar.xZ);
        C0072b.m252c(parcel, 4, fqVar.weight);
        C0072b.m243a(parcel, 5, fqVar.ya);
        C0072b.m240a(parcel, 6, fqVar.yb, false);
        C0072b.m246a(parcel, 7, fqVar.yc, i, false);
        C0072b.m245a(parcel, 8, fqVar.yd, false);
        C0072b.m240a(parcel, 11, fqVar.ye, false);
        C0072b.m228G(parcel, C);
    }

    public fq[] m1075J(int i) {
        return new fq[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1076p(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1075J(x0);
    }

    public fq m1076p(Parcel parcel) {
        boolean z = false;
        String str = null;
        int B = C0071a.m189B(parcel);
        int i = 1;
        int[] iArr = null;
        fn[] fnVarArr = null;
        String str2 = null;
        boolean z2 = false;
        String str3 = null;
        String str4 = null;
        int i2 = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    str4 = C0071a.m213o(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str3 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    z2 = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    fnVarArr = (fn[]) C0071a.m199b(parcel, A, fn.CREATOR);
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    iArr = C0071a.m219u(parcel, A);
                    break;
                case C0450R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new fq(i2, str4, str3, z2, i, z, str2, fnVarArr, iArr, str);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }
}
