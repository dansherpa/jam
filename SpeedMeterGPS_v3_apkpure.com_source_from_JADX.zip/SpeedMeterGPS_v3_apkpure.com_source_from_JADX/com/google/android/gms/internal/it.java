package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.SearchableOrderedMetadataField;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.metadata.internal.C1073d;
import java.util.Date;

public class it {
    public static final C1142a Kt;
    public static final C1143b Ku;
    public static final C1145d Kv;
    public static final C1144c Kw;
    public static final C1146e Kx;

    /* renamed from: com.google.android.gms.internal.it.a */
    public static class C1142a extends C1073d implements SortableMetadataField<Date> {
        public C1142a(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.it.b */
    public static class C1143b extends C1073d implements SearchableOrderedMetadataField<Date>, SortableMetadataField<Date> {
        public C1143b(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.it.c */
    public static class C1144c extends C1073d implements SortableMetadataField<Date> {
        public C1144c(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.it.d */
    public static class C1145d extends C1073d implements SearchableOrderedMetadataField<Date>, SortableMetadataField<Date> {
        public C1145d(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.it.e */
    public static class C1146e extends C1073d implements SearchableOrderedMetadataField<Date>, SortableMetadataField<Date> {
        public C1146e(String str, int i) {
            super(str, i);
        }
    }

    static {
        Kt = new C1142a("created", 4100000);
        Ku = new C1143b("lastOpenedTime", 4300000);
        Kv = new C1145d("modified", 4100000);
        Kw = new C1144c("modifiedByMe", 4100000);
        Kx = new C1146e("sharedWithMe", 4100000);
    }
}
