package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;

public interface gn extends IInterface {

    /* renamed from: com.google.android.gms.internal.gn.a */
    public static abstract class C0643a extends Binder implements gn {
        public C0643a() {
            attachInterface(this, "com.google.android.gms.cast.internal.ICastDeviceControllerListener");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            boolean z = false;
            gk gkVar = null;
            switch (code) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1118T(data.readInt());
                    return true;
                case DataEvent.TYPE_DELETED /*2*/:
                    ApplicationMetadata applicationMetadata;
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    if (data.readInt() != 0) {
                        applicationMetadata = (ApplicationMetadata) ApplicationMetadata.CREATOR.createFromParcel(data);
                    }
                    String readString = data.readString();
                    String readString2 = data.readString();
                    if (data.readInt() != 0) {
                        z = true;
                    }
                    m1122a(applicationMetadata, readString, readString2, z);
                    return true;
                case DetectedActivity.STILL /*3*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1119U(data.readInt());
                    return true;
                case DetectedActivity.UNKNOWN /*4*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    String readString3 = data.readString();
                    double readDouble = data.readDouble();
                    if (data.readInt() != 0) {
                        z = true;
                    }
                    m1123a(readString3, readDouble, z);
                    return true;
                case DetectedActivity.TILTING /*5*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1129g(data.readString(), data.readString());
                    return true;
                case Quest.STATE_FAILED /*6*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1128b(data.readString(), data.createByteArray());
                    return true;
                case DetectedActivity.WALKING /*7*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1121W(data.readInt());
                    return true;
                case DetectedActivity.RUNNING /*8*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1120V(data.readInt());
                    return true;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    onApplicationDisconnected(data.readInt());
                    return true;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1125a(data.readString(), data.readLong(), data.readInt());
                    return true;
                case C0450R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    m1124a(data.readString(), data.readLong());
                    return true;
                case C0450R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    gf gfVar;
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    if (data.readInt() != 0) {
                        gfVar = (gf) gf.CREATOR.createFromParcel(data);
                    }
                    m1126b(gfVar);
                    return true;
                case C0450R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    data.enforceInterface("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    if (data.readInt() != 0) {
                        gkVar = (gk) gk.CREATOR.createFromParcel(data);
                    }
                    m1127b(gkVar);
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.cast.internal.ICastDeviceControllerListener");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void m1118T(int i) throws RemoteException;

    void m1119U(int i) throws RemoteException;

    void m1120V(int i) throws RemoteException;

    void m1121W(int i) throws RemoteException;

    void m1122a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z) throws RemoteException;

    void m1123a(String str, double d, boolean z) throws RemoteException;

    void m1124a(String str, long j) throws RemoteException;

    void m1125a(String str, long j, int i) throws RemoteException;

    void m1126b(gf gfVar) throws RemoteException;

    void m1127b(gk gkVar) throws RemoteException;

    void m1128b(String str, byte[] bArr) throws RemoteException;

    void m1129g(String str, String str2) throws RemoteException;

    void onApplicationDisconnected(int i) throws RemoteException;
}
