package com.google.android.gms.internal;

import com.google.android.gms.cast.Cast;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import java.io.IOException;

public final class lz {
    private int amK;
    private int amL;
    private int amM;
    private int amN;
    private int amO;
    private int amP;
    private int amQ;
    private int amR;
    private int amS;
    private final byte[] buffer;

    private lz(byte[] bArr, int i, int i2) {
        this.amP = Integer.MAX_VALUE;
        this.amR = 64;
        this.amS = 67108864;
        this.buffer = bArr;
        this.amK = i;
        this.amL = i + i2;
        this.amN = i;
    }

    public static long m1365A(long j) {
        return (j >>> 1) ^ (-(1 & j));
    }

    public static lz m1366a(byte[] bArr, int i, int i2) {
        return new lz(bArr, i, i2);
    }

    public static int ew(int i) {
        return (i >>> 1) ^ (-(i & 1));
    }

    private void nH() {
        this.amL += this.amM;
        int i = this.amL;
        if (i > this.amP) {
            this.amM = i - this.amP;
            this.amL -= this.amM;
            return;
        }
        this.amM = 0;
    }

    public static lz m1367p(byte[] bArr) {
        return m1366a(bArr, 0, bArr.length);
    }

    public void m1368a(mf mfVar) throws IOException {
        int nD = nD();
        if (this.amQ >= this.amR) {
            throw me.nT();
        }
        nD = ex(nD);
        this.amQ++;
        mfVar.m1424b(this);
        eu(0);
        this.amQ--;
        ey(nD);
    }

    public void m1369a(mf mfVar, int i) throws IOException {
        if (this.amQ >= this.amR) {
            throw me.nT();
        }
        this.amQ++;
        mfVar.m1424b(this);
        eu(mi.m1430u(i, 4));
        this.amQ--;
    }

    public byte[] eA(int i) throws IOException {
        if (i < 0) {
            throw me.nO();
        } else if (this.amN + i > this.amP) {
            eB(this.amP - this.amN);
            throw me.nN();
        } else if (i <= this.amL - this.amN) {
            Object obj = new byte[i];
            System.arraycopy(this.buffer, this.amN, obj, 0, i);
            this.amN += i;
            return obj;
        } else {
            throw me.nN();
        }
    }

    public void eB(int i) throws IOException {
        if (i < 0) {
            throw me.nO();
        } else if (this.amN + i > this.amP) {
            eB(this.amP - this.amN);
            throw me.nN();
        } else if (i <= this.amL - this.amN) {
            this.amN += i;
        } else {
            throw me.nN();
        }
    }

    public void eu(int i) throws me {
        if (this.amO != i) {
            throw me.nR();
        }
    }

    public boolean ev(int i) throws IOException {
        switch (mi.eN(i)) {
            case DetectedActivity.IN_VEHICLE /*0*/:
                nz();
                return true;
            case DataEvent.TYPE_CHANGED /*1*/:
                nG();
                return true;
            case DataEvent.TYPE_DELETED /*2*/:
                eB(nD());
                return true;
            case DetectedActivity.STILL /*3*/:
                nx();
                eu(mi.m1430u(mi.eO(i), 4));
                return true;
            case DetectedActivity.UNKNOWN /*4*/:
                return false;
            case DetectedActivity.TILTING /*5*/:
                nF();
                return true;
            default:
                throw me.nS();
        }
    }

    public int ex(int i) throws me {
        if (i < 0) {
            throw me.nO();
        }
        int i2 = this.amN + i;
        int i3 = this.amP;
        if (i2 > i3) {
            throw me.nN();
        }
        this.amP = i2;
        nH();
        return i3;
    }

    public void ey(int i) {
        this.amP = i;
        nH();
    }

    public void ez(int i) {
        if (i > this.amN - this.amK) {
            throw new IllegalArgumentException("Position " + i + " is beyond current " + (this.amN - this.amK));
        } else if (i < 0) {
            throw new IllegalArgumentException("Bad position " + i);
        } else {
            this.amN = this.amK + i;
        }
    }

    public int getPosition() {
        return this.amN - this.amK;
    }

    public boolean nA() throws IOException {
        return nD() != 0;
    }

    public int nB() throws IOException {
        return ew(nD());
    }

    public long nC() throws IOException {
        return m1365A(nE());
    }

    public int nD() throws IOException {
        byte nK = nK();
        if (nK >= null) {
            return nK;
        }
        int i = nK & 127;
        byte nK2 = nK();
        if (nK2 >= null) {
            return i | (nK2 << 7);
        }
        i |= (nK2 & 127) << 7;
        nK2 = nK();
        if (nK2 >= null) {
            return i | (nK2 << 14);
        }
        i |= (nK2 & 127) << 14;
        nK2 = nK();
        if (nK2 >= null) {
            return i | (nK2 << 21);
        }
        i |= (nK2 & 127) << 21;
        nK2 = nK();
        i |= nK2 << 28;
        if (nK2 >= null) {
            return i;
        }
        for (int i2 = 0; i2 < 5; i2++) {
            if (nK() >= null) {
                return i;
            }
        }
        throw me.nP();
    }

    public long nE() throws IOException {
        long j = 0;
        for (int i = 0; i < 64; i += 7) {
            byte nK = nK();
            j |= ((long) (nK & 127)) << i;
            if ((nK & Cast.MAX_NAMESPACE_LENGTH) == 0) {
                return j;
            }
        }
        throw me.nP();
    }

    public int nF() throws IOException {
        return (((nK() & 255) | ((nK() & 255) << 8)) | ((nK() & 255) << 16)) | ((nK() & 255) << 24);
    }

    public long nG() throws IOException {
        byte nK = nK();
        byte nK2 = nK();
        return ((((((((((long) nK2) & 255) << 8) | (((long) nK) & 255)) | ((((long) nK()) & 255) << 16)) | ((((long) nK()) & 255) << 24)) | ((((long) nK()) & 255) << 32)) | ((((long) nK()) & 255) << 40)) | ((((long) nK()) & 255) << 48)) | ((((long) nK()) & 255) << 56);
    }

    public int nI() {
        if (this.amP == Integer.MAX_VALUE) {
            return -1;
        }
        return this.amP - this.amN;
    }

    public boolean nJ() {
        return this.amN == this.amL;
    }

    public byte nK() throws IOException {
        if (this.amN == this.amL) {
            throw me.nN();
        }
        byte[] bArr = this.buffer;
        int i = this.amN;
        this.amN = i + 1;
        return bArr[i];
    }

    public int nw() throws IOException {
        if (nJ()) {
            this.amO = 0;
            return 0;
        }
        this.amO = nD();
        if (this.amO != 0) {
            return this.amO;
        }
        throw me.nQ();
    }

    public void nx() throws IOException {
        int nw;
        do {
            nw = nw();
            if (nw == 0) {
                return;
            }
        } while (ev(nw));
    }

    public long ny() throws IOException {
        return nE();
    }

    public int nz() throws IOException {
        return nD();
    }

    public byte[] m1370o(int i, int i2) {
        if (i2 == 0) {
            return mi.anh;
        }
        Object obj = new byte[i2];
        System.arraycopy(this.buffer, this.amK + i, obj, 0, i2);
        return obj;
    }

    public byte[] readBytes() throws IOException {
        int nD = nD();
        if (nD > this.amL - this.amN || nD <= 0) {
            return eA(nD);
        }
        Object obj = new byte[nD];
        System.arraycopy(this.buffer, this.amN, obj, 0, nD);
        this.amN = nD + this.amN;
        return obj;
    }

    public double readDouble() throws IOException {
        return Double.longBitsToDouble(nG());
    }

    public float readFloat() throws IOException {
        return Float.intBitsToFloat(nF());
    }

    public String readString() throws IOException {
        int nD = nD();
        if (nD > this.amL - this.amN || nD <= 0) {
            return new String(eA(nD), "UTF-8");
        }
        String str = new String(this.buffer, this.amN, nD, "UTF-8");
        this.amN = nD + this.amN;
        return str;
    }
}
