package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.internal.hz.C0657a;
import com.google.android.gms.internal.ic.C0660b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

public class ib implements Creator<C0660b> {
    static void m1254a(C0660b c0660b, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, c0660b.versionCode);
        C0072b.m240a(parcel, 2, c0660b.eM, false);
        C0072b.m236a(parcel, 3, c0660b.Hm, i, false);
        C0072b.m228G(parcel, C);
    }

    public C0660b m1255I(Parcel parcel) {
        C0657a c0657a = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    c0657a = (C0657a) C0071a.m194a(parcel, A, C0657a.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new C0660b(i, str, c0657a);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public C0660b[] ax(int i) {
        return new C0660b[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1255I(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ax(x0);
    }
}
