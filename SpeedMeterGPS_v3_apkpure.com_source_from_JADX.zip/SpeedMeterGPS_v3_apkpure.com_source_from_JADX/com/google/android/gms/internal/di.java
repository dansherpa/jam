package com.google.android.gms.internal;

import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.internal.dd.C0600a;

public final class di extends C0600a {
    private final InAppPurchaseListener mz;

    public di(InAppPurchaseListener inAppPurchaseListener) {
        this.mz = inAppPurchaseListener;
    }

    public void m3562a(dc dcVar) {
        this.mz.onInAppPurchaseRequested(new dl(dcVar));
    }
}
