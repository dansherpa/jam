package com.google.android.gms.internal;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.C0048b;
import com.google.android.gms.common.api.Api.C0049c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;

public final class fg {
    public static final C0049c<fy> xF;
    private static final C0048b<fy, NoOptions> xG;
    public static final Api<NoOptions> xH;
    public static final fu xI;

    /* renamed from: com.google.android.gms.internal.fg.1 */
    static class C06301 implements C0048b<fy, NoOptions> {
        C06301() {
        }

        public fy m2583a(Context context, Looper looper, gz gzVar, NoOptions noOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new fy(context, looper, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    static {
        xF = new C0049c();
        xG = new C06301();
        xH = new Api(xG, xF, new Scope[0]);
        xI = new fz();
    }
}
