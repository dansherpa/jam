package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties;
import com.google.android.gms.drive.metadata.internal.C0928j;
import java.util.Arrays;
import java.util.Collections;

public class is extends C0928j<AppVisibleCustomProperties> {
    public is(int i) {
        super("customFileProperties", Collections.emptyList(), Arrays.asList(new String[]{"customPropertiesExtra"}), i);
    }

    protected /* synthetic */ Object m4053b(DataHolder dataHolder, int i, int i2) {
        return m4054j(dataHolder, i, i2);
    }

    protected AppVisibleCustomProperties m4054j(DataHolder dataHolder, int i, int i2) {
        return (AppVisibleCustomProperties) dataHolder.eP().getSparseParcelableArray("customPropertiesExtra").get(i, AppVisibleCustomProperties.JK);
    }
}
