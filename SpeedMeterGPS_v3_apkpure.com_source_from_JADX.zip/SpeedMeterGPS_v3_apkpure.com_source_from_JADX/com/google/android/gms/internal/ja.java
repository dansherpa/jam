package com.google.android.gms.internal;

import android.content.Context;

public class ja {
    public static ja m1278a(Context context, String str, jk<jf> jkVar) {
        return null;
    }
}
