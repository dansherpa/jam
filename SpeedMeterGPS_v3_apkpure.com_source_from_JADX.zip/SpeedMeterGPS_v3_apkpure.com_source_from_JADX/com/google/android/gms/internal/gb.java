package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.appstate.AppStateBuffer;
import com.google.android.gms.appstate.AppStateManager.StateConflictResult;
import com.google.android.gms.appstate.AppStateManager.StateDeletedResult;
import com.google.android.gms.appstate.AppStateManager.StateListResult;
import com.google.android.gms.appstate.AppStateManager.StateLoadedResult;
import com.google.android.gms.appstate.AppStateManager.StateResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.C0502b;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.gd.C0640a;
import com.google.android.gms.internal.hc.C0993e;

public final class gb extends hc<gd> {
    private final String yN;

    /* renamed from: com.google.android.gms.internal.gb.b */
    private static final class C0987b implements StateDeletedResult {
        private final int yP;
        private final Status yw;

        public C0987b(Status status, int i) {
            this.yw = status;
            this.yP = i;
        }

        public int getStateKey() {
            return this.yP;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.internal.gb.d */
    private static final class C0988d extends C0502b implements StateListResult {
        private final AppStateBuffer yQ;

        public C0988d(DataHolder dataHolder) {
            super(dataHolder);
            this.yQ = new AppStateBuffer(dataHolder);
        }

        public AppStateBuffer getStateBuffer() {
            return this.yQ;
        }
    }

    /* renamed from: com.google.android.gms.internal.gb.f */
    private static final class C0989f extends C0502b implements StateConflictResult, StateLoadedResult, StateResult {
        private final int yP;
        private final AppStateBuffer yQ;

        public C0989f(int i, DataHolder dataHolder) {
            super(dataHolder);
            this.yP = i;
            this.yQ = new AppStateBuffer(dataHolder);
        }

        private boolean dR() {
            return this.yw.getStatusCode() == GamesStatusCodes.STATUS_REQUEST_UPDATE_PARTIAL_SUCCESS;
        }

        public StateConflictResult getConflictResult() {
            return dR() ? this : null;
        }

        public StateLoadedResult getLoadedResult() {
            return dR() ? null : this;
        }

        public byte[] getLocalData() {
            return this.yQ.getCount() == 0 ? null : this.yQ.get(0).getLocalData();
        }

        public String getResolvedVersion() {
            return this.yQ.getCount() == 0 ? null : this.yQ.get(0).getConflictVersion();
        }

        public byte[] getServerData() {
            return this.yQ.getCount() == 0 ? null : this.yQ.get(0).getConflictData();
        }

        public int getStateKey() {
            return this.yP;
        }

        public void release() {
            this.yQ.close();
        }
    }

    /* renamed from: com.google.android.gms.internal.gb.a */
    private static final class C1080a extends ga {
        private final C0052d<StateDeletedResult> yO;

        public C1080a(C0052d<StateDeletedResult> c0052d) {
            this.yO = (C0052d) hn.m1226b((Object) c0052d, (Object) "Result holder must not be null");
        }

        public void m4046b(int i, int i2) {
            this.yO.m147a(new C0987b(new Status(i), i2));
        }
    }

    /* renamed from: com.google.android.gms.internal.gb.c */
    private static final class C1081c extends ga {
        private final C0052d<StateListResult> yO;

        public C1081c(C0052d<StateListResult> c0052d) {
            this.yO = (C0052d) hn.m1226b((Object) c0052d, (Object) "Result holder must not be null");
        }

        public void m4047a(DataHolder dataHolder) {
            this.yO.m147a(new C0988d(dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.gb.e */
    private static final class C1082e extends ga {
        private final C0052d<StateResult> yO;

        public C1082e(C0052d<StateResult> c0052d) {
            this.yO = (C0052d) hn.m1226b((Object) c0052d, (Object) "Result holder must not be null");
        }

        public void m4048a(int i, DataHolder dataHolder) {
            this.yO.m147a(new C0989f(i, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.gb.g */
    private static final class C1083g extends ga {
        private final C0052d<Status> yO;

        public C1083g(C0052d<Status> c0052d) {
            this.yO = (C0052d) hn.m1226b((Object) c0052d, (Object) "Holder must not be null");
        }

        public void dO() {
            this.yO.m147a(new Status(0));
        }
    }

    public gb(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.yN = (String) hn.m1230f(str);
    }

    protected gd m3583D(IBinder iBinder) {
        return C0640a.m2613F(iBinder);
    }

    public void m3584a(C0052d<StateListResult> c0052d) {
        try {
            ((gd) fo()).m1091a(new C1081c(c0052d));
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m3585a(C0052d<StateDeletedResult> c0052d, int i) {
        try {
            ((gd) fo()).m1096b(new C1080a(c0052d), i);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m3586a(C0052d<StateResult> c0052d, int i, String str, byte[] bArr) {
        try {
            ((gd) fo()).m1093a(new C1082e(c0052d), i, str, bArr);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m3587a(C0052d<StateResult> c0052d, int i, byte[] bArr) {
        if (c0052d == null) {
            gc gcVar = null;
        } else {
            Object c1082e = new C1082e(c0052d);
        }
        try {
            ((gd) fo()).m1094a(gcVar, i, bArr);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    protected void m3588a(hj hjVar, C0993e c0993e) throws RemoteException {
        hjVar.m1188a((hi) c0993e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.yN, fn());
    }

    public void m3589b(C0052d<Status> c0052d) {
        try {
            ((gd) fo()).m1095b(new C1083g(c0052d));
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m3590b(C0052d<StateResult> c0052d, int i) {
        try {
            ((gd) fo()).m1092a(new C1082e(c0052d), i);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    protected void m3591b(String... strArr) {
        boolean z = false;
        for (String equals : strArr) {
            if (equals.equals(Scopes.APP_STATE)) {
                z = true;
            }
        }
        hn.m1224a(z, String.format("App State APIs requires %s to function.", new Object[]{Scopes.APP_STATE}));
    }

    protected String bp() {
        return "com.google.android.gms.appstate.service.START";
    }

    protected String bq() {
        return "com.google.android.gms.appstate.internal.IAppStateService";
    }

    public int dP() {
        try {
            return ((gd) fo()).dP();
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    public int dQ() {
        try {
            return ((gd) fo()).dQ();
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    protected /* synthetic */ IInterface m3592x(IBinder iBinder) {
        return m3583D(iBinder);
    }
}
