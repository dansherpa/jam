package com.google.android.gms.internal;

import android.net.Uri;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.Moments;
import com.google.android.gms.plus.Moments.LoadMomentsResult;
import com.google.android.gms.plus.Plus.C1096a;
import com.google.android.gms.plus.internal.C1039e;
import com.google.android.gms.plus.model.moments.Moment;
import com.google.android.gms.plus.model.moments.MomentBuffer;

public final class km implements Moments {

    /* renamed from: com.google.android.gms.internal.km.a */
    private static abstract class C1153a extends C1096a<LoadMomentsResult> {

        /* renamed from: com.google.android.gms.internal.km.a.1 */
        class C10041 implements LoadMomentsResult {
            final /* synthetic */ C1153a aci;
            final /* synthetic */ Status yG;

            C10041(C1153a c1153a, Status status) {
                this.aci = c1153a;
                this.yG = status;
            }

            public MomentBuffer getMomentBuffer() {
                return null;
            }

            public String getNextPageToken() {
                return null;
            }

            public Status getStatus() {
                return this.yG;
            }

            public String getUpdated() {
                return null;
            }

            public void release() {
            }
        }

        private C1153a() {
        }

        public LoadMomentsResult an(Status status) {
            return new C10041(this, status);
        }

        public /* synthetic */ Result m4245c(Status status) {
            return an(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.km.b */
    private static abstract class C1154b extends C1096a<Status> {
        private C1154b() {
        }

        public /* synthetic */ Result m4246c(Status status) {
            return m4247d(status);
        }

        public Status m4247d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.km.c */
    private static abstract class C1155c extends C1096a<Status> {
        private C1155c() {
        }

        public /* synthetic */ Result m4248c(Status status) {
            return m4249d(status);
        }

        public Status m4249d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.km.1 */
    class C13071 extends C1153a {
        final /* synthetic */ km acb;

        C13071(km kmVar) {
            this.acb = kmVar;
            super();
        }

        protected void m4645a(C1039e c1039e) {
            c1039e.m3791k(this);
        }
    }

    /* renamed from: com.google.android.gms.internal.km.2 */
    class C13082 extends C1153a {
        final /* synthetic */ int PJ;
        final /* synthetic */ km acb;
        final /* synthetic */ String acc;
        final /* synthetic */ Uri acd;
        final /* synthetic */ String ace;
        final /* synthetic */ String acf;

        C13082(km kmVar, int i, String str, Uri uri, String str2, String str3) {
            this.acb = kmVar;
            this.PJ = i;
            this.acc = str;
            this.acd = uri;
            this.ace = str2;
            this.acf = str3;
            super();
        }

        protected void m4647a(C1039e c1039e) {
            c1039e.m3786a(this, this.PJ, this.acc, this.acd, this.ace, this.acf);
        }
    }

    /* renamed from: com.google.android.gms.internal.km.3 */
    class C13093 extends C1155c {
        final /* synthetic */ km acb;
        final /* synthetic */ Moment acg;

        C13093(km kmVar, Moment moment) {
            this.acb = kmVar;
            this.acg = moment;
            super();
        }

        protected void m4649a(C1039e c1039e) {
            c1039e.m3787a((C0052d) this, this.acg);
        }
    }

    /* renamed from: com.google.android.gms.internal.km.4 */
    class C13104 extends C1154b {
        final /* synthetic */ km acb;
        final /* synthetic */ String ach;

        C13104(km kmVar, String str) {
            this.acb = kmVar;
            this.ach = str;
            super();
        }

        protected void m4651a(C1039e c1039e) {
            c1039e.removeMoment(this.ach);
            m1988b(Status.Ek);
        }
    }

    public PendingResult<LoadMomentsResult> load(GoogleApiClient googleApiClient) {
        return googleApiClient.m139a(new C13071(this));
    }

    public PendingResult<LoadMomentsResult> load(GoogleApiClient googleApiClient, int maxResults, String pageToken, Uri targetUrl, String type, String userId) {
        return googleApiClient.m139a(new C13082(this, maxResults, pageToken, targetUrl, type, userId));
    }

    public PendingResult<Status> remove(GoogleApiClient googleApiClient, String momentId) {
        return googleApiClient.m140b(new C13104(this, momentId));
    }

    public PendingResult<Status> write(GoogleApiClient googleApiClient, Moment moment) {
        return googleApiClient.m140b(new C13093(this, moment));
    }
}
