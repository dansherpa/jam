package com.google.android.gms.internal;

import com.google.android.gms.internal.C0176c.C0978f;
import com.google.android.gms.internal.C0176c.C0982j;
import com.google.android.gms.location.DetectedActivity;
import java.io.IOException;

public interface lf {

    /* renamed from: com.google.android.gms.internal.lf.a */
    public static final class C1015a extends mb<C1015a> {
        public long aiD;
        public C0982j aiE;
        public C0978f fK;

        public C1015a() {
            na();
        }

        public static C1015a m3700l(byte[] bArr) throws me {
            return (C1015a) mf.m1419a(new C1015a(), bArr);
        }

        public void m3701a(ma maVar) throws IOException {
            maVar.m1403b(1, this.aiD);
            if (this.fK != null) {
                maVar.m1398a(2, this.fK);
            }
            if (this.aiE != null) {
                maVar.m1398a(3, this.aiE);
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3702b(lz lzVar) throws IOException {
            return m3704p(lzVar);
        }

        protected int m3703c() {
            int c = super.m2816c() + ma.m1383d(1, this.aiD);
            if (this.fK != null) {
                c += ma.m1377b(2, this.fK);
            }
            return this.aiE != null ? c + ma.m1377b(3, this.aiE) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C1015a)) {
                return false;
            }
            C1015a c1015a = (C1015a) o;
            if (this.aiD != c1015a.aiD) {
                return false;
            }
            if (this.fK == null) {
                if (c1015a.fK != null) {
                    return false;
                }
            } else if (!this.fK.equals(c1015a.fK)) {
                return false;
            }
            if (this.aiE == null) {
                if (c1015a.aiE != null) {
                    return false;
                }
            } else if (!this.aiE.equals(c1015a.aiE)) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c1015a.amU == null || c1015a.amU.isEmpty();
            } else {
                return this.amU.equals(c1015a.amU);
            }
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.aiE == null ? 0 : this.aiE.hashCode()) + (((this.fK == null ? 0 : this.fK.hashCode()) + ((((int) (this.aiD ^ (this.aiD >>> 32))) + 527) * 31)) * 31)) * 31;
            if (!(this.amU == null || this.amU.isEmpty())) {
                i = this.amU.hashCode();
            }
            return hashCode + i;
        }

        public C1015a na() {
            this.aiD = 0;
            this.fK = null;
            this.aiE = null;
            this.amU = null;
            this.amY = -1;
            return this;
        }

        public C1015a m3704p(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case DetectedActivity.RUNNING /*8*/:
                        this.aiD = lzVar.ny();
                        continue;
                    case 18:
                        if (this.fK == null) {
                            this.fK = new C0978f();
                        }
                        lzVar.m1368a(this.fK);
                        continue;
                    case 26:
                        if (this.aiE == null) {
                            this.aiE = new C0982j();
                        }
                        lzVar.m1368a(this.aiE);
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }
}
