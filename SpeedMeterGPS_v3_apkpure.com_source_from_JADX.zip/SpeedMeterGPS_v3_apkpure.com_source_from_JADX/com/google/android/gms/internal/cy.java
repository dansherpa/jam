package com.google.android.gms.internal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import java.util.LinkedList;
import java.util.List;

public class cy {
    private static final Object lq;
    private static final String pp;
    private static cy pr;
    private final C0194a pq;

    /* renamed from: com.google.android.gms.internal.cy.a */
    public class C0194a extends SQLiteOpenHelper {
        final /* synthetic */ cy ps;

        public C0194a(cy cyVar, Context context, String str) {
            this.ps = cyVar;
            super(context, str, null, 4);
        }

        public void onCreate(SQLiteDatabase db) {
            db.execSQL(cy.pp);
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            ev.m1011B("Database updated from version " + oldVersion + " to version " + newVersion);
            db.execSQL("DROP TABLE IF EXISTS InAppPurchase");
            onCreate(db);
        }
    }

    static {
        pp = String.format("CREATE TABLE IF NOT EXISTS %s ( %s INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, %s TEXT NOT NULL, %s TEXT NOT NULL, %s INTEGER)", new Object[]{"InAppPurchase", "purchase_id", "product_id", "developer_payload", "record_time"});
        lq = new Object();
    }

    private cy(Context context) {
        this.pq = new C0194a(this, context, "google_inapp_purchase.db");
    }

    public static cy m873h(Context context) {
        cy cyVar;
        synchronized (lq) {
            if (pr == null) {
                pr = new cy(context);
            }
            cyVar = pr;
        }
        return cyVar;
    }

    public cw m874a(Cursor cursor) {
        return cursor == null ? null : new cw(cursor.getLong(0), cursor.getString(1), cursor.getString(2));
    }

    public void m875a(cw cwVar) {
        if (cwVar != null) {
            synchronized (lq) {
                SQLiteDatabase writableDatabase = getWritableDatabase();
                if (writableDatabase == null) {
                    return;
                }
                writableDatabase.delete("InAppPurchase", String.format("%s = %d", new Object[]{"purchase_id", Long.valueOf(cwVar.pj)}), null);
            }
        }
    }

    public void m876b(cw cwVar) {
        if (cwVar != null) {
            synchronized (lq) {
                SQLiteDatabase writableDatabase = getWritableDatabase();
                if (writableDatabase == null) {
                    return;
                }
                ContentValues contentValues = new ContentValues();
                contentValues.put("product_id", cwVar.pl);
                contentValues.put("developer_payload", cwVar.pk);
                contentValues.put("record_time", Long.valueOf(SystemClock.elapsedRealtime()));
                cwVar.pj = writableDatabase.insert("InAppPurchase", null, contentValues);
                if (((long) getRecordCount()) > 20000) {
                    bf();
                }
            }
        }
    }

    public void bf() {
        Cursor query;
        SQLiteException e;
        synchronized (lq) {
            SQLiteDatabase writableDatabase = getWritableDatabase();
            if (writableDatabase == null) {
                return;
            }
            try {
                query = writableDatabase.query("InAppPurchase", null, null, null, null, null, "record_time ASC", "1");
                if (query != null) {
                    try {
                        if (query.moveToFirst()) {
                            m875a(m874a(query));
                        }
                    } catch (SQLiteException e2) {
                        e = e2;
                        try {
                            ev.m1013D("Error remove oldest record" + e.getMessage());
                            if (query != null) {
                                query.close();
                            }
                        } catch (Throwable th) {
                            Throwable th2 = th;
                            if (query != null) {
                                query.close();
                            }
                            throw th2;
                        }
                    }
                }
                if (query != null) {
                    query.close();
                }
            } catch (SQLiteException e3) {
                e = e3;
                query = null;
                ev.m1013D("Error remove oldest record" + e.getMessage());
                if (query != null) {
                    query.close();
                }
            } catch (Throwable th3) {
                th2 = th3;
                query = null;
                if (query != null) {
                    query.close();
                }
                throw th2;
            }
        }
    }

    public List<cw> m877d(long j) {
        Cursor query;
        SQLiteException e;
        Throwable th;
        synchronized (lq) {
            List<cw> linkedList = new LinkedList();
            if (j <= 0) {
                return linkedList;
            }
            SQLiteDatabase writableDatabase = getWritableDatabase();
            if (writableDatabase == null) {
                return linkedList;
            }
            try {
                query = writableDatabase.query("InAppPurchase", null, null, null, null, null, "record_time ASC", String.valueOf(j));
                try {
                    if (query.moveToFirst()) {
                        do {
                            linkedList.add(m874a(query));
                        } while (query.moveToNext());
                    }
                    if (query != null) {
                        query.close();
                    }
                } catch (SQLiteException e2) {
                    e = e2;
                    try {
                        ev.m1013D("Error extracing purchase info: " + e.getMessage());
                        if (query != null) {
                            query.close();
                        }
                        return linkedList;
                    } catch (Throwable th2) {
                        th = th2;
                        if (query != null) {
                            query.close();
                        }
                        throw th;
                    }
                }
            } catch (SQLiteException e3) {
                e = e3;
                query = null;
                ev.m1013D("Error extracing purchase info: " + e.getMessage());
                if (query != null) {
                    query.close();
                }
                return linkedList;
            } catch (Throwable th3) {
                th = th3;
                query = null;
                if (query != null) {
                    query.close();
                }
                throw th;
            }
            return linkedList;
        }
    }

    public int getRecordCount() {
        Cursor cursor = null;
        int i = 0;
        synchronized (lq) {
            SQLiteDatabase writableDatabase = getWritableDatabase();
            if (writableDatabase == null) {
            } else {
                try {
                    cursor = writableDatabase.rawQuery("select count(*) from InAppPurchase", null);
                    if (cursor.moveToFirst()) {
                        i = cursor.getInt(0);
                        if (cursor != null) {
                            cursor.close();
                        }
                    } else {
                        if (cursor != null) {
                            cursor.close();
                        }
                    }
                } catch (SQLiteException e) {
                    ev.m1013D("Error getting record count" + e.getMessage());
                    if (cursor != null) {
                        cursor.close();
                    }
                } catch (Throwable th) {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        }
        return i;
    }

    public SQLiteDatabase getWritableDatabase() {
        try {
            return this.pq.getWritableDatabase();
        } catch (SQLiteException e) {
            ev.m1013D("Error opening writable conversion tracking database");
            return null;
        }
    }
}
