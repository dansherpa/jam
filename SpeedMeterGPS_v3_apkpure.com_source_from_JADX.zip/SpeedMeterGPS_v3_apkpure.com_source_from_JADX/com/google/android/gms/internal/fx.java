package com.google.android.gms.internal;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.fw.C0635a;

public abstract class fx<T> extends C0635a {
    protected C0052d<T> yr;

    public fx(C0052d<T> c0052d) {
        this.yr = c0052d;
    }

    public void m3573a(Status status) {
    }

    public void m3574a(Status status, ParcelFileDescriptor parcelFileDescriptor) {
    }

    public void m3575a(Status status, boolean z) {
    }
}
