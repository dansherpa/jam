package com.google.android.gms.internal;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.ads.purchase.InAppPurchaseActivity;
import com.google.android.gms.internal.de.C0602a;
import com.google.android.gms.location.GeofenceStatusCodes;

public class cv extends C0602a implements ServiceConnection {
    private dh oV;
    private cs oW;
    private final cy oX;
    private da oZ;
    private final Activity oe;
    private Context pf;
    private dc pg;
    private cw ph;
    private String pi;

    public cv(Activity activity) {
        this.pi = null;
        this.oe = activity;
        this.oX = cy.m873h(this.oe.getApplicationContext());
    }

    public static void m3554a(Context context, boolean z, cr crVar) {
        Intent intent = new Intent();
        intent.setClassName(context, InAppPurchaseActivity.CLASS_NAME);
        intent.putExtra("com.google.android.gms.ads.internal.purchase.useClientJar", z);
        cr.m2523a(intent, crVar);
        context.startActivity(intent);
    }

    private void m3555a(String str, boolean z, int i, Intent intent) {
        try {
            this.oV.m890a(new cx(this.pf, str, z, i, intent, this.ph));
        } catch (RemoteException e) {
            ev.m1013D("Fail to invoke PlayStorePurchaseListener.");
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == GeofenceStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES) {
            try {
                int c = cz.m879c(data);
                if (resultCode != -1 || c != 0) {
                    this.oX.m875a(this.ph);
                    m3555a(this.pg.getProductId(), false, resultCode, data);
                } else if (this.oZ.m884a(this.pi, resultCode, data)) {
                    m3555a(this.pg.getProductId(), true, resultCode, data);
                } else {
                    m3555a(this.pg.getProductId(), false, resultCode, data);
                }
                this.pg.recordPlayBillingResolution(c);
            } catch (RemoteException e) {
                ev.m1013D("Fail to process purchase result.");
            } finally {
                this.pi = null;
                this.oe.finish();
            }
        }
    }

    public void onCreate() {
        cr b = cr.m2524b(this.oe.getIntent());
        this.oV = b.kV;
        this.oZ = b.kX;
        this.pg = b.oR;
        this.oW = new cs(this.oe.getApplicationContext());
        this.pf = b.oS;
        Activity activity = this.oe;
        Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        this.oe.getApplicationContext();
        activity.bindService(intent, this, 1);
    }

    public void onDestroy() {
        this.oe.unbindService(this);
        this.oW.destroy();
    }

    public void onServiceConnected(ComponentName name, IBinder service) {
        Throwable e;
        this.oW.m872o(service);
        try {
            this.pi = this.oZ.bh();
            Bundle a = this.oW.m870a(this.oe.getPackageName(), this.pg.getProductId(), this.pi);
            PendingIntent pendingIntent = (PendingIntent) a.getParcelable("BUY_INTENT");
            if (pendingIntent == null) {
                int a2 = cz.m878a(a);
                this.pg.recordPlayBillingResolution(a2);
                m3555a(this.pg.getProductId(), false, a2, null);
                this.oe.finish();
                return;
            }
            this.ph = new cw(this.pg.getProductId(), this.pi);
            this.oX.m876b(this.ph);
            this.oe.startIntentSenderForResult(pendingIntent.getIntentSender(), GeofenceStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES, new Intent(), Integer.valueOf(0).intValue(), Integer.valueOf(0).intValue(), Integer.valueOf(0).intValue());
        } catch (RemoteException e2) {
            e = e2;
            ev.m1016c("Error when connecting in-app billing service", e);
            this.oe.finish();
        } catch (SendIntentException e3) {
            e = e3;
            ev.m1016c("Error when connecting in-app billing service", e);
            this.oe.finish();
        }
    }

    public void onServiceDisconnected(ComponentName name) {
        ev.m1011B("In-app billing service disconnected.");
        this.oW.destroy();
    }
}
