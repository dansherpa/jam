package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.internal.w */
public final class C0700w implements SafeParcelable {
    public static final C0275x CREATOR;
    public final boolean kZ;
    public final boolean lb;
    public final int versionCode;

    static {
        CREATOR = new C0275x();
    }

    C0700w(int i, boolean z, boolean z2) {
        this.versionCode = i;
        this.kZ = z;
        this.lb = z2;
    }

    public C0700w(boolean z, boolean z2) {
        this.versionCode = 1;
        this.kZ = z;
        this.lb = z2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        C0275x.m1459a(this, out, flags);
    }
}
