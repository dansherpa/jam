package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class fl implements SafeParcelable {
    public static final fm CREATOR;
    public static final int xQ;
    final int xJ;
    public final String xR;
    final fq xS;
    public final int xT;
    public final byte[] xU;

    static {
        xQ = Integer.parseInt("-1");
        CREATOR = new fm();
    }

    fl(int i, String str, fq fqVar, int i2, byte[] bArr) {
        boolean z = i2 == xQ || fp.m1068H(i2) != null;
        hn.m1228b(z, "Invalid section type " + i2);
        this.xJ = i;
        this.xR = str;
        this.xS = fqVar;
        this.xT = i2;
        this.xU = bArr;
        String dJ = dJ();
        if (dJ != null) {
            throw new IllegalArgumentException(dJ);
        }
    }

    public fl(String str, fq fqVar) {
        this(1, str, fqVar, xQ, null);
    }

    public fl(String str, fq fqVar, String str2) {
        this(1, str, fqVar, fp.m1069Y(str2), null);
    }

    public fl(byte[] bArr, fq fqVar) {
        this(1, null, fqVar, xQ, bArr);
    }

    public String dJ() {
        return (this.xT == xQ || fp.m1068H(this.xT) != null) ? (this.xR == null || this.xU == null) ? null : "Both content and blobContent set" : "Invalid section type " + this.xT;
    }

    public int describeContents() {
        fm fmVar = CREATOR;
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        fm fmVar = CREATOR;
        fm.m1062a(this, dest, flags);
    }
}
