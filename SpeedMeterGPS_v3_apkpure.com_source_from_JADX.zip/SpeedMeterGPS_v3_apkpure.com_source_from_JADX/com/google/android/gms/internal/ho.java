package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.view.View;
import com.google.android.gms.dynamic.C0155g;
import com.google.android.gms.dynamic.C0155g.C0154a;
import com.google.android.gms.dynamic.C0931e;
import com.google.android.gms.internal.hk.C0655a;

public final class ho extends C0155g<hk> {
    private static final ho GI;

    static {
        GI = new ho();
    }

    private ho() {
        super("com.google.android.gms.common.ui.SignInButtonCreatorImpl");
    }

    public static View m2698b(Context context, int i, int i2) throws C0154a {
        return GI.m2699c(context, i, i2);
    }

    private View m2699c(Context context, int i, int i2) throws C0154a {
        try {
            return (View) C0931e.m3241e(((hk) m462D(context)).m1217a(C0931e.m3242h(context), i, i2));
        } catch (Throwable e) {
            throw new C0154a("Could not get button with size " + i + " and color " + i2, e);
        }
    }

    public hk m2700N(IBinder iBinder) {
        return C0655a.m2697M(iBinder);
    }

    public /* synthetic */ Object m2701d(IBinder iBinder) {
        return m2700N(iBinder);
    }
}
