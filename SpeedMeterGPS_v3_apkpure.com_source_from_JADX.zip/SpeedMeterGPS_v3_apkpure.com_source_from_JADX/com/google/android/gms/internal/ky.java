package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.internal.kt.C1009b.C1008b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import java.util.HashSet;
import java.util.Set;

public class ky implements Creator<C1008b> {
    static void m1324a(C1008b c1008b, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        Set kf = c1008b.kf();
        if (kf.contains(Integer.valueOf(1))) {
            C0072b.m252c(parcel, 1, c1008b.getVersionCode());
        }
        if (kf.contains(Integer.valueOf(2))) {
            C0072b.m252c(parcel, 2, c1008b.getHeight());
        }
        if (kf.contains(Integer.valueOf(3))) {
            C0072b.m240a(parcel, 3, c1008b.getUrl(), true);
        }
        if (kf.contains(Integer.valueOf(4))) {
            C0072b.m252c(parcel, 4, c1008b.getWidth());
        }
        C0072b.m228G(parcel, C);
    }

    public C1008b bK(Parcel parcel) {
        int i = 0;
        int B = C0071a.m189B(parcel);
        Set hashSet = new HashSet();
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i3 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    i2 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case DetectedActivity.STILL /*3*/:
                    str = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(3));
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(4));
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new C1008b(hashSet, i3, i2, str, i);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bK(x0);
    }

    public C1008b[] dh(int i) {
        return new C1008b[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return dh(x0);
    }
}
