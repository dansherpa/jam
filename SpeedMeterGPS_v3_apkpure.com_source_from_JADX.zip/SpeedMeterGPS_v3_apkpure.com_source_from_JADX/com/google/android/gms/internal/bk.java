package com.google.android.gms.internal;

import android.location.Location;

public final class bk implements bj {
    public Location m2489a(long j) {
        return null;
    }

    public void init() {
    }
}
