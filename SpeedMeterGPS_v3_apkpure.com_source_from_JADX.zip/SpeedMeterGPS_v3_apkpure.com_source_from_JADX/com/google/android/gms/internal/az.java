package com.google.android.gms.internal;

public final class az {
    private String mO;
    private String mP;

    public az() {
        this.mO = null;
        this.mP = null;
        this.mO = "http://googleads.g.doubleclick.net/mads/static/mad/sdk/native/sdk-core-v40.html";
        this.mP = null;
    }

    public String aI() {
        return this.mO;
    }

    public String aJ() {
        return this.mP;
    }
}
