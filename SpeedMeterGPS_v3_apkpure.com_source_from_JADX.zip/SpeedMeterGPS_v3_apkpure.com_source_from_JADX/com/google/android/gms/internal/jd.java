package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingApi;
import com.google.android.gms.location.LocationClient.OnAddGeofencesResultListener;
import com.google.android.gms.location.LocationClient.OnRemoveGeofencesResultListener;
import com.google.android.gms.location.LocationServices.C1095a;
import com.google.android.gms.location.LocationStatusCodes;
import java.util.ArrayList;
import java.util.List;

public class jd implements GeofencingApi {

    /* renamed from: com.google.android.gms.internal.jd.a */
    private static abstract class C1149a extends C1095a<Status> {
        private C1149a() {
        }

        public /* synthetic */ Result m4238c(Status status) {
            return m4239d(status);
        }

        public Status m4239d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.jd.1 */
    class C13011 extends C1149a {
        final /* synthetic */ PendingIntent VA;
        final /* synthetic */ jd VB;
        final /* synthetic */ List Vz;

        /* renamed from: com.google.android.gms.internal.jd.1.1 */
        class C06661 implements OnAddGeofencesResultListener {
            final /* synthetic */ C13011 VC;

            C06661(C13011 c13011) {
                this.VC = c13011;
            }

            public void onAddGeofencesResult(int statusCode, String[] geofenceRequestIds) {
                this.VC.m1988b(LocationStatusCodes.cK(statusCode));
            }
        }

        C13011(jd jdVar, List list, PendingIntent pendingIntent) {
            this.VB = jdVar;
            this.Vz = list;
            this.VA = pendingIntent;
            super();
        }

        protected void m4635a(jh jhVar) throws RemoteException {
            jhVar.addGeofences(this.Vz, this.VA, new C06661(this));
        }
    }

    /* renamed from: com.google.android.gms.internal.jd.2 */
    class C13022 extends C1149a {
        final /* synthetic */ PendingIntent VA;
        final /* synthetic */ jd VB;

        /* renamed from: com.google.android.gms.internal.jd.2.1 */
        class C06671 implements OnRemoveGeofencesResultListener {
            final /* synthetic */ C13022 VD;

            C06671(C13022 c13022) {
                this.VD = c13022;
            }

            public void onRemoveGeofencesByPendingIntentResult(int statusCode, PendingIntent pendingIntent) {
                this.VD.m1988b(LocationStatusCodes.cK(statusCode));
            }

            public void onRemoveGeofencesByRequestIdsResult(int statusCode, String[] geofenceRequestIds) {
                Log.wtf("GeofencingImpl", "Request ID callback shouldn't have been called");
            }
        }

        C13022(jd jdVar, PendingIntent pendingIntent) {
            this.VB = jdVar;
            this.VA = pendingIntent;
            super();
        }

        protected void m4637a(jh jhVar) throws RemoteException {
            jhVar.removeGeofences(this.VA, new C06671(this));
        }
    }

    /* renamed from: com.google.android.gms.internal.jd.3 */
    class C13033 extends C1149a {
        final /* synthetic */ jd VB;
        final /* synthetic */ List VE;

        /* renamed from: com.google.android.gms.internal.jd.3.1 */
        class C06681 implements OnRemoveGeofencesResultListener {
            final /* synthetic */ C13033 VF;

            C06681(C13033 c13033) {
                this.VF = c13033;
            }

            public void onRemoveGeofencesByPendingIntentResult(int statusCode, PendingIntent pendingIntent) {
                Log.wtf("GeofencingImpl", "PendingIntent callback shouldn't have been called");
            }

            public void onRemoveGeofencesByRequestIdsResult(int statusCode, String[] geofenceRequestIds) {
                this.VF.m1988b(LocationStatusCodes.cK(statusCode));
            }
        }

        C13033(jd jdVar, List list) {
            this.VB = jdVar;
            this.VE = list;
            super();
        }

        protected void m4639a(jh jhVar) throws RemoteException {
            jhVar.removeGeofences(this.VE, new C06681(this));
        }
    }

    public PendingResult<Status> addGeofences(GoogleApiClient client, List<Geofence> geofences, PendingIntent pendingIntent) {
        List list;
        if (geofences != null) {
            List arrayList = new ArrayList(geofences.size());
            for (Geofence geofence : geofences) {
                hn.m1228b(geofence instanceof ji, (Object) "Geofence must be created using Geofence.Builder.");
                arrayList.add((ji) geofence);
            }
            list = arrayList;
        } else {
            list = null;
        }
        return client.m140b(new C13011(this, list, pendingIntent));
    }

    public PendingResult<Status> removeGeofences(GoogleApiClient client, PendingIntent pendingIntent) {
        return client.m140b(new C13022(this, pendingIntent));
    }

    public PendingResult<Status> removeGeofences(GoogleApiClient client, List<String> geofenceRequestIds) {
        return client.m140b(new C13033(this, geofenceRequestIds));
    }
}
