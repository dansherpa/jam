package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wallet.FullWalletRequest;
import com.google.android.gms.wallet.MaskedWalletRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest;
import com.google.android.gms.wallet.Payments;
import com.google.android.gms.wallet.Wallet.C1157b;

public class lr implements Payments {

    /* renamed from: com.google.android.gms.internal.lr.1 */
    class C13161 extends C1157b {
        final /* synthetic */ int UA;
        final /* synthetic */ lr akD;

        C13161(lr lrVar, int i) {
            this.akD = lrVar;
            this.UA = i;
        }

        protected void m4663a(ls lsVar) {
            lsVar.dQ(this.UA);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.lr.2 */
    class C13172 extends C1157b {
        final /* synthetic */ int UA;
        final /* synthetic */ lr akD;
        final /* synthetic */ MaskedWalletRequest akE;

        C13172(lr lrVar, MaskedWalletRequest maskedWalletRequest, int i) {
            this.akD = lrVar;
            this.akE = maskedWalletRequest;
            this.UA = i;
        }

        protected void m4665a(ls lsVar) {
            lsVar.m3714a(this.akE, this.UA);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.lr.3 */
    class C13183 extends C1157b {
        final /* synthetic */ int UA;
        final /* synthetic */ lr akD;
        final /* synthetic */ FullWalletRequest akF;

        C13183(lr lrVar, FullWalletRequest fullWalletRequest, int i) {
            this.akD = lrVar;
            this.akF = fullWalletRequest;
            this.UA = i;
        }

        protected void m4667a(ls lsVar) {
            lsVar.m3713a(this.akF, this.UA);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.lr.4 */
    class C13194 extends C1157b {
        final /* synthetic */ int UA;
        final /* synthetic */ lr akD;
        final /* synthetic */ String akG;
        final /* synthetic */ String akH;

        C13194(lr lrVar, String str, String str2, int i) {
            this.akD = lrVar;
            this.akG = str;
            this.akH = str2;
            this.UA = i;
        }

        protected void m4669a(ls lsVar) {
            lsVar.m3716d(this.akG, this.akH, this.UA);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.lr.5 */
    class C13205 extends C1157b {
        final /* synthetic */ lr akD;
        final /* synthetic */ NotifyTransactionStatusRequest akI;

        C13205(lr lrVar, NotifyTransactionStatusRequest notifyTransactionStatusRequest) {
            this.akD = lrVar;
            this.akI = notifyTransactionStatusRequest;
        }

        protected void m4671a(ls lsVar) {
            lsVar.m3715a(this.akI);
            m1988b(Status.Ek);
        }
    }

    public void changeMaskedWallet(GoogleApiClient googleApiClient, String googleTransactionId, String merchantTransactionId, int requestCode) {
        googleApiClient.m139a(new C13194(this, googleTransactionId, merchantTransactionId, requestCode));
    }

    public void checkForPreAuthorization(GoogleApiClient googleApiClient, int requestCode) {
        googleApiClient.m139a(new C13161(this, requestCode));
    }

    public void loadFullWallet(GoogleApiClient googleApiClient, FullWalletRequest request, int requestCode) {
        googleApiClient.m139a(new C13183(this, request, requestCode));
    }

    public void loadMaskedWallet(GoogleApiClient googleApiClient, MaskedWalletRequest request, int requestCode) {
        googleApiClient.m139a(new C13172(this, request, requestCode));
    }

    public void notifyTransactionStatus(GoogleApiClient googleApiClient, NotifyTransactionStatusRequest request) {
        googleApiClient.m139a(new C13205(this, request));
    }
}
