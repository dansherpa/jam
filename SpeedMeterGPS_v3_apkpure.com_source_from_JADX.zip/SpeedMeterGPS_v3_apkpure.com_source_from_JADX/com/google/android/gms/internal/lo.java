package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.C0151c;
import com.google.android.gms.dynamic.C0151c.C0558a;
import com.google.android.gms.dynamic.C0152d;
import com.google.android.gms.dynamic.C0152d.C0560a;
import com.google.android.gms.internal.ll.C0683a;
import com.google.android.gms.internal.lm.C0685a;
import com.google.android.gms.wallet.fragment.WalletFragmentOptions;
import com.google.android.gms.wearable.DataEvent;

public interface lo extends IInterface {

    /* renamed from: com.google.android.gms.internal.lo.a */
    public static abstract class C0689a extends Binder implements lo {

        /* renamed from: com.google.android.gms.internal.lo.a.a */
        private static class C0688a implements lo {
            private IBinder ko;

            C0688a(IBinder iBinder) {
                this.ko = iBinder;
            }

            public ll m2804a(C0152d c0152d, C0151c c0151c, WalletFragmentOptions walletFragmentOptions, lm lmVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
                    obtain.writeStrongBinder(c0152d != null ? c0152d.asBinder() : null);
                    obtain.writeStrongBinder(c0151c != null ? c0151c.asBinder() : null);
                    if (walletFragmentOptions != null) {
                        obtain.writeInt(1);
                        walletFragmentOptions.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lmVar != null) {
                        iBinder = lmVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    ll bo = C0683a.bo(obtain2.readStrongBinder());
                    return bo;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.ko;
            }
        }

        public static lo br(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof lo)) ? new C0688a(iBinder) : (lo) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            IBinder iBinder = null;
            switch (code) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
                    ll a = m1349a(C0560a.ag(data.readStrongBinder()), C0558a.af(data.readStrongBinder()), data.readInt() != 0 ? (WalletFragmentOptions) WalletFragmentOptions.CREATOR.createFromParcel(data) : null, C0685a.bp(data.readStrongBinder()));
                    reply.writeNoException();
                    if (a != null) {
                        iBinder = a.asBinder();
                    }
                    reply.writeStrongBinder(iBinder);
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.wallet.internal.IWalletDynamiteCreator");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    ll m1349a(C0152d c0152d, C0151c c0151c, WalletFragmentOptions walletFragmentOptions, lm lmVar) throws RemoteException;
}
