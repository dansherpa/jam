package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.C0155g;
import com.google.android.gms.dynamic.C0931e;
import com.google.android.gms.internal.ar.C0573a;
import com.google.android.gms.internal.as.C0575a;

public final class ai extends C0155g<as> {
    private static final ai lP;

    static {
        lP = new ai();
    }

    private ai() {
        super("com.google.android.gms.ads.AdManagerCreatorImpl");
    }

    public static ar m2454a(Context context, am amVar, String str, bt btVar) {
        if (GooglePlayServicesUtil.isGooglePlayServicesAvailable(context) == 0) {
            ar b = lP.m2455b(context, amVar, str, btVar);
            if (b != null) {
                return b;
            }
        }
        ev.m1018z("Using AdManager from the client jar.");
        return new C1020v(context, amVar, str, btVar, new ew(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, true));
    }

    private ar m2455b(Context context, am amVar, String str, bt btVar) {
        try {
            return C0573a.m2470f(((as) m462D(context)).m791a(C0931e.m3242h(context), amVar, str, btVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE));
        } catch (Throwable e) {
            ev.m1016c("Could not create remote AdManager.", e);
            return null;
        } catch (Throwable e2) {
            ev.m1016c("Could not create remote AdManager.", e2);
            return null;
        }
    }

    protected as m2456c(IBinder iBinder) {
        return C0575a.m2472g(iBinder);
    }

    protected /* synthetic */ Object m2457d(IBinder iBinder) {
        return m2456c(iBinder);
    }
}
