package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ei {
    private static final ei rM;
    public static final String rN;
    private final Object lq;
    public final String rO;
    private final ej rP;
    private BigInteger rQ;
    private final HashSet<eh> rR;
    private final HashMap<String, el> rS;
    private boolean rT;

    static {
        rM = new ei();
        rN = rM.rO;
    }

    private ei() {
        this.lq = new Object();
        this.rQ = BigInteger.ONE;
        this.rR = new HashSet();
        this.rS = new HashMap();
        this.rT = false;
        this.rO = ep.bO();
        this.rP = new ej(this.rO);
    }

    public static Bundle m954a(Context context, ek ekVar, String str) {
        return rM.m958b(context, ekVar, str);
    }

    public static void m955b(HashSet<eh> hashSet) {
        rM.m959c(hashSet);
    }

    public static ei bC() {
        return rM;
    }

    public static String bD() {
        return rM.bE();
    }

    public static ej bF() {
        return rM.bG();
    }

    public static boolean bH() {
        return rM.bI();
    }

    public void m956a(eh ehVar) {
        synchronized (this.lq) {
            this.rR.add(ehVar);
        }
    }

    public void m957a(String str, el elVar) {
        synchronized (this.lq) {
            this.rS.put(str, elVar);
        }
    }

    public Bundle m958b(Context context, ek ekVar, String str) {
        Bundle bundle;
        synchronized (this.lq) {
            bundle = new Bundle();
            bundle.putBundle("app", this.rP.m961b(context, str));
            Bundle bundle2 = new Bundle();
            for (String str2 : this.rS.keySet()) {
                bundle2.putBundle(str2, ((el) this.rS.get(str2)).toBundle());
            }
            bundle.putBundle("slots", bundle2);
            ArrayList arrayList = new ArrayList();
            Iterator it = this.rR.iterator();
            while (it.hasNext()) {
                arrayList.add(((eh) it.next()).toBundle());
            }
            bundle.putParcelableArrayList("ads", arrayList);
            ekVar.m963a(this.rR);
            this.rR.clear();
        }
        return bundle;
    }

    public String bE() {
        String bigInteger;
        synchronized (this.lq) {
            bigInteger = this.rQ.toString();
            this.rQ = this.rQ.add(BigInteger.ONE);
        }
        return bigInteger;
    }

    public ej bG() {
        ej ejVar;
        synchronized (this.lq) {
            ejVar = this.rP;
        }
        return ejVar;
    }

    public boolean bI() {
        boolean z;
        synchronized (this.lq) {
            z = this.rT;
            this.rT = true;
        }
        return z;
    }

    public void m959c(HashSet<eh> hashSet) {
        synchronized (this.lq) {
            this.rR.addAll(hashSet);
        }
    }
}
