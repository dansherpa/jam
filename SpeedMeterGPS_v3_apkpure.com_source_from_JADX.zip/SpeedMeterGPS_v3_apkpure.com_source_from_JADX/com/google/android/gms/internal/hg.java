package com.google.android.gms.internal;

import android.util.Log;

public final class hg {
    private final String GF;

    public hg(String str) {
        this.GF = (String) hn.m1230f(str);
    }

    public void m1176a(String str, String str2, Throwable th) {
        if (ap(4)) {
            Log.i(str, str2, th);
        }
    }

    public boolean ap(int i) {
        return Log.isLoggable(this.GF, i);
    }

    public void m1177b(String str, String str2, Throwable th) {
        if (ap(6)) {
            Log.e(str, str2, th);
        }
    }

    public void m1178i(String str, String str2) {
        if (ap(2)) {
            Log.v(str, str2);
        }
    }

    public void m1179j(String str, String str2) {
        if (ap(5)) {
            Log.w(str, str2);
        }
    }

    public void m1180k(String str, String str2) {
        if (ap(6)) {
            Log.e(str, str2);
        }
    }
}
