package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.internal.fv.C0633a;
import com.google.android.gms.internal.hc.C0993e;

public class fy extends hc<fv> {
    public fy(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, new String[0]);
    }

    protected fv m3576C(IBinder iBinder) {
        return C0633a.m2594A(iBinder);
    }

    protected void m3577a(hj hjVar, C0993e c0993e) throws RemoteException {
        hjVar.m1193b(c0993e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName());
    }

    protected String bp() {
        return "com.google.android.gms.icing.LIGHTWEIGHT_INDEX_SERVICE";
    }

    protected String bq() {
        return "com.google.android.gms.appdatasearch.internal.ILightweightAppDataSearch";
    }

    public fv dM() {
        return (fv) fo();
    }

    protected /* synthetic */ IInterface m3578x(IBinder iBinder) {
        return m3576C(iBinder);
    }
}
