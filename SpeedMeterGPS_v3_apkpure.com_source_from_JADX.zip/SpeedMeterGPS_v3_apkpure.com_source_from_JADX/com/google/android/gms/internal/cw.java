package com.google.android.gms.internal;

public final class cw {
    public long pj;
    public final String pk;
    public final String pl;

    public cw(long j, String str, String str2) {
        this.pj = j;
        this.pl = str;
        this.pk = str2;
    }

    public cw(String str, String str2) {
        this.pl = str;
        this.pk = str2;
    }
}
