package com.google.android.gms.internal;

import android.content.Context;
import android.webkit.WebSettings;

public final class es {
    public static void m1002a(Context context, WebSettings webSettings) {
        er.m996a(context, webSettings);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
    }

    public static String getDefaultUserAgent(Context context) {
        return WebSettings.getDefaultUserAgent(context);
    }
}
