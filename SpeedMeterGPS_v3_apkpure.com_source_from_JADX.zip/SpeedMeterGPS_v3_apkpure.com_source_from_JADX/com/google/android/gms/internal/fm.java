package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;

public class fm implements Creator<fl> {
    static void m1062a(fl flVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m240a(parcel, 1, flVar.xR, false);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, flVar.xJ);
        C0072b.m236a(parcel, 3, flVar.xS, i, false);
        C0072b.m252c(parcel, 4, flVar.xT);
        C0072b.m244a(parcel, 5, flVar.xU, false);
        C0072b.m228G(parcel, C);
    }

    public fl[] m1063F(int i) {
        return new fl[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1064n(x0);
    }

    public fl m1064n(Parcel parcel) {
        byte[] bArr = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        int i2 = -1;
        fq fqVar = null;
        String str = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    fqVar = (fq) C0071a.m194a(parcel, A, fq.CREATOR);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    bArr = C0071a.m216r(parcel, A);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new fl(i, str, fqVar, i2, bArr);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1063F(x0);
    }
}
