package com.google.android.gms.internal;

import com.google.android.gms.cast.Cast;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public final class ma {
    private final int amT;
    private final byte[] buffer;
    private int position;

    /* renamed from: com.google.android.gms.internal.ma.a */
    public static class C0263a extends IOException {
        C0263a(int i, int i2) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space (pos " + i + " limit " + i2 + ").");
        }
    }

    private ma(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.position = i;
        this.amT = i + i2;
    }

    public static int m1371D(long j) {
        return m1373G(j);
    }

    public static int m1372E(long j) {
        return m1373G(m1374I(j));
    }

    public static int m1373G(long j) {
        return (-128 & j) == 0 ? 1 : (-16384 & j) == 0 ? 2 : (-2097152 & j) == 0 ? 3 : (-268435456 & j) == 0 ? 4 : (-34359738368L & j) == 0 ? 5 : (-4398046511104L & j) == 0 ? 6 : (-562949953421312L & j) == 0 ? 7 : (-72057594037927936L & j) == 0 ? 8 : (Long.MIN_VALUE & j) == 0 ? 9 : 10;
    }

    public static long m1374I(long j) {
        return (j << 1) ^ (j >> 63);
    }

    public static int m1375J(boolean z) {
        return 1;
    }

    public static int m1376b(int i, double d) {
        return eH(i) + m1386f(d);
    }

    public static int m1377b(int i, mf mfVar) {
        return eH(i) + m1382c(mfVar);
    }

    public static int m1378b(int i, boolean z) {
        return eH(i) + m1375J(z);
    }

    public static int m1379b(int i, byte[] bArr) {
        return eH(i) + m1391s(bArr);
    }

    public static ma m1380b(byte[] bArr, int i, int i2) {
        return new ma(bArr, i, i2);
    }

    public static int m1381c(int i, float f) {
        return eH(i) + m1384e(f);
    }

    public static int m1382c(mf mfVar) {
        int nV = mfVar.nV();
        return nV + eJ(nV);
    }

    public static int cz(String str) {
        try {
            byte[] bytes = str.getBytes("UTF-8");
            return bytes.length + eJ(bytes.length);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported.");
        }
    }

    public static int m1383d(int i, long j) {
        return eH(i) + m1371D(j);
    }

    public static int m1384e(float f) {
        return 4;
    }

    public static int m1385e(int i, long j) {
        return eH(i) + m1372E(j);
    }

    public static int eE(int i) {
        return i >= 0 ? eJ(i) : 10;
    }

    public static int eF(int i) {
        return eJ(eL(i));
    }

    public static int eH(int i) {
        return eJ(mi.m1430u(i, 0));
    }

    public static int eJ(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (-268435456 & i) == 0 ? 4 : 5;
    }

    public static int eL(int i) {
        return (i << 1) ^ (i >> 31);
    }

    public static int m1386f(double d) {
        return 8;
    }

    public static int m1387h(int i, String str) {
        return eH(i) + cz(str);
    }

    public static ma m1388q(byte[] bArr) {
        return m1380b(bArr, 0, bArr.length);
    }

    public static int m1389r(int i, int i2) {
        return eH(i) + eE(i2);
    }

    public static int m1390s(int i, int i2) {
        return eH(i) + eF(i2);
    }

    public static int m1391s(byte[] bArr) {
        return eJ(bArr.length) + bArr.length;
    }

    public void m1392B(long j) throws IOException {
        m1394F(j);
    }

    public void m1393C(long j) throws IOException {
        m1394F(m1374I(j));
    }

    public void m1394F(long j) throws IOException {
        while ((-128 & j) != 0) {
            eG((((int) j) & 127) | Cast.MAX_NAMESPACE_LENGTH);
            j >>>= 7;
        }
        eG((int) j);
    }

    public void m1395H(long j) throws IOException {
        eG(((int) j) & 255);
        eG(((int) (j >> 8)) & 255);
        eG(((int) (j >> 16)) & 255);
        eG(((int) (j >> 24)) & 255);
        eG(((int) (j >> 32)) & 255);
        eG(((int) (j >> 40)) & 255);
        eG(((int) (j >> 48)) & 255);
        eG(((int) (j >> 56)) & 255);
    }

    public void m1396I(boolean z) throws IOException {
        eG(z ? 1 : 0);
    }

    public void m1397a(int i, double d) throws IOException {
        m1413t(i, 1);
        m1409e(d);
    }

    public void m1398a(int i, mf mfVar) throws IOException {
        m1413t(i, 2);
        m1405b(mfVar);
    }

    public void m1399a(int i, boolean z) throws IOException {
        m1413t(i, 0);
        m1396I(z);
    }

    public void m1400a(int i, byte[] bArr) throws IOException {
        m1413t(i, 2);
        m1412r(bArr);
    }

    public void m1401b(byte b) throws IOException {
        if (this.position == this.amT) {
            throw new C0263a(this.position, this.amT);
        }
        byte[] bArr = this.buffer;
        int i = this.position;
        this.position = i + 1;
        bArr[i] = b;
    }

    public void m1402b(int i, float f) throws IOException {
        m1413t(i, 5);
        m1408d(f);
    }

    public void m1403b(int i, long j) throws IOException {
        m1413t(i, 0);
        m1392B(j);
    }

    public void m1404b(int i, String str) throws IOException {
        m1413t(i, 2);
        cy(str);
    }

    public void m1405b(mf mfVar) throws IOException {
        eI(mfVar.nU());
        mfVar.m1423a(this);
    }

    public void m1406c(int i, long j) throws IOException {
        m1413t(i, 0);
        m1393C(j);
    }

    public void m1407c(byte[] bArr, int i, int i2) throws IOException {
        if (this.amT - this.position >= i2) {
            System.arraycopy(bArr, i, this.buffer, this.position, i2);
            this.position += i2;
            return;
        }
        throw new C0263a(this.position, this.amT);
    }

    public void cy(String str) throws IOException {
        byte[] bytes = str.getBytes("UTF-8");
        eI(bytes.length);
        m1414t(bytes);
    }

    public void m1408d(float f) throws IOException {
        eK(Float.floatToIntBits(f));
    }

    public void m1409e(double d) throws IOException {
        m1395H(Double.doubleToLongBits(d));
    }

    public void eC(int i) throws IOException {
        if (i >= 0) {
            eI(i);
        } else {
            m1394F((long) i);
        }
    }

    public void eD(int i) throws IOException {
        eI(eL(i));
    }

    public void eG(int i) throws IOException {
        m1401b((byte) i);
    }

    public void eI(int i) throws IOException {
        while ((i & -128) != 0) {
            eG((i & 127) | Cast.MAX_NAMESPACE_LENGTH);
            i >>>= 7;
        }
        eG(i);
    }

    public void eK(int i) throws IOException {
        eG(i & 255);
        eG((i >> 8) & 255);
        eG((i >> 16) & 255);
        eG((i >> 24) & 255);
    }

    public int nL() {
        return this.amT - this.position;
    }

    public void nM() {
        if (nL() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public void m1410p(int i, int i2) throws IOException {
        m1413t(i, 0);
        eC(i2);
    }

    public void m1411q(int i, int i2) throws IOException {
        m1413t(i, 0);
        eD(i2);
    }

    public void m1412r(byte[] bArr) throws IOException {
        eI(bArr.length);
        m1414t(bArr);
    }

    public void m1413t(int i, int i2) throws IOException {
        eI(mi.m1430u(i, i2));
    }

    public void m1414t(byte[] bArr) throws IOException {
        m1407c(bArr, 0, bArr.length);
    }
}
