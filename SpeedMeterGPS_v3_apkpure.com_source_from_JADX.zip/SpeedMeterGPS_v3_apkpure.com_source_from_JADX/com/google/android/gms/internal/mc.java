package com.google.android.gms.internal;

import com.mochii.speedmo.C0450R;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class mc<M extends mb<M>, T> {
    protected final Class<T> amV;
    protected final boolean amW;
    protected final int tag;
    protected final int type;

    private mc(int i, Class<T> cls, int i2, boolean z) {
        this.type = i;
        this.amV = cls;
        this.tag = i2;
        this.amW = z;
    }

    public static <M extends mb<M>, T extends mf> mc<M, T> m1415a(int i, Class<T> cls, int i2) {
        return new mc(i, cls, i2, false);
    }

    protected void m1416a(mh mhVar, List<Object> list) {
        list.add(m1418u(lz.m1367p(mhVar.amZ)));
    }

    protected boolean eM(int i) {
        return i == this.tag;
    }

    final T m1417i(List<mh> list) {
        int i = 0;
        if (list == null) {
            return null;
        }
        mh mhVar;
        if (this.amW) {
            int i2;
            List arrayList = new ArrayList();
            for (i2 = 0; i2 < list.size(); i2++) {
                mhVar = (mh) list.get(i2);
                if (eM(mhVar.tag) && mhVar.amZ.length != 0) {
                    m1416a(mhVar, arrayList);
                }
            }
            i2 = arrayList.size();
            if (i2 == 0) {
                return null;
            }
            T cast = this.amV.cast(Array.newInstance(this.amV.getComponentType(), i2));
            while (i < i2) {
                Array.set(cast, i, arrayList.get(i));
                i++;
            }
            return cast;
        }
        i = list.size() - 1;
        mh mhVar2 = null;
        while (mhVar2 == null && i >= 0) {
            mhVar = (mh) list.get(i);
            if (!eM(mhVar.tag) || mhVar.amZ.length == 0) {
                mhVar = mhVar2;
            }
            i--;
            mhVar2 = mhVar;
        }
        return mhVar2 == null ? null : this.amV.cast(m1418u(lz.m1367p(mhVar2.amZ)));
    }

    protected Object m1418u(lz lzVar) {
        Class componentType = this.amW ? this.amV.getComponentType() : this.amV;
        try {
            mf mfVar;
            switch (this.type) {
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    mfVar = (mf) componentType.newInstance();
                    lzVar.m1369a(mfVar, mi.eO(this.tag));
                    return mfVar;
                case C0450R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    mfVar = (mf) componentType.newInstance();
                    lzVar.m1368a(mfVar);
                    return mfVar;
                default:
                    throw new IllegalArgumentException("Unknown type " + this.type);
            }
        } catch (Throwable e) {
            throw new IllegalArgumentException("Error creating instance of class " + componentType, e);
        } catch (Throwable e2) {
            throw new IllegalArgumentException("Error creating instance of class " + componentType, e2);
        } catch (Throwable e22) {
            throw new IllegalArgumentException("Error reading extension field", e22);
        }
    }
}
