package com.google.android.gms.internal;

import java.io.IOException;

/* renamed from: com.google.android.gms.internal.o */
interface C0265o {
    void m1433b(int i, long j) throws IOException;

    void m1434b(int i, String str) throws IOException;

    void reset();

    byte[] m1435z() throws IOException;
}
