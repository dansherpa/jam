package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.wearable.DataEvent;
import java.util.List;

public class jw implements Creator<jv> {
    static void m1310a(jv jvVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m240a(parcel, 1, jvVar.getName(), false);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, jvVar.xJ);
        C0072b.m236a(parcel, 2, jvVar.jf(), i, false);
        C0072b.m240a(parcel, 3, jvVar.getAddress(), false);
        C0072b.m251b(parcel, 4, jvVar.jg(), false);
        C0072b.m240a(parcel, 5, jvVar.getPhoneNumber(), false);
        C0072b.m240a(parcel, 6, jvVar.jh(), false);
        C0072b.m228G(parcel, C);
    }

    public jv bz(Parcel parcel) {
        String str = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        String str2 = null;
        List list = null;
        String str3 = null;
        LatLng latLng = null;
        String str4 = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    str4 = C0071a.m213o(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    latLng = (LatLng) C0071a.m194a(parcel, A, LatLng.CREATOR);
                    break;
                case DetectedActivity.STILL /*3*/:
                    str3 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    list = C0071a.m200c(parcel, A, jt.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new jv(i, str4, latLng, str3, list, str2, str);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public jv[] cU(int i) {
        return new jv[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bz(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cU(x0);
    }
}
