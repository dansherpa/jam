package com.google.android.gms.internal;

import android.os.IInterface;

public interface jk<T extends IInterface> {
    void ci();

    T fo();
}
