package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

public class fp {
    private static final String[] xW;
    private static final Map<String, Integer> xX;

    static {
        int i = 0;
        xW = new String[]{"text1", "text2", "icon", "intent_action", "intent_data", "intent_data_id", "intent_extra_data", "suggest_large_icon", "intent_activity"};
        xX = new HashMap(xW.length);
        while (i < xW.length) {
            xX.put(xW[i], Integer.valueOf(i));
            i++;
        }
    }

    public static String m1068H(int i) {
        return (i < 0 || i >= xW.length) ? null : xW[i];
    }

    public static int m1069Y(String str) {
        Integer num = (Integer) xX.get(str);
        if (num != null) {
            return num.intValue();
        }
        throw new IllegalArgumentException("[" + str + "] is not a valid global search section name");
    }

    public static int dK() {
        return xW.length;
    }
}
