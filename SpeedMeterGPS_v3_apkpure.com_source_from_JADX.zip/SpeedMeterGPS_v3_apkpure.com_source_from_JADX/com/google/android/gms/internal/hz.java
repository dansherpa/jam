package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.location.DetectedActivity;
import com.mochii.speedmo.C0450R;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class hz {

    /* renamed from: com.google.android.gms.internal.hz.b */
    public interface C0253b<I, O> {
        int fA();

        int fz();

        I m1246g(O o);
    }

    /* renamed from: com.google.android.gms.internal.hz.a */
    public static class C0657a<I, O> implements SafeParcelable {
        public static final ia CREATOR;
        protected final int GY;
        protected final boolean GZ;
        protected final int Ha;
        protected final boolean Hb;
        protected final String Hc;
        protected final int Hd;
        protected final Class<? extends hz> He;
        protected final String Hf;
        private ic Hg;
        private C0253b<I, O> Hh;
        private final int xJ;

        static {
            CREATOR = new ia();
        }

        C0657a(int i, int i2, boolean z, int i3, boolean z2, String str, int i4, String str2, hu huVar) {
            this.xJ = i;
            this.GY = i2;
            this.GZ = z;
            this.Ha = i3;
            this.Hb = z2;
            this.Hc = str;
            this.Hd = i4;
            if (str2 == null) {
                this.He = null;
                this.Hf = null;
            } else {
                this.He = C0661if.class;
                this.Hf = str2;
            }
            if (huVar == null) {
                this.Hh = null;
            } else {
                this.Hh = huVar.fx();
            }
        }

        protected C0657a(int i, boolean z, int i2, boolean z2, String str, int i3, Class<? extends hz> cls, C0253b<I, O> c0253b) {
            this.xJ = 1;
            this.GY = i;
            this.GZ = z;
            this.Ha = i2;
            this.Hb = z2;
            this.Hc = str;
            this.Hd = i3;
            this.He = cls;
            if (cls == null) {
                this.Hf = null;
            } else {
                this.Hf = cls.getCanonicalName();
            }
            this.Hh = c0253b;
        }

        public static C0657a m2707a(String str, int i, C0253b<?, ?> c0253b, boolean z) {
            return new C0657a(c0253b.fz(), z, c0253b.fA(), false, str, i, null, c0253b);
        }

        public static <T extends hz> C0657a<T, T> m2708a(String str, int i, Class<T> cls) {
            return new C0657a(11, false, 11, false, str, i, cls, null);
        }

        public static <T extends hz> C0657a<ArrayList<T>, ArrayList<T>> m2709b(String str, int i, Class<T> cls) {
            return new C0657a(11, true, 11, true, str, i, cls, null);
        }

        public static C0657a<Integer, Integer> m2711g(String str, int i) {
            return new C0657a(0, false, 0, false, str, i, null, null);
        }

        public static C0657a<Double, Double> m2712h(String str, int i) {
            return new C0657a(4, false, 4, false, str, i, null, null);
        }

        public static C0657a<Boolean, Boolean> m2713i(String str, int i) {
            return new C0657a(6, false, 6, false, str, i, null, null);
        }

        public static C0657a<String, String> m2714j(String str, int i) {
            return new C0657a(7, false, 7, false, str, i, null, null);
        }

        public static C0657a<ArrayList<String>, ArrayList<String>> m2715k(String str, int i) {
            return new C0657a(7, true, 7, true, str, i, null, null);
        }

        public void m2716a(ic icVar) {
            this.Hg = icVar;
        }

        public int describeContents() {
            ia iaVar = CREATOR;
            return 0;
        }

        public int fA() {
            return this.Ha;
        }

        public C0657a<I, O> fE() {
            return new C0657a(this.xJ, this.GY, this.GZ, this.Ha, this.Hb, this.Hc, this.Hd, this.Hf, fM());
        }

        public boolean fF() {
            return this.GZ;
        }

        public boolean fG() {
            return this.Hb;
        }

        public String fH() {
            return this.Hc;
        }

        public int fI() {
            return this.Hd;
        }

        public Class<? extends hz> fJ() {
            return this.He;
        }

        String fK() {
            return this.Hf == null ? null : this.Hf;
        }

        public boolean fL() {
            return this.Hh != null;
        }

        hu fM() {
            return this.Hh == null ? null : hu.m2702a(this.Hh);
        }

        public HashMap<String, C0657a<?, ?>> fN() {
            hn.m1230f(this.Hf);
            hn.m1230f(this.Hg);
            return this.Hg.aJ(this.Hf);
        }

        public int fz() {
            return this.GY;
        }

        public I m2717g(O o) {
            return this.Hh.m1246g(o);
        }

        public int getVersionCode() {
            return this.xJ;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Field\n");
            stringBuilder.append("            versionCode=").append(this.xJ).append('\n');
            stringBuilder.append("                 typeIn=").append(this.GY).append('\n');
            stringBuilder.append("            typeInArray=").append(this.GZ).append('\n');
            stringBuilder.append("                typeOut=").append(this.Ha).append('\n');
            stringBuilder.append("           typeOutArray=").append(this.Hb).append('\n');
            stringBuilder.append("        outputFieldName=").append(this.Hc).append('\n');
            stringBuilder.append("      safeParcelFieldId=").append(this.Hd).append('\n');
            stringBuilder.append("       concreteTypeName=").append(fK()).append('\n');
            if (fJ() != null) {
                stringBuilder.append("     concreteType.class=").append(fJ().getCanonicalName()).append('\n');
            }
            stringBuilder.append("          converterName=").append(this.Hh == null ? "null" : this.Hh.getClass().getCanonicalName()).append('\n');
            return stringBuilder.toString();
        }

        public void writeToParcel(Parcel out, int flags) {
            ia iaVar = CREATOR;
            ia.m1252a(this, out, flags);
        }
    }

    private void m1247a(StringBuilder stringBuilder, C0657a c0657a, Object obj) {
        if (c0657a.fz() == 11) {
            stringBuilder.append(((hz) c0657a.fJ().cast(obj)).toString());
        } else if (c0657a.fz() == 7) {
            stringBuilder.append("\"");
            stringBuilder.append(io.aK((String) obj));
            stringBuilder.append("\"");
        } else {
            stringBuilder.append(obj);
        }
    }

    private void m1248a(StringBuilder stringBuilder, C0657a c0657a, ArrayList<Object> arrayList) {
        stringBuilder.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                stringBuilder.append(",");
            }
            Object obj = arrayList.get(i);
            if (obj != null) {
                m1247a(stringBuilder, c0657a, obj);
            }
        }
        stringBuilder.append("]");
    }

    protected <O, I> I m1249a(C0657a<I, O> c0657a, Object obj) {
        return c0657a.Hh != null ? c0657a.m2717g(obj) : obj;
    }

    protected boolean m1250a(C0657a c0657a) {
        return c0657a.fA() == 11 ? c0657a.fG() ? aI(c0657a.fH()) : aH(c0657a.fH()) : aG(c0657a.fH());
    }

    protected abstract Object aF(String str);

    protected abstract boolean aG(String str);

    protected boolean aH(String str) {
        throw new UnsupportedOperationException("Concrete types not supported");
    }

    protected boolean aI(String str) {
        throw new UnsupportedOperationException("Concrete type arrays not supported");
    }

    protected Object m1251b(C0657a c0657a) {
        String fH = c0657a.fH();
        if (c0657a.fJ() == null) {
            return aF(c0657a.fH());
        }
        hn.m1225a(aF(c0657a.fH()) == null, "Concrete field shouldn't be value object: %s", c0657a.fH());
        Map fD = c0657a.fG() ? fD() : fC();
        if (fD != null) {
            return fD.get(fH);
        }
        try {
            return getClass().getMethod("get" + Character.toUpperCase(fH.charAt(0)) + fH.substring(1), new Class[0]).invoke(this, new Object[0]);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public abstract HashMap<String, C0657a<?, ?>> fB();

    public HashMap<String, Object> fC() {
        return null;
    }

    public HashMap<String, Object> fD() {
        return null;
    }

    public String toString() {
        HashMap fB = fB();
        StringBuilder stringBuilder = new StringBuilder(100);
        for (String str : fB.keySet()) {
            C0657a c0657a = (C0657a) fB.get(str);
            if (m1250a(c0657a)) {
                Object a = m1249a(c0657a, m1251b(c0657a));
                if (stringBuilder.length() == 0) {
                    stringBuilder.append("{");
                } else {
                    stringBuilder.append(",");
                }
                stringBuilder.append("\"").append(str).append("\":");
                if (a != null) {
                    switch (c0657a.fA()) {
                        case DetectedActivity.RUNNING /*8*/:
                            stringBuilder.append("\"").append(ii.m1269d((byte[]) a)).append("\"");
                            break;
                        case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                            stringBuilder.append("\"").append(ii.m1270e((byte[]) a)).append("\"");
                            break;
                        case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                            ip.m1275a(stringBuilder, (HashMap) a);
                            break;
                        default:
                            if (!c0657a.fF()) {
                                m1247a(stringBuilder, c0657a, a);
                                break;
                            }
                            m1248a(stringBuilder, c0657a, (ArrayList) a);
                            break;
                    }
                }
                stringBuilder.append("null");
            }
        }
        if (stringBuilder.length() > 0) {
            stringBuilder.append("}");
        } else {
            stringBuilder.append("{}");
        }
        return stringBuilder.toString();
    }
}
