package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.internal.dx.C0611a;
import com.google.android.gms.internal.hc.C0993e;

public class ds extends hc<dx> {
    final int pT;

    public ds(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, int i) {
        super(context, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.pT = i;
    }

    protected void m3564a(hj hjVar, C0993e c0993e) throws RemoteException {
        hjVar.m1205g(c0993e, this.pT, getContext().getPackageName(), new Bundle());
    }

    protected String bp() {
        return "com.google.android.gms.ads.service.START";
    }

    protected String bq() {
        return "com.google.android.gms.ads.internal.request.IAdRequestService";
    }

    public dx br() {
        return (dx) super.fo();
    }

    protected dx m3565w(IBinder iBinder) {
        return C0611a.m2560y(iBinder);
    }

    protected /* synthetic */ IInterface m3566x(IBinder iBinder) {
        return m3565w(iBinder);
    }
}
