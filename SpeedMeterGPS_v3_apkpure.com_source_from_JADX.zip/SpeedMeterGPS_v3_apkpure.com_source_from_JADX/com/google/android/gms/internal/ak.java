package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;
import java.util.List;

public class ak implements Creator<aj> {
    static void m774a(aj ajVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, ajVar.versionCode);
        C0072b.m232a(parcel, 2, ajVar.lQ);
        C0072b.m233a(parcel, 3, ajVar.extras, false);
        C0072b.m252c(parcel, 4, ajVar.lR);
        C0072b.m241a(parcel, 5, ajVar.lS, false);
        C0072b.m243a(parcel, 6, ajVar.lT);
        C0072b.m252c(parcel, 7, ajVar.lU);
        C0072b.m243a(parcel, 8, ajVar.lV);
        C0072b.m240a(parcel, 9, ajVar.lW, false);
        C0072b.m236a(parcel, 10, ajVar.lX, i, false);
        C0072b.m236a(parcel, 11, ajVar.lY, i, false);
        C0072b.m240a(parcel, 12, ajVar.lZ, false);
        C0072b.m233a(parcel, 13, ajVar.ma, false);
        C0072b.m228G(parcel, C);
    }

    public aj m775b(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        long j = 0;
        Bundle bundle = null;
        int i2 = 0;
        List list = null;
        boolean z = false;
        int i3 = 0;
        boolean z2 = false;
        String str = null;
        ax axVar = null;
        Location location = null;
        String str2 = null;
        Bundle bundle2 = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    j = C0071a.m207i(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    bundle = C0071a.m215q(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    list = C0071a.m190B(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i3 = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    z2 = C0071a.m201c(parcel, A);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                    axVar = (ax) C0071a.m194a(parcel, A, ax.CREATOR);
                    break;
                case C0450R.styleable.MapAttrs_uiZoomGestures /*11*/:
                    location = (Location) C0071a.m194a(parcel, A, Location.CREATOR);
                    break;
                case C0450R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case C0450R.styleable.MapAttrs_zOrderOnTop /*13*/:
                    bundle2 = C0071a.m215q(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new aj(i, j, bundle, i2, list, z, i3, z2, str, axVar, location, str2, bundle2);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public aj[] m776c(int i) {
        return new aj[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m775b(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m776c(x0);
    }
}
