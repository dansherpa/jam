package com.google.android.gms.internal;

import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.People;
import com.google.android.gms.plus.People.LoadPeopleResult;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.Plus.C1096a;
import com.google.android.gms.plus.internal.C1039e;
import com.google.android.gms.plus.model.people.Person;
import com.google.android.gms.plus.model.people.PersonBuffer;
import java.util.Collection;

public final class kn implements People {

    /* renamed from: com.google.android.gms.internal.kn.a */
    private static abstract class C1156a extends C1096a<LoadPeopleResult> {

        /* renamed from: com.google.android.gms.internal.kn.a.1 */
        class C10051 implements LoadPeopleResult {
            final /* synthetic */ C1156a acn;
            final /* synthetic */ Status yG;

            C10051(C1156a c1156a, Status status) {
                this.acn = c1156a;
                this.yG = status;
            }

            public String getNextPageToken() {
                return null;
            }

            public PersonBuffer getPersonBuffer() {
                return null;
            }

            public Status getStatus() {
                return this.yG;
            }

            public void release() {
            }
        }

        private C1156a() {
        }

        public LoadPeopleResult ao(Status status) {
            return new C10051(this, status);
        }

        public /* synthetic */ Result m4250c(Status status) {
            return ao(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.kn.1 */
    class C13111 extends C1156a {
        final /* synthetic */ String acc;
        final /* synthetic */ int acj;
        final /* synthetic */ kn ack;

        C13111(kn knVar, int i, String str) {
            this.ack = knVar;
            this.acj = i;
            this.acc = str;
            super();
        }

        protected void m4653a(C1039e c1039e) {
            m1986a(c1039e.m3784a((C0052d) this, this.acj, this.acc));
        }
    }

    /* renamed from: com.google.android.gms.internal.kn.2 */
    class C13122 extends C1156a {
        final /* synthetic */ String acc;
        final /* synthetic */ kn ack;

        C13122(kn knVar, String str) {
            this.ack = knVar;
            this.acc = str;
            super();
        }

        protected void m4655a(C1039e c1039e) {
            m1986a(c1039e.m3794r(this, this.acc));
        }
    }

    /* renamed from: com.google.android.gms.internal.kn.3 */
    class C13133 extends C1156a {
        final /* synthetic */ kn ack;

        C13133(kn knVar) {
            this.ack = knVar;
            super();
        }

        protected void m4657a(C1039e c1039e) {
            c1039e.m3792l(this);
        }
    }

    /* renamed from: com.google.android.gms.internal.kn.4 */
    class C13144 extends C1156a {
        final /* synthetic */ kn ack;
        final /* synthetic */ Collection acl;

        C13144(kn knVar, Collection collection) {
            this.ack = knVar;
            this.acl = collection;
            super();
        }

        protected void m4659a(C1039e c1039e) {
            c1039e.m3788a((C0052d) this, this.acl);
        }
    }

    /* renamed from: com.google.android.gms.internal.kn.5 */
    class C13155 extends C1156a {
        final /* synthetic */ kn ack;
        final /* synthetic */ String[] acm;

        C13155(kn knVar, String[] strArr) {
            this.ack = knVar;
            this.acm = strArr;
            super();
        }

        protected void m4661a(C1039e c1039e) {
            c1039e.m3790d(this, this.acm);
        }
    }

    public Person getCurrentPerson(GoogleApiClient googleApiClient) {
        return Plus.m1541a(googleApiClient, Plus.yE).getCurrentPerson();
    }

    public PendingResult<LoadPeopleResult> load(GoogleApiClient googleApiClient, Collection<String> personIds) {
        return googleApiClient.m139a(new C13144(this, personIds));
    }

    public PendingResult<LoadPeopleResult> load(GoogleApiClient googleApiClient, String... personIds) {
        return googleApiClient.m139a(new C13155(this, personIds));
    }

    public PendingResult<LoadPeopleResult> loadConnected(GoogleApiClient googleApiClient) {
        return googleApiClient.m139a(new C13133(this));
    }

    public PendingResult<LoadPeopleResult> loadVisible(GoogleApiClient googleApiClient, int orderBy, String pageToken) {
        return googleApiClient.m139a(new C13111(this, orderBy, pageToken));
    }

    public PendingResult<LoadPeopleResult> loadVisible(GoogleApiClient googleApiClient, String pageToken) {
        return googleApiClient.m139a(new C13122(this, pageToken));
    }
}
