package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.hz.C0657a;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;

public class ia implements Creator<C0657a> {
    static void m1252a(C0657a c0657a, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, c0657a.getVersionCode());
        C0072b.m252c(parcel, 2, c0657a.fz());
        C0072b.m243a(parcel, 3, c0657a.fF());
        C0072b.m252c(parcel, 4, c0657a.fA());
        C0072b.m243a(parcel, 5, c0657a.fG());
        C0072b.m240a(parcel, 6, c0657a.fH(), false);
        C0072b.m252c(parcel, 7, c0657a.fI());
        C0072b.m240a(parcel, 8, c0657a.fK(), false);
        C0072b.m236a(parcel, 9, c0657a.fM(), i, false);
        C0072b.m228G(parcel, C);
    }

    public C0657a m1253H(Parcel parcel) {
        hu huVar = null;
        int i = 0;
        int B = C0071a.m189B(parcel);
        String str = null;
        String str2 = null;
        boolean z = false;
        int i2 = 0;
        boolean z2 = false;
        int i3 = 0;
        int i4 = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i4 = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    i3 = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    z2 = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.WALKING /*7*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    huVar = (hu) C0071a.m194a(parcel, A, hu.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new C0657a(i4, i3, z2, i2, z, str2, i, str, huVar);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public C0657a[] aw(int i) {
        return new C0657a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1253H(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aw(x0);
    }
}
