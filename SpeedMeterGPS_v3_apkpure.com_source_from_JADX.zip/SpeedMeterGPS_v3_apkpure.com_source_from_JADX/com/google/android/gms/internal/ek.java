package com.google.android.gms.internal;

import java.util.HashSet;

public interface ek {
    void m963a(HashSet<eh> hashSet);
}
