package com.google.android.gms.internal;

import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;

public final class cb<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
    private final bw nR;

    /* renamed from: com.google.android.gms.internal.cb.10 */
    class AnonymousClass10 implements Runnable {
        final /* synthetic */ cb nU;
        final /* synthetic */ ErrorCode nV;

        AnonymousClass10(cb cbVar, ErrorCode errorCode) {
            this.nU = cbVar;
            this.nV = errorCode;
        }

        public void run() {
            try {
                this.nU.nR.onAdFailedToLoad(cc.m841a(this.nV));
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.1 */
    class C01771 implements Runnable {
        final /* synthetic */ cb nU;

        C01771(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdClicked();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdClicked.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.2 */
    class C01782 implements Runnable {
        final /* synthetic */ cb nU;

        C01782(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdOpened();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdOpened.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.3 */
    class C01793 implements Runnable {
        final /* synthetic */ cb nU;

        C01793(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdLoaded();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLoaded.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.4 */
    class C01804 implements Runnable {
        final /* synthetic */ cb nU;

        C01804(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdClosed();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdClosed.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.5 */
    class C01815 implements Runnable {
        final /* synthetic */ cb nU;
        final /* synthetic */ ErrorCode nV;

        C01815(cb cbVar, ErrorCode errorCode) {
            this.nU = cbVar;
            this.nV = errorCode;
        }

        public void run() {
            try {
                this.nU.nR.onAdFailedToLoad(cc.m841a(this.nV));
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.6 */
    class C01826 implements Runnable {
        final /* synthetic */ cb nU;

        C01826(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdLeftApplication();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLeftApplication.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.7 */
    class C01837 implements Runnable {
        final /* synthetic */ cb nU;

        C01837(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdOpened();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdOpened.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.8 */
    class C01848 implements Runnable {
        final /* synthetic */ cb nU;

        C01848(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdLoaded();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLoaded.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.cb.9 */
    class C01859 implements Runnable {
        final /* synthetic */ cb nU;

        C01859(cb cbVar) {
            this.nU = cbVar;
        }

        public void run() {
            try {
                this.nU.nR.onAdClosed();
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdClosed.", e);
            }
        }
    }

    public cb(bw bwVar) {
        this.nR = bwVar;
    }

    public void onClick(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ev.m1018z("Adapter called onClick.");
        if (eu.bR()) {
            try {
                this.nR.onAdClicked();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdClicked.", e);
                return;
            }
        }
        ev.m1013D("onClick must be called on the main UI thread.");
        eu.ss.post(new C01771(this));
    }

    public void onDismissScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ev.m1018z("Adapter called onDismissScreen.");
        if (eu.bR()) {
            try {
                this.nR.onAdClosed();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdClosed.", e);
                return;
            }
        }
        ev.m1013D("onDismissScreen must be called on the main UI thread.");
        eu.ss.post(new C01804(this));
    }

    public void onDismissScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ev.m1018z("Adapter called onDismissScreen.");
        if (eu.bR()) {
            try {
                this.nR.onAdClosed();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdClosed.", e);
                return;
            }
        }
        ev.m1013D("onDismissScreen must be called on the main UI thread.");
        eu.ss.post(new C01859(this));
    }

    public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> mediationBannerAdapter, ErrorCode errorCode) {
        ev.m1018z("Adapter called onFailedToReceiveAd with error. " + errorCode);
        if (eu.bR()) {
            try {
                this.nR.onAdFailedToLoad(cc.m841a(errorCode));
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        ev.m1013D("onFailedToReceiveAd must be called on the main UI thread.");
        eu.ss.post(new C01815(this, errorCode));
    }

    public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter, ErrorCode errorCode) {
        ev.m1018z("Adapter called onFailedToReceiveAd with error " + errorCode + ".");
        if (eu.bR()) {
            try {
                this.nR.onAdFailedToLoad(cc.m841a(errorCode));
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        ev.m1013D("onFailedToReceiveAd must be called on the main UI thread.");
        eu.ss.post(new AnonymousClass10(this, errorCode));
    }

    public void onLeaveApplication(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ev.m1018z("Adapter called onLeaveApplication.");
        if (eu.bR()) {
            try {
                this.nR.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        ev.m1013D("onLeaveApplication must be called on the main UI thread.");
        eu.ss.post(new C01826(this));
    }

    public void onLeaveApplication(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ev.m1018z("Adapter called onLeaveApplication.");
        if (eu.bR()) {
            try {
                this.nR.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        ev.m1013D("onLeaveApplication must be called on the main UI thread.");
        eu.ss.post(new Runnable() {
            final /* synthetic */ cb nU;

            {
                this.nU = r1;
            }

            public void run() {
                try {
                    this.nU.nR.onAdLeftApplication();
                } catch (Throwable e) {
                    ev.m1016c("Could not call onAdLeftApplication.", e);
                }
            }
        });
    }

    public void onPresentScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ev.m1018z("Adapter called onPresentScreen.");
        if (eu.bR()) {
            try {
                this.nR.onAdOpened();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdOpened.", e);
                return;
            }
        }
        ev.m1013D("onPresentScreen must be called on the main UI thread.");
        eu.ss.post(new C01837(this));
    }

    public void onPresentScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ev.m1018z("Adapter called onPresentScreen.");
        if (eu.bR()) {
            try {
                this.nR.onAdOpened();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdOpened.", e);
                return;
            }
        }
        ev.m1013D("onPresentScreen must be called on the main UI thread.");
        eu.ss.post(new C01782(this));
    }

    public void onReceivedAd(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        ev.m1018z("Adapter called onReceivedAd.");
        if (eu.bR()) {
            try {
                this.nR.onAdLoaded();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLoaded.", e);
                return;
            }
        }
        ev.m1013D("onReceivedAd must be called on the main UI thread.");
        eu.ss.post(new C01848(this));
    }

    public void onReceivedAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        ev.m1018z("Adapter called onReceivedAd.");
        if (eu.bR()) {
            try {
                this.nR.onAdLoaded();
                return;
            } catch (Throwable e) {
                ev.m1016c("Could not call onAdLoaded.", e);
                return;
            }
        }
        ev.m1013D("onReceivedAd must be called on the main UI thread.");
        eu.ss.post(new C01793(this));
    }
}
