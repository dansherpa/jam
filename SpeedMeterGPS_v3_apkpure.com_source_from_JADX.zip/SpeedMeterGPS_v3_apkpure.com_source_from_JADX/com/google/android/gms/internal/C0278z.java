package com.google.android.gms.internal;

import android.os.Handler;
import java.lang.ref.WeakReference;

/* renamed from: com.google.android.gms.internal.z */
public final class C0278z {
    private final C0277a ld;
    private final Runnable le;
    private aj lf;
    private boolean lg;
    private boolean lh;
    private long li;

    /* renamed from: com.google.android.gms.internal.z.1 */
    class C02761 implements Runnable {
        private final WeakReference<C1020v> lj;
        final /* synthetic */ C1020v lk;
        final /* synthetic */ C0278z ll;

        C02761(C0278z c0278z, C1020v c1020v) {
            this.ll = c0278z;
            this.lk = c1020v;
            this.lj = new WeakReference(this.lk);
        }

        public void run() {
            this.ll.lg = false;
            C1020v c1020v = (C1020v) this.lj.get();
            if (c1020v != null) {
                c1020v.m3761b(this.ll.lf);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.z.a */
    public static class C0277a {
        private final Handler mHandler;

        public C0277a(Handler handler) {
            this.mHandler = handler;
        }

        public boolean postDelayed(Runnable runnable, long timeFromNowInMillis) {
            return this.mHandler.postDelayed(runnable, timeFromNowInMillis);
        }

        public void removeCallbacks(Runnable runnable) {
            this.mHandler.removeCallbacks(runnable);
        }
    }

    public C0278z(C1020v c1020v) {
        this(c1020v, new C0277a(eu.ss));
    }

    C0278z(C1020v c1020v, C0277a c0277a) {
        this.lg = false;
        this.lh = false;
        this.li = 0;
        this.ld = c0277a;
        this.le = new C02761(this, c1020v);
    }

    public void m1464a(aj ajVar, long j) {
        if (this.lg) {
            ev.m1013D("An ad refresh is already scheduled.");
            return;
        }
        this.lf = ajVar;
        this.lg = true;
        this.li = j;
        if (!this.lh) {
            ev.m1011B("Scheduling ad refresh " + j + " milliseconds from now.");
            this.ld.postDelayed(this.le, j);
        }
    }

    public void cancel() {
        this.lg = false;
        this.ld.removeCallbacks(this.le);
    }

    public void m1465d(aj ajVar) {
        m1464a(ajVar, 60000);
    }

    public void pause() {
        this.lh = true;
        if (this.lg) {
            this.ld.removeCallbacks(this.le);
        }
    }

    public void resume() {
        this.lh = false;
        if (this.lg) {
            this.lg = false;
            m1464a(this.lf, this.li);
        }
    }
}
