package com.google.android.gms.internal;

import com.google.android.gms.location.DetectedActivity;
import com.mochii.speedmo.C0450R;
import java.io.IOException;

public interface iw {

    /* renamed from: com.google.android.gms.internal.iw.a */
    public static final class C0996a extends mb<C0996a> {
        public C0995a[] Uv;

        /* renamed from: com.google.android.gms.internal.iw.a.a */
        public static final class C0995a extends mb<C0995a> {
            private static volatile C0995a[] Uw;
            public String Ux;
            public String Uy;
            public int viewId;

            public C0995a() {
                iN();
            }

            public static C0995a[] iM() {
                if (Uw == null) {
                    synchronized (md.amX) {
                        if (Uw == null) {
                            Uw = new C0995a[0];
                        }
                    }
                }
                return Uw;
            }

            public void m3642a(ma maVar) throws IOException {
                if (!this.Ux.equals("")) {
                    maVar.m1404b(1, this.Ux);
                }
                if (!this.Uy.equals("")) {
                    maVar.m1404b(2, this.Uy);
                }
                if (this.viewId != 0) {
                    maVar.m1410p(3, this.viewId);
                }
                super.m2814a(maVar);
            }

            public /* synthetic */ mf m3643b(lz lzVar) throws IOException {
                return m3645o(lzVar);
            }

            protected int m3644c() {
                int c = super.m2816c();
                if (!this.Ux.equals("")) {
                    c += ma.m1387h(1, this.Ux);
                }
                if (!this.Uy.equals("")) {
                    c += ma.m1387h(2, this.Uy);
                }
                return this.viewId != 0 ? c + ma.m1389r(3, this.viewId) : c;
            }

            public boolean equals(Object o) {
                if (o == this) {
                    return true;
                }
                if (!(o instanceof C0995a)) {
                    return false;
                }
                C0995a c0995a = (C0995a) o;
                if (this.Ux == null) {
                    if (c0995a.Ux != null) {
                        return false;
                    }
                } else if (!this.Ux.equals(c0995a.Ux)) {
                    return false;
                }
                if (this.Uy == null) {
                    if (c0995a.Uy != null) {
                        return false;
                    }
                } else if (!this.Uy.equals(c0995a.Uy)) {
                    return false;
                }
                if (this.viewId != c0995a.viewId) {
                    return false;
                }
                if (this.amU == null || this.amU.isEmpty()) {
                    return c0995a.amU == null || c0995a.amU.isEmpty();
                } else {
                    return this.amU.equals(c0995a.amU);
                }
            }

            public int hashCode() {
                int i = 0;
                int hashCode = ((((this.Uy == null ? 0 : this.Uy.hashCode()) + (((this.Ux == null ? 0 : this.Ux.hashCode()) + 527) * 31)) * 31) + this.viewId) * 31;
                if (!(this.amU == null || this.amU.isEmpty())) {
                    i = this.amU.hashCode();
                }
                return hashCode + i;
            }

            public C0995a iN() {
                this.Ux = "";
                this.Uy = "";
                this.viewId = 0;
                this.amU = null;
                this.amY = -1;
                return this;
            }

            public C0995a m3645o(lz lzVar) throws IOException {
                while (true) {
                    int nw = lzVar.nw();
                    switch (nw) {
                        case DetectedActivity.IN_VEHICLE /*0*/:
                            break;
                        case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                            this.Ux = lzVar.readString();
                            continue;
                        case 18:
                            this.Uy = lzVar.readString();
                            continue;
                        case 24:
                            this.viewId = lzVar.nz();
                            continue;
                        default:
                            if (!m2815a(lzVar, nw)) {
                                break;
                            }
                            continue;
                    }
                    return this;
                }
            }
        }

        public C0996a() {
            iL();
        }

        public void m3646a(ma maVar) throws IOException {
            if (this.Uv != null && this.Uv.length > 0) {
                for (mf mfVar : this.Uv) {
                    if (mfVar != null) {
                        maVar.m1398a(1, mfVar);
                    }
                }
            }
            super.m2814a(maVar);
        }

        public /* synthetic */ mf m3647b(lz lzVar) throws IOException {
            return m3649n(lzVar);
        }

        protected int m3648c() {
            int c = super.m2816c();
            if (this.Uv != null && this.Uv.length > 0) {
                for (mf mfVar : this.Uv) {
                    if (mfVar != null) {
                        c += ma.m1377b(1, mfVar);
                    }
                }
            }
            return c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0996a)) {
                return false;
            }
            C0996a c0996a = (C0996a) o;
            if (!md.equals(this.Uv, c0996a.Uv)) {
                return false;
            }
            if (this.amU == null || this.amU.isEmpty()) {
                return c0996a.amU == null || c0996a.amU.isEmpty();
            } else {
                return this.amU.equals(c0996a.amU);
            }
        }

        public int hashCode() {
            int hashCode = (md.hashCode(this.Uv) + 527) * 31;
            int hashCode2 = (this.amU == null || this.amU.isEmpty()) ? 0 : this.amU.hashCode();
            return hashCode2 + hashCode;
        }

        public C0996a iL() {
            this.Uv = C0995a.iM();
            this.amU = null;
            this.amY = -1;
            return this;
        }

        public C0996a m3649n(lz lzVar) throws IOException {
            while (true) {
                int nw = lzVar.nw();
                switch (nw) {
                    case DetectedActivity.IN_VEHICLE /*0*/:
                        break;
                    case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoImageType /*10*/:
                        int b = mi.m1429b(lzVar, 10);
                        nw = this.Uv == null ? 0 : this.Uv.length;
                        Object obj = new C0995a[(b + nw)];
                        if (nw != 0) {
                            System.arraycopy(this.Uv, 0, obj, 0, nw);
                        }
                        while (nw < obj.length - 1) {
                            obj[nw] = new C0995a();
                            lzVar.m1368a(obj[nw]);
                            lzVar.nw();
                            nw++;
                        }
                        obj[nw] = new C0995a();
                        lzVar.m1368a(obj[nw]);
                        this.Uv = obj;
                        continue;
                    default:
                        if (!m2815a(lzVar, nw)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }
}
