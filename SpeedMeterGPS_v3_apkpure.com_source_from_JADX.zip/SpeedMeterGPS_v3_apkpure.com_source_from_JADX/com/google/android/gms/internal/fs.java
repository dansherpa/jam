package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.appindexing.AppIndexApi.AppIndexingLink;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.fq.C0229a;
import com.google.android.gms.internal.iw.C0996a;
import com.google.android.gms.internal.iw.C0996a.C0995a;
import com.google.android.gms.plus.PlusShare;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;

public class fs implements SafeParcelable {
    public static final ft CREATOR;
    public final String mN;
    final int xJ;
    final fj yn;
    final long yo;
    final int yp;
    final fh yq;

    static {
        CREATOR = new ft();
    }

    fs(int i, fj fjVar, long j, int i2, String str, fh fhVar) {
        this.xJ = i;
        this.yn = fjVar;
        this.yo = j;
        this.yp = i2;
        this.mN = str;
        this.yq = fhVar;
    }

    public fs(fj fjVar, long j, int i) {
        this(1, fjVar, j, i, null, null);
    }

    public fs(String str, Intent intent, String str2, Uri uri, String str3, List<AppIndexingLink> list) {
        this(1, m2585a(str, intent), System.currentTimeMillis(), 0, null, m2584a(intent, str2, uri, str3, list));
    }

    static fh m2584a(Intent intent, String str, Uri uri, String str2, List<AppIndexingLink> list) {
        List arrayList = new ArrayList();
        arrayList.add(ab(str));
        if (uri != null) {
            arrayList.add(m2587e(uri));
        }
        if (list != null) {
            arrayList.add(m2586a(list));
        }
        String action = intent.getAction();
        if (action != null) {
            arrayList.add(m2588f("intent_action", action));
        }
        action = intent.getDataString();
        if (action != null) {
            arrayList.add(m2588f("intent_data", action));
        }
        ComponentName component = intent.getComponent();
        if (component != null) {
            arrayList.add(m2588f("intent_activity", component.getClassName()));
        }
        Bundle extras = intent.getExtras();
        if (extras != null) {
            action = extras.getString("intent_extra_data_key");
            if (action != null) {
                arrayList.add(m2588f("intent_extra_data", action));
            }
        }
        return new fh(str2, true, (fl[]) arrayList.toArray(new fl[arrayList.size()]));
    }

    public static fj m2585a(String str, Intent intent) {
        return new fj(str, "", m2589f(intent));
    }

    private static fl m2586a(List<AppIndexingLink> list) {
        mf c0996a = new C0996a();
        C0995a[] c0995aArr = new C0995a[list.size()];
        for (int i = 0; i < c0995aArr.length; i++) {
            c0995aArr[i] = new C0995a();
            AppIndexingLink appIndexingLink = (AppIndexingLink) list.get(i);
            c0995aArr[i].Ux = appIndexingLink.appIndexingUrl.toString();
            c0995aArr[i].Uy = appIndexingLink.webUrl.toString();
            c0995aArr[i].viewId = appIndexingLink.viewId;
        }
        c0996a.Uv = c0995aArr;
        return new fl(mf.m1422d(c0996a), new C0229a("outlinks").m1072w(true).aa(".private:outLinks").m1071Z("blob").dL());
    }

    private static fl ab(String str) {
        return new fl(str, new C0229a(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE).m1070I(1).m1073x(true).aa("name").dL(), "text1");
    }

    private static fl m2587e(Uri uri) {
        return new fl(uri.toString(), new C0229a("web_url").m1070I(4).m1072w(true).aa(PlusShare.KEY_CALL_TO_ACTION_URL).dL());
    }

    private static fl m2588f(String str, String str2) {
        return new fl(str2, new C0229a(str).m1072w(true).dL(), str);
    }

    private static String m2589f(Intent intent) {
        String toUri = intent.toUri(1);
        CRC32 crc32 = new CRC32();
        try {
            crc32.update(toUri.getBytes("UTF-8"));
            return Long.toHexString(crc32.getValue());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public int describeContents() {
        ft ftVar = CREATOR;
        return 0;
    }

    public String toString() {
        return String.format("UsageInfo[documentId=%s, timestamp=%d, usageType=%d]", new Object[]{this.yn, Long.valueOf(this.yo), Integer.valueOf(this.yp)});
    }

    public void writeToParcel(Parcel dest, int flags) {
        ft ftVar = CREATOR;
        ft.m1077a(this, dest, flags);
    }
}
