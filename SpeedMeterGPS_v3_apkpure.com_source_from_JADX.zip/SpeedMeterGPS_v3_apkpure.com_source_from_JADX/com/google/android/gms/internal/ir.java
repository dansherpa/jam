package com.google.android.gms.internal;

import com.google.android.gms.common.data.C0508a;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.C0923b;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.SearchableCollectionMetadataField;
import com.google.android.gms.drive.metadata.SearchableMetadataField;
import com.google.android.gms.drive.metadata.SortableMetadataField;
import com.google.android.gms.drive.metadata.internal.AppVisibleCustomProperties;
import com.google.android.gms.drive.metadata.internal.C0925b;
import com.google.android.gms.drive.metadata.internal.C0927g;
import com.google.android.gms.drive.metadata.internal.C0928j;
import com.google.android.gms.drive.metadata.internal.C0929l;
import com.google.android.gms.drive.metadata.internal.C1074i;
import com.google.android.gms.drive.metadata.internal.C1075k;
import com.google.android.gms.plus.PlusShare;
import java.util.Collection;
import java.util.Collections;

public class ir {
    public static final MetadataField<DriveId> JQ;
    public static final MetadataField<String> JR;
    public static final C1140a JS;
    public static final MetadataField<String> JT;
    public static final MetadataField<String> JU;
    public static final MetadataField<String> JV;
    public static final MetadataField<Long> JW;
    public static final MetadataField<Boolean> JX;
    public static final MetadataField<String> JY;
    public static final MetadataField<Boolean> JZ;
    public static final MetadataField<Boolean> Ka;
    public static final MetadataField<Boolean> Kb;
    public static final C1085b Kc;
    public static final MetadataField<Boolean> Kd;
    public static final MetadataField<Boolean> Ke;
    public static final MetadataField<Boolean> Kf;
    public static final MetadataField<Boolean> Kg;
    public static final C1086c Kh;
    public static final MetadataField<String> Ki;
    public static final C0923b<String> Kj;
    public static final C1141d Kk;
    public static final C1087e Kl;
    public static final C1088f Km;
    public static final MetadataField<C0508a> Kn;
    public static final C1089g Ko;
    public static final C1090h Kp;
    public static final MetadataField<String> Kq;
    public static final MetadataField<String> Kr;
    public static final MetadataField<String> Ks;

    /* renamed from: com.google.android.gms.internal.ir.1 */
    static class C10841 extends C0928j<C0508a> {
        C10841(String str, Collection collection, Collection collection2, int i) {
            super(str, collection, collection2, i);
        }

        protected /* synthetic */ Object m4049b(DataHolder dataHolder, int i, int i2) {
            return m4050i(dataHolder, i, i2);
        }

        protected C0508a m4050i(DataHolder dataHolder, int i, int i2) {
            throw new IllegalStateException("Thumbnail field is write only");
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.b */
    public static class C1085b extends C0925b implements SearchableMetadataField<Boolean> {
        public C1085b(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.c */
    public static class C1086c extends C0929l implements SearchableMetadataField<String> {
        public C1086c(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.e */
    public static class C1087e extends C0927g implements SortableMetadataField<Long> {
        public C1087e(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.f */
    public static class C1088f extends C0925b implements SearchableMetadataField<Boolean> {
        public C1088f(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.g */
    public static class C1089g extends C0929l implements SearchableMetadataField<String>, SortableMetadataField<String> {
        public C1089g(String str, int i) {
            super(str, i);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.h */
    public static class C1090h extends C0925b implements SearchableMetadataField<Boolean> {
        public C1090h(String str, int i) {
            super(str, i);
        }

        protected /* synthetic */ Object m4051b(DataHolder dataHolder, int i, int i2) {
            return m4052d(dataHolder, i, i2);
        }

        protected Boolean m4052d(DataHolder dataHolder, int i, int i2) {
            return Boolean.valueOf(dataHolder.m2014b(getName(), i, i2) != 0);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.a */
    public static class C1140a extends is implements SearchableMetadataField<AppVisibleCustomProperties> {
        public C1140a(int i) {
            super(i);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.d */
    public static class C1141d extends C1074i<DriveId> implements SearchableCollectionMetadataField<DriveId> {
        public C1141d(String str, int i) {
            super(str, i);
        }
    }

    static {
        JQ = iu.Ky;
        JR = new C0929l("alternateLink", 4300000);
        JS = new C1140a(5000000);
        JT = new C0929l(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, 4300000);
        JU = new C0929l("embedLink", 4300000);
        JV = new C0929l("fileExtension", 4300000);
        JW = new C0927g("fileSize", 4300000);
        JX = new C0925b("hasThumbnail", 4300000);
        JY = new C0929l("indexableText", 4300000);
        JZ = new C0925b("isAppData", 4300000);
        Ka = new C0925b("isCopyable", 4300000);
        Kb = new C0925b("isEditable", 4100000);
        Kc = new C1085b("isPinned", 4100000);
        Kd = new C0925b("isRestricted", 4300000);
        Ke = new C0925b("isShared", 4300000);
        Kf = new C0925b("isTrashable", 4400000);
        Kg = new C0925b("isViewed", 4300000);
        Kh = new C1086c("mimeType", 4100000);
        Ki = new C0929l("originalFilename", 4300000);
        Kj = new C1075k("ownerNames", 4300000);
        Kk = new C1141d("parents", 4100000);
        Kl = new C1087e("quotaBytesUsed", 4300000);
        Km = new C1088f("starred", 4100000);
        Kn = new C10841("thumbnail", Collections.emptySet(), Collections.emptySet(), 4400000);
        Ko = new C1089g(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, 4100000);
        Kp = new C1090h("trashed", 4100000);
        Kq = new C0929l("webContentLink", 4300000);
        Kr = new C0929l("webViewLink", 4300000);
        Ks = new C0929l("uniqueIdentifier", 5000000);
    }
}
