package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.internal.y */
class C0701y implements aa {
    private ey lc;

    public C0701y(ey eyVar) {
        this.lc = eyVar;
    }

    public void m2831a(ad adVar, boolean z) {
        Map hashMap = new HashMap();
        hashMap.put("isVisible", z ? "1" : "0");
        this.lc.m1028a("onAdVisibilityChanged", hashMap);
    }
}
