package com.google.android.gms.internal;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.cast.Cast;
import java.util.HashMap;
import java.util.Map;

public final class bc {
    public static final bd mR;
    public static final bd mS;
    public static final bd mT;
    public static final bd mU;
    public static final bd mV;
    public static final bd mW;
    public static final bd mX;
    public static final bd mY;
    public static final bd mZ;

    /* renamed from: com.google.android.gms.internal.bc.1 */
    static class C05781 implements bd {
        C05781() {
        }

        public void m2475b(ey eyVar, Map<String, String> map) {
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.2 */
    static class C05792 implements bd {
        C05792() {
        }

        public void m2476b(ey eyVar, Map<String, String> map) {
            String str = (String) map.get("urls");
            if (TextUtils.isEmpty(str)) {
                ev.m1013D("URLs missing in canOpenURLs GMSG.");
                return;
            }
            String[] split = str.split(",");
            Map hashMap = new HashMap();
            PackageManager packageManager = eyVar.getContext().getPackageManager();
            for (String str2 : split) {
                String[] split2 = str2.split(";", 2);
                hashMap.put(str2, Boolean.valueOf(packageManager.resolveActivity(new Intent(split2.length > 1 ? split2[1].trim() : "android.intent.action.VIEW", Uri.parse(split2[0].trim())), Cast.MAX_MESSAGE_LENGTH) != null));
            }
            eyVar.m1028a("openableURLs", hashMap);
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.3 */
    static class C05803 implements bd {
        C05803() {
        }

        public void m2477b(ey eyVar, Map<String, String> map) {
            String str = (String) map.get("u");
            if (str == null) {
                ev.m1013D("URL missing from click GMSG.");
                return;
            }
            Uri a;
            Uri parse = Uri.parse(str);
            try {
                C0259l bX = eyVar.bX();
                if (bX != null && bX.m1330a(parse)) {
                    a = bX.m1328a(parse, eyVar.getContext());
                    new et(eyVar.getContext(), eyVar.bY().st, a.toString()).start();
                }
            } catch (C0262m e) {
                ev.m1013D("Unable to append parameter to URL: " + str);
            }
            a = parse;
            new et(eyVar.getContext(), eyVar.bY().st, a.toString()).start();
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.4 */
    static class C05814 implements bd {
        C05814() {
        }

        public void m2478b(ey eyVar, Map<String, String> map) {
            cg bV = eyVar.bV();
            if (bV == null) {
                ev.m1013D("A GMSG tried to close something that wasn't an overlay.");
            } else {
                bV.close();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.5 */
    static class C05825 implements bd {
        C05825() {
        }

        public void m2479b(ey eyVar, Map<String, String> map) {
            cg bV = eyVar.bV();
            if (bV == null) {
                ev.m1013D("A GMSG tried to use a custom close button on something that wasn't an overlay.");
            } else {
                bV.m3551j("1".equals(map.get("custom_close")));
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.6 */
    static class C05836 implements bd {
        C05836() {
        }

        public void m2480b(ey eyVar, Map<String, String> map) {
            String str = (String) map.get("u");
            if (str == null) {
                ev.m1013D("URL missing from httpTrack GMSG.");
            } else {
                new et(eyVar.getContext(), eyVar.bY().st, str).start();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.7 */
    static class C05847 implements bd {
        C05847() {
        }

        public void m2481b(ey eyVar, Map<String, String> map) {
            ev.m1011B("Received log message: " + ((String) map.get("string")));
        }
    }

    /* renamed from: com.google.android.gms.internal.bc.8 */
    static class C05858 implements bd {
        C05858() {
        }

        public void m2482b(ey eyVar, Map<String, String> map) {
            String str = (String) map.get("ty");
            String str2 = (String) map.get("td");
            try {
                int parseInt = Integer.parseInt((String) map.get("tx"));
                int parseInt2 = Integer.parseInt(str);
                int parseInt3 = Integer.parseInt(str2);
                C0259l bX = eyVar.bX();
                if (bX != null) {
                    bX.m1331y().m1157a(parseInt, parseInt2, parseInt3);
                }
            } catch (NumberFormatException e) {
                ev.m1013D("Could not parse touch parameters from gmsg.");
            }
        }
    }

    static {
        mR = new C05781();
        mS = new C05792();
        mT = new C05803();
        mU = new C05814();
        mV = new C05825();
        mW = new C05836();
        mX = new C05847();
        mY = new C05858();
        mZ = new bi();
    }
}
