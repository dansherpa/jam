package com.google.android.gms.internal;

import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;
import java.util.Map;

public class ez extends WebViewClient {
    protected final ey lL;
    private final Object lq;
    private bb mQ;
    private bg na;
    private be nb;
    private C0217a pL;
    private final HashMap<String, bd> sE;
    private C0271u sF;
    private cj sG;
    private boolean sH;
    private boolean sI;
    private cm sJ;

    /* renamed from: com.google.android.gms.internal.ez.1 */
    class C02161 implements Runnable {
        final /* synthetic */ cg sK;
        final /* synthetic */ ez sL;

        C02161(ez ezVar, cg cgVar) {
            this.sL = ezVar;
            this.sK = cgVar;
        }

        public void run() {
            this.sK.aN();
        }
    }

    /* renamed from: com.google.android.gms.internal.ez.a */
    public interface C0217a {
        void m1032a(ey eyVar);
    }

    public ez(ey eyVar, boolean z) {
        this.sE = new HashMap();
        this.lq = new Object();
        this.sH = false;
        this.lL = eyVar;
        this.sI = z;
    }

    private static boolean m1033c(Uri uri) {
        String scheme = uri.getScheme();
        return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
    }

    private void m1034d(Uri uri) {
        String path = uri.getPath();
        bd bdVar = (bd) this.sE.get(path);
        if (bdVar != null) {
            Map b = ep.m979b(uri);
            if (ev.m1017p(2)) {
                ev.m1012C("Received GMSG: " + path);
                for (String path2 : b.keySet()) {
                    ev.m1012C("  " + path2 + ": " + ((String) b.get(path2)));
                }
            }
            bdVar.m823b(this.lL, b);
            return;
        }
        ev.m1012C("No GMSG handler found for GMSG: " + uri);
    }

    public final void m1035a(cf cfVar) {
        cj cjVar = null;
        boolean bZ = this.lL.bZ();
        C0271u c0271u = (!bZ || this.lL.m1024Q().md) ? this.sF : null;
        if (!bZ) {
            cjVar = this.sG;
        }
        m1036a(new ci(cfVar, c0271u, cjVar, this.sJ, this.lL.bY()));
    }

    protected void m1036a(ci ciVar) {
        cg.m3544a(this.lL.getContext(), ciVar);
    }

    public final void m1037a(C0217a c0217a) {
        this.pL = c0217a;
    }

    public void m1038a(C0271u c0271u, cj cjVar, bb bbVar, cm cmVar, boolean z, be beVar) {
        m1040a("/appEvent", new ba(bbVar));
        m1040a("/canOpenURLs", bc.mS);
        m1040a("/click", bc.mT);
        m1040a("/close", bc.mU);
        m1040a("/customClose", bc.mV);
        m1040a("/httpTrack", bc.mW);
        m1040a("/log", bc.mX);
        m1040a("/open", new bh(beVar));
        m1040a("/touch", bc.mY);
        m1040a("/video", bc.mZ);
        this.sF = c0271u;
        this.sG = cjVar;
        this.mQ = bbVar;
        this.nb = beVar;
        this.sJ = cmVar;
        m1044r(z);
    }

    public void m1039a(C0271u c0271u, cj cjVar, bb bbVar, cm cmVar, boolean z, be beVar, bg bgVar) {
        m1038a(c0271u, cjVar, bbVar, cmVar, z, beVar);
        m1040a("/setInterstitialProperties", new bf(bgVar));
        this.na = bgVar;
    }

    public final void m1040a(String str, bd bdVar) {
        this.sE.put(str, bdVar);
    }

    public final void m1041a(boolean z, int i) {
        C0271u c0271u = (!this.lL.bZ() || this.lL.m1024Q().md) ? this.sF : null;
        m1036a(new ci(c0271u, this.sG, this.sJ, this.lL, z, i, this.lL.bY()));
    }

    public final void m1042a(boolean z, int i, String str) {
        cj cjVar = null;
        boolean bZ = this.lL.bZ();
        C0271u c0271u = (!bZ || this.lL.m1024Q().md) ? this.sF : null;
        if (!bZ) {
            cjVar = this.sG;
        }
        m1036a(new ci(c0271u, cjVar, this.mQ, this.sJ, this.lL, z, i, str, this.lL.bY(), this.nb));
    }

    public final void m1043a(boolean z, int i, String str, String str2) {
        boolean bZ = this.lL.bZ();
        C0271u c0271u = (!bZ || this.lL.m1024Q().md) ? this.sF : null;
        m1036a(new ci(c0271u, bZ ? null : this.sG, this.mQ, this.sJ, this.lL, z, i, str, str2, this.lL.bY(), this.nb));
    }

    public final void aN() {
        synchronized (this.lq) {
            this.sH = false;
            this.sI = true;
            cg bV = this.lL.bV();
            if (bV != null) {
                if (eu.bR()) {
                    bV.aN();
                } else {
                    eu.ss.post(new C02161(this, bV));
                }
            }
        }
    }

    public boolean ce() {
        boolean z;
        synchronized (this.lq) {
            z = this.sI;
        }
        return z;
    }

    public final void onLoadResource(WebView webView, String url) {
        ev.m1012C("Loading resource: " + url);
        Uri parse = Uri.parse(url);
        if ("gmsg".equalsIgnoreCase(parse.getScheme()) && "mobileads.google.com".equalsIgnoreCase(parse.getHost())) {
            m1034d(parse);
        }
    }

    public final void onPageFinished(WebView webView, String url) {
        if (this.pL != null) {
            this.pL.m1032a(this.lL);
            this.pL = null;
        }
    }

    public final void m1044r(boolean z) {
        this.sH = z;
    }

    public final void reset() {
        synchronized (this.lq) {
            this.sE.clear();
            this.sF = null;
            this.sG = null;
            this.pL = null;
            this.mQ = null;
            this.sH = false;
            this.sI = false;
            this.nb = null;
            this.sJ = null;
        }
    }

    public final boolean shouldOverrideUrlLoading(WebView webView, String url) {
        ev.m1012C("AdWebView shouldOverrideUrlLoading: " + url);
        Uri parse = Uri.parse(url);
        if ("gmsg".equalsIgnoreCase(parse.getScheme()) && "mobileads.google.com".equalsIgnoreCase(parse.getHost())) {
            m1034d(parse);
        } else if (this.sH && webView == this.lL && m1033c(parse)) {
            return super.shouldOverrideUrlLoading(webView, url);
        } else {
            if (this.lL.willNotDraw()) {
                ev.m1013D("AdWebView unable to handle URL: " + url);
            } else {
                Uri uri;
                try {
                    C0259l bX = this.lL.bX();
                    if (bX != null && bX.m1330a(parse)) {
                        parse = bX.m1328a(parse, this.lL.getContext());
                    }
                    uri = parse;
                } catch (C0262m e) {
                    ev.m1013D("Unable to append parameter to URL: " + url);
                    uri = parse;
                }
                m1035a(new cf("android.intent.action.VIEW", uri.toString(), null, null, null, null, null));
            }
        }
        return true;
    }
}
