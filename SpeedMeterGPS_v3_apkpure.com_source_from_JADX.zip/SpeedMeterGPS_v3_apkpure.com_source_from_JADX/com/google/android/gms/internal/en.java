package com.google.android.gms.internal;

public abstract class en {
    private final Runnable le;
    private volatile Thread sc;

    /* renamed from: com.google.android.gms.internal.en.1 */
    class C02081 implements Runnable {
        final /* synthetic */ en sd;

        C02081(en enVar) {
            this.sd = enVar;
        }

        public final void run() {
            this.sd.sc = Thread.currentThread();
            this.sd.bc();
        }
    }

    public en() {
        this.le = new C02081(this);
    }

    public abstract void bc();

    public final void cancel() {
        onStop();
        if (this.sc != null) {
            this.sc.interrupt();
        }
    }

    public abstract void onStop();

    public final void start() {
        eo.execute(this.le);
    }
}
