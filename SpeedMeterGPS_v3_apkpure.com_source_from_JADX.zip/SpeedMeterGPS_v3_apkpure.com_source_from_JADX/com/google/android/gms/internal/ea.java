package com.google.android.gms.internal;

import java.util.Map;

public final class ea {
    private ey lL;
    private final Object lq;
    private int pH;
    public final bd qA;
    public final bd qB;
    private String qy;
    private ec qz;

    /* renamed from: com.google.android.gms.internal.ea.1 */
    class C06141 implements bd {
        final /* synthetic */ ea qC;

        C06141(ea eaVar) {
            this.qC = eaVar;
        }

        public void m2564b(ey eyVar, Map<String, String> map) {
            synchronized (this.qC.lq) {
                ec ecVar = new ec(map);
                ev.m1013D("Invalid " + ecVar.getType() + " request error: " + ecVar.bt());
                this.qC.pH = 1;
                this.qC.lq.notify();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.ea.2 */
    class C06152 implements bd {
        final /* synthetic */ ea qC;

        C06152(ea eaVar) {
            this.qC = eaVar;
        }

        public void m2565b(ey eyVar, Map<String, String> map) {
            synchronized (this.qC.lq) {
                ec ecVar = new ec(map);
                String url = ecVar.getUrl();
                if (url == null) {
                    ev.m1013D("URL missing in loadAdUrl GMSG.");
                    return;
                }
                if (url.contains("%40mediation_adapters%40")) {
                    ev.m1012C("Ad request URL modified to " + url.replaceAll("%40mediation_adapters%40", em.m965a(eyVar.getContext(), (String) map.get("check_adapters"), this.qC.qy)));
                }
                this.qC.qz = ecVar;
                this.qC.lq.notify();
            }
        }
    }

    public ea(String str) {
        this.lq = new Object();
        this.pH = -2;
        this.qA = new C06141(this);
        this.qB = new C06152(this);
        this.qy = str;
    }

    public void m927b(ey eyVar) {
        synchronized (this.lq) {
            this.lL = eyVar;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.android.gms.internal.ec bs() {
        /*
        r3 = this;
        r1 = r3.lq;
        monitor-enter(r1);
    L_0x0003:
        r0 = r3.qz;	 Catch:{ all -> 0x001f }
        if (r0 != 0) goto L_0x001b;
    L_0x0007:
        r0 = r3.pH;	 Catch:{ all -> 0x001f }
        r2 = -2;
        if (r0 != r2) goto L_0x001b;
    L_0x000c:
        r0 = r3.lq;	 Catch:{ InterruptedException -> 0x0012 }
        r0.wait();	 Catch:{ InterruptedException -> 0x0012 }
        goto L_0x0003;
    L_0x0012:
        r0 = move-exception;
        r0 = "Ad request service was interrupted.";
        com.google.android.gms.internal.ev.m1013D(r0);	 Catch:{ all -> 0x001f }
        r0 = 0;
        monitor-exit(r1);	 Catch:{ all -> 0x001f }
    L_0x001a:
        return r0;
    L_0x001b:
        r0 = r3.qz;	 Catch:{ all -> 0x001f }
        monitor-exit(r1);	 Catch:{ all -> 0x001f }
        goto L_0x001a;
    L_0x001f:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x001f }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ea.bs():com.google.android.gms.internal.ec");
    }

    public int getErrorCode() {
        int i;
        synchronized (this.lq) {
            i = this.pH;
        }
        return i;
    }
}
