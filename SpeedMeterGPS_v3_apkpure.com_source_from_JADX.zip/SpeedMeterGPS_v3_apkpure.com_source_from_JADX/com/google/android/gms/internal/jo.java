package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.wearable.DataEvent;
import java.util.List;

public class jo implements Creator<jn> {
    static void m1306a(jn jnVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m251b(parcel, 1, jnVar.VZ, false);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, jnVar.xJ);
        C0072b.m240a(parcel, 2, jnVar.jb(), false);
        C0072b.m243a(parcel, 3, jnVar.jc());
        C0072b.m251b(parcel, 4, jnVar.Wc, false);
        C0072b.m240a(parcel, 5, jnVar.jd(), false);
        C0072b.m241a(parcel, 6, jnVar.We, false);
        C0072b.m228G(parcel, C);
    }

    public jn bv(Parcel parcel) {
        boolean z = false;
        List list = null;
        int B = C0071a.m189B(parcel);
        String str = null;
        List list2 = null;
        String str2 = null;
        List list3 = null;
        int i = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    list3 = C0071a.m200c(parcel, A, jt.CREATOR);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str2 = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    z = C0071a.m201c(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    list2 = C0071a.m200c(parcel, A, jx.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case Quest.STATE_FAILED /*6*/:
                    list = C0071a.m190B(parcel, A);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new jn(i, list3, str2, z, list2, str, list);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public jn[] cQ(int i) {
        return new jn[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bv(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cQ(x0);
    }
}
