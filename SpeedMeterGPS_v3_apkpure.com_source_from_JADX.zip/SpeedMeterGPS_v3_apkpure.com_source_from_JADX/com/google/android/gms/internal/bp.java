package com.google.android.gms.internal;

import com.google.android.gms.internal.br.C0175a;
import com.google.android.gms.internal.bw.C0591a;

public final class bp extends C0591a {
    private final Object lq;
    private C0175a ny;
    private bo nz;

    public bp() {
        this.lq = new Object();
    }

    public void m3471a(bo boVar) {
        synchronized (this.lq) {
            this.nz = boVar;
        }
    }

    public void m3472a(C0175a c0175a) {
        synchronized (this.lq) {
            this.ny = c0175a;
        }
    }

    public void onAdClicked() {
        synchronized (this.lq) {
            if (this.nz != null) {
                this.nz.m829W();
            }
        }
    }

    public void onAdClosed() {
        synchronized (this.lq) {
            if (this.nz != null) {
                this.nz.m830X();
            }
        }
    }

    public void onAdFailedToLoad(int error) {
        synchronized (this.lq) {
            if (this.ny != null) {
                this.ny.m833g(error == 3 ? 1 : 2);
                this.ny = null;
            }
        }
    }

    public void onAdLeftApplication() {
        synchronized (this.lq) {
            if (this.nz != null) {
                this.nz.m831Y();
            }
        }
    }

    public void onAdLoaded() {
        synchronized (this.lq) {
            if (this.ny != null) {
                this.ny.m833g(0);
                this.ny = null;
                return;
            }
            if (this.nz != null) {
                this.nz.aa();
            }
        }
    }

    public void onAdOpened() {
        synchronized (this.lq) {
            if (this.nz != null) {
                this.nz.m832Z();
            }
        }
    }
}
