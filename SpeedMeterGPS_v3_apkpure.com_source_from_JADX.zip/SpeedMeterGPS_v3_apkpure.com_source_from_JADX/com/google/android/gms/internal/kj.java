package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0049c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.Account;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.Plus.C1096a;
import com.google.android.gms.plus.internal.C1039e;

public final class kj implements Account {

    /* renamed from: com.google.android.gms.internal.kj.a */
    private static abstract class C1152a extends C1096a<Status> {
        private C1152a() {
        }

        public /* synthetic */ Result m4243c(Status status) {
            return m4244d(status);
        }

        public Status m4244d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.kj.1 */
    class C13061 extends C1152a {
        final /* synthetic */ kj aca;

        C13061(kj kjVar) {
            this.aca = kjVar;
            super();
        }

        protected void m4643a(C1039e c1039e) {
            c1039e.m3793m(this);
        }
    }

    private static C1039e m2792a(GoogleApiClient googleApiClient, C0049c<C1039e> c0049c) {
        boolean z = true;
        hn.m1228b(googleApiClient != null, (Object) "GoogleApiClient parameter is required.");
        hn.m1224a(googleApiClient.isConnected(), "GoogleApiClient must be connected.");
        C1039e c1039e = (C1039e) googleApiClient.m138a((C0049c) c0049c);
        if (c1039e == null) {
            z = false;
        }
        hn.m1224a(z, "GoogleApiClient is not configured to use the Plus.API Api. Pass this into GoogleApiClient.Builder#addApi() to use this feature.");
        return c1039e;
    }

    public void clearDefaultAccount(GoogleApiClient googleApiClient) {
        m2792a(googleApiClient, Plus.yE).clearDefaultAccount();
    }

    public String getAccountName(GoogleApiClient googleApiClient) {
        return m2792a(googleApiClient, Plus.yE).getAccountName();
    }

    public PendingResult<Status> revokeAccessAndDisconnect(GoogleApiClient googleApiClient) {
        return googleApiClient.m140b(new C13061(this));
    }
}
