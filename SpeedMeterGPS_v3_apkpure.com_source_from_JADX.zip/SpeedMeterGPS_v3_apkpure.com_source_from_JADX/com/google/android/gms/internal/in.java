package com.google.android.gms.internal;

public final class in {
    public static boolean aE(int i) {
        return i >= 3200000;
    }
}
