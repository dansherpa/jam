package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.k */
public class C1091k extends C0998j {

    /* renamed from: com.google.android.gms.internal.k.a */
    class C0257a {
        private String kb;
        private boolean kc;
        final /* synthetic */ C1091k kd;

        public C0257a(C1091k c1091k, String str, boolean z) {
            this.kd = c1091k;
            this.kb = str;
            this.kc = z;
        }

        public String getId() {
            return this.kb;
        }

        public boolean isLimitAdTrackingEnabled() {
            return this.kc;
        }
    }

    private C1091k(Context context, C0264n c0264n, C0265o c0265o) {
        super(context, c0264n, c0265o);
    }

    public static C1091k m4057a(String str, Context context) {
        C0264n c0613e = new C0613e();
        C0998j.m3657a(str, context, c0613e);
        return new C1091k(context, c0613e, new C0694q(239));
    }

    protected void m4058b(Context context) {
        long j = 1;
        super.m3665b(context);
        try {
            C0257a f = m4059f(context);
            try {
                if (!f.isLimitAdTrackingEnabled()) {
                    j = 0;
                }
                m2725a(28, j);
                String id = f.getId();
                if (id != null) {
                    m2726a(30, id);
                }
            } catch (IOException e) {
            }
        } catch (GooglePlayServicesNotAvailableException e2) {
        } catch (IOException e3) {
            m2725a(28, 1);
        }
    }

    C0257a m4059f(Context context) throws IOException, GooglePlayServicesNotAvailableException {
        int i = 0;
        try {
            String str;
            Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
            String id = advertisingIdInfo.getId();
            if (id == null || !id.matches("^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$")) {
                str = id;
            } else {
                byte[] bArr = new byte[16];
                int i2 = 0;
                while (i < id.length()) {
                    if (i == 8 || i == 13 || i == 18 || i == 23) {
                        i++;
                    }
                    bArr[i2] = (byte) ((Character.digit(id.charAt(i), 16) << 4) + Character.digit(id.charAt(i + 1), 16));
                    i2++;
                    i += 2;
                }
                str = this.jQ.m1431a(bArr, true);
            }
            return new C0257a(this, str, advertisingIdInfo.isLimitAdTrackingEnabled());
        } catch (Throwable e) {
            throw new IOException(e);
        }
    }
}
