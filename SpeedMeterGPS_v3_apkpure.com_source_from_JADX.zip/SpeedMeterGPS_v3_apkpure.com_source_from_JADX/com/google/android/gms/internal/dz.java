package com.google.android.gms.internal;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.wearable.DataEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class dz {
    private static final SimpleDateFormat qx;

    static {
        qx = new SimpleDateFormat("yyyyMMdd");
    }

    public static dv m915a(Context context, dt dtVar, String str) {
        try {
            dv dvVar;
            int i;
            List list;
            List list2;
            List list3;
            JSONObject jSONObject = new JSONObject(str);
            String optString = jSONObject.optString("ad_base_url", null);
            String optString2 = jSONObject.optString("ad_url", null);
            String optString3 = jSONObject.optString("ad_size", null);
            String optString4 = jSONObject.optString("ad_html", null);
            long j = -1;
            String optString5 = jSONObject.optString("debug_dialog", null);
            long j2 = jSONObject.has("interstitial_timeout") ? (long) (jSONObject.getDouble("interstitial_timeout") * 1000.0d) : -1;
            String optString6 = jSONObject.optString("orientation", null);
            int i2 = -1;
            if ("portrait".equals(optString6)) {
                i2 = ep.bN();
            } else if ("landscape".equals(optString6)) {
                i2 = ep.bM();
            }
            if (TextUtils.isEmpty(optString4)) {
                if (TextUtils.isEmpty(optString2)) {
                    ev.m1013D("Could not parse the mediation config: Missing required ad_html or ad_url field.");
                    return new dv(0);
                }
                dv a = dy.m3568a(context, dtVar.kO.st, optString2, null, null);
                optString = a.oy;
                optString4 = a.qb;
                j = a.qh;
                dvVar = a;
            } else if (TextUtils.isEmpty(optString)) {
                ev.m1013D("Could not parse the mediation config: Missing required ad_base_url field");
                return new dv(0);
            } else {
                dvVar = null;
            }
            JSONArray optJSONArray = jSONObject.optJSONArray("click_urls");
            List list4 = dvVar == null ? null : dvVar.nr;
            if (optJSONArray != null) {
                if (list4 == null) {
                    list4 = new LinkedList();
                }
                for (i = 0; i < optJSONArray.length(); i++) {
                    list4.add(optJSONArray.getString(i));
                }
                list = list4;
            } else {
                list = list4;
            }
            JSONArray optJSONArray2 = jSONObject.optJSONArray("impression_urls");
            list4 = dvVar == null ? null : dvVar.ns;
            if (optJSONArray2 != null) {
                if (list4 == null) {
                    list4 = new LinkedList();
                }
                for (i = 0; i < optJSONArray2.length(); i++) {
                    list4.add(optJSONArray2.getString(i));
                }
                list2 = list4;
            } else {
                list2 = list4;
            }
            JSONArray optJSONArray3 = jSONObject.optJSONArray("manual_impression_urls");
            list4 = dvVar == null ? null : dvVar.qf;
            if (optJSONArray3 != null) {
                if (list4 == null) {
                    list4 = new LinkedList();
                }
                for (i = 0; i < optJSONArray3.length(); i++) {
                    list4.add(optJSONArray3.getString(i));
                }
                list3 = list4;
            } else {
                list3 = list4;
            }
            if (dvVar != null) {
                if (dvVar.orientation != -1) {
                    i2 = dvVar.orientation;
                }
                if (dvVar.qc > 0) {
                    j2 = dvVar.qc;
                }
            }
            String optString7 = jSONObject.optString("active_view");
            String str2 = null;
            boolean optBoolean = jSONObject.optBoolean("ad_is_javascript", false);
            if (optBoolean) {
                str2 = jSONObject.optString("ad_passback_url", null);
            }
            return new dv(optString, optString4, list, list2, j2, false, -1, list3, -1, i2, optString3, j, optString5, optBoolean, str2, optString7);
        } catch (JSONException e) {
            ev.m1013D("Could not parse the mediation config: " + e.getMessage());
            return new dv(0);
        }
    }

    public static String m916a(dt dtVar, ed edVar, Location location, String str) {
        try {
            HashMap hashMap = new HashMap();
            if (!(str == null || str.trim() == "")) {
                hashMap.put("eid", str);
            }
            if (dtVar.pU != null) {
                hashMap.put("ad_pos", dtVar.pU);
            }
            m918a(hashMap, dtVar.pV);
            hashMap.put("format", dtVar.kR.mc);
            if (dtVar.kR.width == -1) {
                hashMap.put("smart_w", "full");
            }
            if (dtVar.kR.height == -2) {
                hashMap.put("smart_h", "auto");
            }
            if (dtVar.kR.me != null) {
                StringBuilder stringBuilder = new StringBuilder();
                for (am amVar : dtVar.kR.me) {
                    if (stringBuilder.length() != 0) {
                        stringBuilder.append("|");
                    }
                    stringBuilder.append(amVar.width == -1 ? (int) (((float) amVar.widthPixels) / edVar.ro) : amVar.width);
                    stringBuilder.append("x");
                    stringBuilder.append(amVar.height == -2 ? (int) (((float) amVar.heightPixels) / edVar.ro) : amVar.height);
                }
                hashMap.put("sz", stringBuilder);
            }
            hashMap.put("slotname", dtVar.kL);
            hashMap.put("pn", dtVar.applicationInfo.packageName);
            if (dtVar.pW != null) {
                hashMap.put("vc", Integer.valueOf(dtVar.pW.versionCode));
            }
            hashMap.put("ms", dtVar.pX);
            hashMap.put("seq_num", dtVar.pY);
            hashMap.put("session_id", dtVar.pZ);
            hashMap.put("js", dtVar.kO.st);
            m920a(hashMap, edVar);
            if (dtVar.pV.versionCode >= 2 && dtVar.pV.lY != null) {
                m917a(hashMap, dtVar.pV.lY);
            }
            if (dtVar.versionCode >= 2) {
                hashMap.put("quality_signals", dtVar.qa);
            }
            if (ev.m1017p(2)) {
                ev.m1012C("Ad Request JSON: " + ep.m988o(hashMap).toString(2));
            }
            return ep.m988o(hashMap).toString();
        } catch (JSONException e) {
            ev.m1013D("Problem serializing ad request to JSON: " + e.getMessage());
            return null;
        }
    }

    private static void m917a(HashMap<String, Object> hashMap, Location location) {
        HashMap hashMap2 = new HashMap();
        Float valueOf = Float.valueOf(location.getAccuracy() * 1000.0f);
        Long valueOf2 = Long.valueOf(location.getTime() * 1000);
        Long valueOf3 = Long.valueOf((long) (location.getLatitude() * 1.0E7d));
        Long valueOf4 = Long.valueOf((long) (location.getLongitude() * 1.0E7d));
        hashMap2.put("radius", valueOf);
        hashMap2.put("lat", valueOf3);
        hashMap2.put("long", valueOf4);
        hashMap2.put("time", valueOf2);
        hashMap.put("uule", hashMap2);
    }

    private static void m918a(HashMap<String, Object> hashMap, aj ajVar) {
        String bK = em.bK();
        if (bK != null) {
            hashMap.put("abf", bK);
        }
        if (ajVar.lQ != -1) {
            hashMap.put("cust_age", qx.format(new Date(ajVar.lQ)));
        }
        if (ajVar.extras != null) {
            hashMap.put("extras", ajVar.extras);
        }
        if (ajVar.lR != -1) {
            hashMap.put("cust_gender", Integer.valueOf(ajVar.lR));
        }
        if (ajVar.lS != null) {
            hashMap.put("kw", ajVar.lS);
        }
        if (ajVar.lU != -1) {
            hashMap.put("tag_for_child_directed_treatment", Integer.valueOf(ajVar.lU));
        }
        if (ajVar.lT) {
            hashMap.put("adtest", "on");
        }
        if (ajVar.versionCode >= 2) {
            if (ajVar.lV) {
                hashMap.put("d_imp_hdr", Integer.valueOf(1));
            }
            if (!TextUtils.isEmpty(ajVar.lW)) {
                hashMap.put("ppid", ajVar.lW);
            }
            if (ajVar.lX != null) {
                m919a((HashMap) hashMap, ajVar.lX);
            }
        }
        if (ajVar.versionCode >= 3 && ajVar.lZ != null) {
            hashMap.put(PlusShare.KEY_CALL_TO_ACTION_URL, ajVar.lZ);
        }
    }

    private static void m919a(HashMap<String, Object> hashMap, ax axVar) {
        Object obj;
        Object obj2 = null;
        if (Color.alpha(axVar.mB) != 0) {
            hashMap.put("acolor", m922o(axVar.mB));
        }
        if (Color.alpha(axVar.backgroundColor) != 0) {
            hashMap.put("bgcolor", m922o(axVar.backgroundColor));
        }
        if (!(Color.alpha(axVar.mC) == 0 || Color.alpha(axVar.mD) == 0)) {
            hashMap.put("gradientto", m922o(axVar.mC));
            hashMap.put("gradientfrom", m922o(axVar.mD));
        }
        if (Color.alpha(axVar.mE) != 0) {
            hashMap.put("bcolor", m922o(axVar.mE));
        }
        hashMap.put("bthick", Integer.toString(axVar.mF));
        switch (axVar.mG) {
            case DetectedActivity.IN_VEHICLE /*0*/:
                obj = "none";
                break;
            case DataEvent.TYPE_CHANGED /*1*/:
                obj = "dashed";
                break;
            case DataEvent.TYPE_DELETED /*2*/:
                obj = "dotted";
                break;
            case DetectedActivity.STILL /*3*/:
                obj = "solid";
                break;
            default:
                obj = null;
                break;
        }
        if (obj != null) {
            hashMap.put("btype", obj);
        }
        switch (axVar.mH) {
            case DetectedActivity.IN_VEHICLE /*0*/:
                obj2 = "light";
                break;
            case DataEvent.TYPE_CHANGED /*1*/:
                obj2 = "medium";
                break;
            case DataEvent.TYPE_DELETED /*2*/:
                obj2 = "dark";
                break;
        }
        if (obj2 != null) {
            hashMap.put("callbuttoncolor", obj2);
        }
        if (axVar.mI != null) {
            hashMap.put("channel", axVar.mI);
        }
        if (Color.alpha(axVar.mJ) != 0) {
            hashMap.put("dcolor", m922o(axVar.mJ));
        }
        if (axVar.mK != null) {
            hashMap.put("font", axVar.mK);
        }
        if (Color.alpha(axVar.mL) != 0) {
            hashMap.put("hcolor", m922o(axVar.mL));
        }
        hashMap.put("headersize", Integer.toString(axVar.mM));
        if (axVar.mN != null) {
            hashMap.put("q", axVar.mN);
        }
    }

    private static void m920a(HashMap<String, Object> hashMap, ed edVar) {
        hashMap.put("am", Integer.valueOf(edVar.qY));
        hashMap.put("cog", m921m(edVar.qZ));
        hashMap.put("coh", m921m(edVar.ra));
        if (!TextUtils.isEmpty(edVar.rb)) {
            hashMap.put("carrier", edVar.rb);
        }
        hashMap.put("gl", edVar.rc);
        if (edVar.rd) {
            hashMap.put("simulator", Integer.valueOf(1));
        }
        hashMap.put("ma", m921m(edVar.re));
        hashMap.put("sp", m921m(edVar.rf));
        hashMap.put("hl", edVar.rg);
        if (!TextUtils.isEmpty(edVar.rh)) {
            hashMap.put("mv", edVar.rh);
        }
        hashMap.put("muv", Integer.valueOf(edVar.ri));
        if (edVar.rj != -2) {
            hashMap.put("cnt", Integer.valueOf(edVar.rj));
        }
        hashMap.put("gnt", Integer.valueOf(edVar.rk));
        hashMap.put("pt", Integer.valueOf(edVar.rl));
        hashMap.put("rm", Integer.valueOf(edVar.rm));
        hashMap.put("riv", Integer.valueOf(edVar.rn));
        hashMap.put("u_sd", Float.valueOf(edVar.ro));
        hashMap.put("sh", Integer.valueOf(edVar.rq));
        hashMap.put("sw", Integer.valueOf(edVar.rp));
        Bundle bundle = new Bundle();
        bundle.putInt("active_network_state", edVar.ru);
        bundle.putBoolean("active_network_metered", edVar.rt);
        hashMap.put("connectivity", bundle);
        bundle = new Bundle();
        bundle.putBoolean("is_charging", edVar.rs);
        bundle.putDouble("battery_level", edVar.rr);
        hashMap.put("battery", bundle);
    }

    private static Integer m921m(boolean z) {
        return Integer.valueOf(z ? 1 : 0);
    }

    private static String m922o(int i) {
        return String.format(Locale.US, "#%06x", new Object[]{Integer.valueOf(16777215 & i)});
    }
}
