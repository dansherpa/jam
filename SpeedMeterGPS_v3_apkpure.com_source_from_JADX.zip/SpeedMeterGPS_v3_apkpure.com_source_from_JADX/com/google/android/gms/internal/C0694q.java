package com.google.android.gms.internal;

import java.io.IOException;

/* renamed from: com.google.android.gms.internal.q */
class C0694q implements C0265o {
    private ma kl;
    private byte[] km;
    private final int kn;

    public C0694q(int i) {
        this.kn = i;
        reset();
    }

    public void m2817b(int i, long j) throws IOException {
        this.kl.m1403b(i, j);
    }

    public void m2818b(int i, String str) throws IOException {
        this.kl.m1404b(i, str);
    }

    public void reset() {
        this.km = new byte[this.kn];
        this.kl = ma.m1388q(this.km);
    }

    public byte[] m2819z() throws IOException {
        int nL = this.kl.nL();
        if (nL < 0) {
            throw new IOException();
        } else if (nL == 0) {
            return this.km;
        } else {
            Object obj = new byte[(this.km.length - nL)];
            System.arraycopy(this.km, 0, obj, 0, obj.length);
            return obj;
        }
    }
}
