package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.C0925b;
import com.google.android.gms.drive.metadata.internal.C0926f;

public class iv {
    public static final MetadataField<Boolean> KA;
    public static final MetadataField<Integer> Kz;

    static {
        Kz = new C0926f("contentAvailability", 4300000);
        KA = new C0925b("isPinnable", 4300000);
    }
}
