package com.google.android.gms.internal;

import android.app.Activity;
import android.os.RemoteException;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.dynamic.C0152d;
import com.google.android.gms.dynamic.C0931e;
import com.google.android.gms.internal.bv.C0589a;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONObject;

public final class ca<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> extends C0589a {
    private final MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> nS;
    private final NETWORK_EXTRAS nT;

    public ca(MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> mediationAdapter, NETWORK_EXTRAS network_extras) {
        this.nS = mediationAdapter;
        this.nT = network_extras;
    }

    private SERVER_PARAMETERS m3538b(String str, int i, String str2) throws RemoteException {
        Map hashMap;
        if (str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                hashMap = new HashMap(jSONObject.length());
                Iterator keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String str3 = (String) keys.next();
                    hashMap.put(str3, jSONObject.getString(str3));
                }
            } catch (Throwable th) {
                ev.m1016c("Could not get MediationServerParameters.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            hashMap = new HashMap(0);
        }
        Class serverParametersType = this.nS.getServerParametersType();
        if (serverParametersType == null) {
            return null;
        }
        MediationServerParameters mediationServerParameters = (MediationServerParameters) serverParametersType.newInstance();
        mediationServerParameters.load(hashMap);
        return mediationServerParameters;
    }

    public void m3539a(C0152d c0152d, aj ajVar, String str, bw bwVar) throws RemoteException {
        m3540a(c0152d, ajVar, str, null, bwVar);
    }

    public void m3540a(C0152d c0152d, aj ajVar, String str, String str2, bw bwVar) throws RemoteException {
        if (this.nS instanceof MediationInterstitialAdapter) {
            ev.m1018z("Requesting interstitial ad from adapter.");
            try {
                ((MediationInterstitialAdapter) this.nS).requestInterstitialAd(new cb(bwVar), (Activity) C0931e.m3241e(c0152d), m3538b(str, ajVar.lU, str2), cc.m843e(ajVar), this.nT);
            } catch (Throwable th) {
                ev.m1016c("Could not request interstitial ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            ev.m1013D("MediationAdapter is not a MediationInterstitialAdapter: " + this.nS.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void m3541a(C0152d c0152d, am amVar, aj ajVar, String str, bw bwVar) throws RemoteException {
        m3542a(c0152d, amVar, ajVar, str, null, bwVar);
    }

    public void m3542a(C0152d c0152d, am amVar, aj ajVar, String str, String str2, bw bwVar) throws RemoteException {
        if (this.nS instanceof MediationBannerAdapter) {
            ev.m1018z("Requesting banner ad from adapter.");
            try {
                ((MediationBannerAdapter) this.nS).requestBannerAd(new cb(bwVar), (Activity) C0931e.m3241e(c0152d), m3538b(str, ajVar.lU, str2), cc.m842b(amVar), cc.m843e(ajVar), this.nT);
            } catch (Throwable th) {
                ev.m1016c("Could not request banner ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            ev.m1013D("MediationAdapter is not a MediationBannerAdapter: " + this.nS.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void destroy() throws RemoteException {
        try {
            this.nS.destroy();
        } catch (Throwable th) {
            ev.m1016c("Could not destroy adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public C0152d getView() throws RemoteException {
        if (this.nS instanceof MediationBannerAdapter) {
            try {
                return C0931e.m3242h(((MediationBannerAdapter) this.nS).getBannerView());
            } catch (Throwable th) {
                ev.m1016c("Could not get banner view from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            ev.m1013D("MediationAdapter is not a MediationBannerAdapter: " + this.nS.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void pause() throws RemoteException {
        throw new RemoteException();
    }

    public void resume() throws RemoteException {
        throw new RemoteException();
    }

    public void showInterstitial() throws RemoteException {
        if (this.nS instanceof MediationInterstitialAdapter) {
            ev.m1018z("Showing interstitial from adapter.");
            try {
                ((MediationInterstitialAdapter) this.nS).showInterstitial();
            } catch (Throwable th) {
                ev.m1016c("Could not show interstitial from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            ev.m1013D("MediationAdapter is not a MediationInterstitialAdapter: " + this.nS.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }
}
