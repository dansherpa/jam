package com.google.android.gms.internal;

import android.util.Base64;

public final class ii {
    public static String m1269d(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 0);
    }

    public static String m1270e(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 10);
    }
}
