package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.hz.C0657a;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.plus.model.moments.ItemScope;
import com.google.android.gms.plus.model.moments.Moment;
import com.google.android.gms.wearable.DataEvent;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public final class kq extends hz implements SafeParcelable, Moment {
    public static final kr CREATOR;
    private static final HashMap<String, C0657a<?, ?>> aco;
    private final Set<Integer> acp;
    private String adc;
    private ko adk;
    private ko adl;
    private String qU;
    private String xD;
    private final int xJ;

    static {
        CREATOR = new kr();
        aco = new HashMap();
        aco.put("id", C0657a.m2714j("id", 2));
        aco.put("result", C0657a.m2708a("result", 4, ko.class));
        aco.put("startDate", C0657a.m2714j("startDate", 5));
        aco.put("target", C0657a.m2708a("target", 6, ko.class));
        aco.put("type", C0657a.m2714j("type", 7));
    }

    public kq() {
        this.xJ = 1;
        this.acp = new HashSet();
    }

    kq(Set<Integer> set, int i, String str, ko koVar, String str2, ko koVar2, String str3) {
        this.acp = set;
        this.xJ = i;
        this.xD = str;
        this.adk = koVar;
        this.adc = str2;
        this.adl = koVar2;
        this.qU = str3;
    }

    public kq(Set<Integer> set, String str, ko koVar, String str2, ko koVar2, String str3) {
        this.acp = set;
        this.xJ = 1;
        this.xD = str;
        this.adk = koVar;
        this.adc = str2;
        this.adl = koVar2;
        this.qU = str3;
    }

    protected boolean m3677a(C0657a c0657a) {
        return this.acp.contains(Integer.valueOf(c0657a.fI()));
    }

    protected Object aF(String str) {
        return null;
    }

    protected boolean aG(String str) {
        return false;
    }

    protected Object m3678b(C0657a c0657a) {
        switch (c0657a.fI()) {
            case DataEvent.TYPE_DELETED /*2*/:
                return this.xD;
            case DetectedActivity.UNKNOWN /*4*/:
                return this.adk;
            case DetectedActivity.TILTING /*5*/:
                return this.adc;
            case Quest.STATE_FAILED /*6*/:
                return this.adl;
            case DetectedActivity.WALKING /*7*/:
                return this.qU;
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + c0657a.fI());
        }
    }

    public int describeContents() {
        kr krVar = CREATOR;
        return 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof kq)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        kq kqVar = (kq) obj;
        for (C0657a c0657a : aco.values()) {
            if (m3677a(c0657a)) {
                if (!kqVar.m3677a(c0657a)) {
                    return false;
                }
                if (!m3678b(c0657a).equals(kqVar.m3678b(c0657a))) {
                    return false;
                }
            } else if (kqVar.m3677a(c0657a)) {
                return false;
            }
        }
        return true;
    }

    public HashMap<String, C0657a<?, ?>> fB() {
        return aco;
    }

    public /* synthetic */ Object freeze() {
        return ky();
    }

    public String getId() {
        return this.xD;
    }

    public ItemScope getResult() {
        return this.adk;
    }

    public String getStartDate() {
        return this.adc;
    }

    public ItemScope getTarget() {
        return this.adl;
    }

    public String getType() {
        return this.qU;
    }

    int getVersionCode() {
        return this.xJ;
    }

    public boolean hasId() {
        return this.acp.contains(Integer.valueOf(2));
    }

    public boolean hasResult() {
        return this.acp.contains(Integer.valueOf(4));
    }

    public boolean hasStartDate() {
        return this.acp.contains(Integer.valueOf(5));
    }

    public boolean hasTarget() {
        return this.acp.contains(Integer.valueOf(6));
    }

    public boolean hasType() {
        return this.acp.contains(Integer.valueOf(7));
    }

    public int hashCode() {
        int i = 0;
        for (C0657a c0657a : aco.values()) {
            int hashCode;
            if (m3677a(c0657a)) {
                hashCode = m3678b(c0657a).hashCode() + (i + c0657a.fI());
            } else {
                hashCode = i;
            }
            i = hashCode;
        }
        return i;
    }

    public boolean isDataValid() {
        return true;
    }

    Set<Integer> kf() {
        return this.acp;
    }

    ko kw() {
        return this.adk;
    }

    ko kx() {
        return this.adl;
    }

    public kq ky() {
        return this;
    }

    public void writeToParcel(Parcel out, int flags) {
        kr krVar = CREATOR;
        kr.m1319a(this, out, flags);
    }
}
