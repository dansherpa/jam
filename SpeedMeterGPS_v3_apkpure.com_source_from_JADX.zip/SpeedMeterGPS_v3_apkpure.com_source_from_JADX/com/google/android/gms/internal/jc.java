package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.location.Location;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderApi;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationServices.C1095a;

public class jc implements FusedLocationProviderApi {

    /* renamed from: com.google.android.gms.internal.jc.a */
    private static abstract class C1148a extends C1095a<Status> {
        private C1148a() {
        }

        public /* synthetic */ Result m4236c(Status status) {
            return m4237d(status);
        }

        public Status m4237d(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.1 */
    class C12941 extends C1148a {
        final /* synthetic */ LocationRequest Vt;
        final /* synthetic */ LocationListener Vu;
        final /* synthetic */ jc Vv;

        C12941(jc jcVar, LocationRequest locationRequest, LocationListener locationListener) {
            this.Vv = jcVar;
            this.Vt = locationRequest;
            this.Vu = locationListener;
            super();
        }

        protected void m4621a(jh jhVar) throws RemoteException {
            jhVar.requestLocationUpdates(this.Vt, this.Vu);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.2 */
    class C12952 extends C1148a {
        final /* synthetic */ LocationRequest Vt;
        final /* synthetic */ LocationListener Vu;
        final /* synthetic */ jc Vv;
        final /* synthetic */ Looper Vw;

        C12952(jc jcVar, LocationRequest locationRequest, LocationListener locationListener, Looper looper) {
            this.Vv = jcVar;
            this.Vt = locationRequest;
            this.Vu = locationListener;
            this.Vw = looper;
            super();
        }

        protected void m4623a(jh jhVar) throws RemoteException {
            jhVar.requestLocationUpdates(this.Vt, this.Vu, this.Vw);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.3 */
    class C12963 extends C1148a {
        final /* synthetic */ PendingIntent Vr;
        final /* synthetic */ LocationRequest Vt;
        final /* synthetic */ jc Vv;

        C12963(jc jcVar, LocationRequest locationRequest, PendingIntent pendingIntent) {
            this.Vv = jcVar;
            this.Vt = locationRequest;
            this.Vr = pendingIntent;
            super();
        }

        protected void m4625a(jh jhVar) throws RemoteException {
            jhVar.requestLocationUpdates(this.Vt, this.Vr);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.4 */
    class C12974 extends C1148a {
        final /* synthetic */ LocationListener Vu;
        final /* synthetic */ jc Vv;

        C12974(jc jcVar, LocationListener locationListener) {
            this.Vv = jcVar;
            this.Vu = locationListener;
            super();
        }

        protected void m4627a(jh jhVar) throws RemoteException {
            jhVar.removeLocationUpdates(this.Vu);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.5 */
    class C12985 extends C1148a {
        final /* synthetic */ PendingIntent Vr;
        final /* synthetic */ jc Vv;

        C12985(jc jcVar, PendingIntent pendingIntent) {
            this.Vv = jcVar;
            this.Vr = pendingIntent;
            super();
        }

        protected void m4629a(jh jhVar) throws RemoteException {
            jhVar.removeLocationUpdates(this.Vr);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.6 */
    class C12996 extends C1148a {
        final /* synthetic */ jc Vv;
        final /* synthetic */ boolean Vx;

        C12996(jc jcVar, boolean z) {
            this.Vv = jcVar;
            this.Vx = z;
            super();
        }

        protected void m4631a(jh jhVar) throws RemoteException {
            jhVar.setMockMode(this.Vx);
            m1988b(Status.Ek);
        }
    }

    /* renamed from: com.google.android.gms.internal.jc.7 */
    class C13007 extends C1148a {
        final /* synthetic */ jc Vv;
        final /* synthetic */ Location Vy;

        C13007(jc jcVar, Location location) {
            this.Vv = jcVar;
            this.Vy = location;
            super();
        }

        protected void m4633a(jh jhVar) throws RemoteException {
            jhVar.setMockLocation(this.Vy);
            m1988b(Status.Ek);
        }
    }

    public Location getLastLocation(GoogleApiClient client) {
        try {
            return LocationServices.m1469e(client).getLastLocation();
        } catch (Exception e) {
            return null;
        }
    }

    public PendingResult<Status> removeLocationUpdates(GoogleApiClient client, PendingIntent callbackIntent) {
        return client.m140b(new C12985(this, callbackIntent));
    }

    public PendingResult<Status> removeLocationUpdates(GoogleApiClient client, LocationListener listener) {
        return client.m140b(new C12974(this, listener));
    }

    public PendingResult<Status> requestLocationUpdates(GoogleApiClient client, LocationRequest request, PendingIntent callbackIntent) {
        return client.m140b(new C12963(this, request, callbackIntent));
    }

    public PendingResult<Status> requestLocationUpdates(GoogleApiClient client, LocationRequest request, LocationListener listener) {
        return client.m140b(new C12941(this, request, listener));
    }

    public PendingResult<Status> requestLocationUpdates(GoogleApiClient client, LocationRequest request, LocationListener listener, Looper looper) {
        return client.m140b(new C12952(this, request, listener, looper));
    }

    public PendingResult<Status> setMockLocation(GoogleApiClient client, Location mockLocation) {
        return client.m140b(new C13007(this, mockLocation));
    }

    public PendingResult<Status> setMockMode(GoogleApiClient client, boolean isMockMode) {
        return client.m140b(new C12996(this, isMockMode));
    }
}
