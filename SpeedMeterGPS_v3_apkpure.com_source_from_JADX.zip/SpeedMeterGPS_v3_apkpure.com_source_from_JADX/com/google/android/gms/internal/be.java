package com.google.android.gms.internal;

import java.util.ArrayList;

public interface be {
    void m824a(String str, ArrayList<String> arrayList);
}
