package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.Notifications;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.kt.C1006a;
import com.google.android.gms.internal.kt.C1009b;
import com.google.android.gms.internal.kt.C1010c;
import com.google.android.gms.internal.kt.C1011d;
import com.google.android.gms.internal.kt.C1012f;
import com.google.android.gms.internal.kt.C1013g;
import com.google.android.gms.internal.kt.C1014h;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ku implements Creator<kt> {
    static void m1320a(kt ktVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        Set kf = ktVar.kf();
        if (kf.contains(Integer.valueOf(1))) {
            C0072b.m252c(parcel, 1, ktVar.getVersionCode());
        }
        if (kf.contains(Integer.valueOf(2))) {
            C0072b.m240a(parcel, 2, ktVar.getAboutMe(), true);
        }
        if (kf.contains(Integer.valueOf(3))) {
            C0072b.m236a(parcel, 3, ktVar.kA(), i, true);
        }
        if (kf.contains(Integer.valueOf(4))) {
            C0072b.m240a(parcel, 4, ktVar.getBirthday(), true);
        }
        if (kf.contains(Integer.valueOf(5))) {
            C0072b.m240a(parcel, 5, ktVar.getBraggingRights(), true);
        }
        if (kf.contains(Integer.valueOf(6))) {
            C0072b.m252c(parcel, 6, ktVar.getCircledByCount());
        }
        if (kf.contains(Integer.valueOf(7))) {
            C0072b.m236a(parcel, 7, ktVar.kB(), i, true);
        }
        if (kf.contains(Integer.valueOf(8))) {
            C0072b.m240a(parcel, 8, ktVar.getCurrentLocation(), true);
        }
        if (kf.contains(Integer.valueOf(9))) {
            C0072b.m240a(parcel, 9, ktVar.getDisplayName(), true);
        }
        if (kf.contains(Integer.valueOf(12))) {
            C0072b.m252c(parcel, 12, ktVar.getGender());
        }
        if (kf.contains(Integer.valueOf(14))) {
            C0072b.m240a(parcel, 14, ktVar.getId(), true);
        }
        if (kf.contains(Integer.valueOf(15))) {
            C0072b.m236a(parcel, 15, ktVar.kC(), i, true);
        }
        if (kf.contains(Integer.valueOf(16))) {
            C0072b.m243a(parcel, 16, ktVar.isPlusUser());
        }
        if (kf.contains(Integer.valueOf(19))) {
            C0072b.m236a(parcel, 19, ktVar.kD(), i, true);
        }
        if (kf.contains(Integer.valueOf(18))) {
            C0072b.m240a(parcel, 18, ktVar.getLanguage(), true);
        }
        if (kf.contains(Integer.valueOf(21))) {
            C0072b.m252c(parcel, 21, ktVar.getObjectType());
        }
        if (kf.contains(Integer.valueOf(20))) {
            C0072b.m240a(parcel, 20, ktVar.getNickname(), true);
        }
        if (kf.contains(Integer.valueOf(23))) {
            C0072b.m251b(parcel, 23, ktVar.kF(), true);
        }
        if (kf.contains(Integer.valueOf(22))) {
            C0072b.m251b(parcel, 22, ktVar.kE(), true);
        }
        if (kf.contains(Integer.valueOf(25))) {
            C0072b.m252c(parcel, 25, ktVar.getRelationshipStatus());
        }
        if (kf.contains(Integer.valueOf(24))) {
            C0072b.m252c(parcel, 24, ktVar.getPlusOneCount());
        }
        if (kf.contains(Integer.valueOf(27))) {
            C0072b.m240a(parcel, 27, ktVar.getUrl(), true);
        }
        if (kf.contains(Integer.valueOf(26))) {
            C0072b.m240a(parcel, 26, ktVar.getTagline(), true);
        }
        if (kf.contains(Integer.valueOf(29))) {
            C0072b.m243a(parcel, 29, ktVar.isVerified());
        }
        if (kf.contains(Integer.valueOf(28))) {
            C0072b.m251b(parcel, 28, ktVar.kG(), true);
        }
        C0072b.m228G(parcel, C);
    }

    public kt bG(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        String str = null;
        C1006a c1006a = null;
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        C1009b c1009b = null;
        String str4 = null;
        String str5 = null;
        int i3 = 0;
        String str6 = null;
        C1010c c1010c = null;
        boolean z = false;
        String str7 = null;
        C1011d c1011d = null;
        String str8 = null;
        int i4 = 0;
        List list = null;
        List list2 = null;
        int i5 = 0;
        int i6 = 0;
        String str9 = null;
        String str10 = null;
        List list3 = null;
        boolean z2 = false;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    str = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case DetectedActivity.STILL /*3*/:
                    C1006a c1006a2 = (C1006a) C0071a.m194a(parcel, A, C1006a.CREATOR);
                    hashSet.add(Integer.valueOf(3));
                    c1006a = c1006a2;
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    str2 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(4));
                    break;
                case DetectedActivity.TILTING /*5*/:
                    str3 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case Quest.STATE_FAILED /*6*/:
                    i2 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(6));
                    break;
                case DetectedActivity.WALKING /*7*/:
                    C1009b c1009b2 = (C1009b) C0071a.m194a(parcel, A, C1009b.CREATOR);
                    hashSet.add(Integer.valueOf(7));
                    c1009b = c1009b2;
                    break;
                case DetectedActivity.RUNNING /*8*/:
                    str4 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(8));
                    break;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    str5 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(9));
                    break;
                case C0450R.styleable.MapAttrs_useViewLifecycle /*12*/:
                    i3 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(12));
                    break;
                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                    str6 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(14));
                    break;
                case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                    C1010c c1010c2 = (C1010c) C0071a.m194a(parcel, A, C1010c.CREATOR);
                    hashSet.add(Integer.valueOf(15));
                    c1010c = c1010c2;
                    break;
                case Notifications.NOTIFICATION_TYPE_LEVEL_UP /*16*/:
                    z = C0071a.m201c(parcel, A);
                    hashSet.add(Integer.valueOf(16));
                    break;
                case 18:
                    str7 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(18));
                    break;
                case 19:
                    C1011d c1011d2 = (C1011d) C0071a.m194a(parcel, A, C1011d.CREATOR);
                    hashSet.add(Integer.valueOf(19));
                    c1011d = c1011d2;
                    break;
                case 20:
                    str8 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(20));
                    break;
                case 21:
                    i4 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(21));
                    break;
                case 22:
                    list = C0071a.m200c(parcel, A, C1012f.CREATOR);
                    hashSet.add(Integer.valueOf(22));
                    break;
                case 23:
                    list2 = C0071a.m200c(parcel, A, C1013g.CREATOR);
                    hashSet.add(Integer.valueOf(23));
                    break;
                case 24:
                    i5 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(24));
                    break;
                case 25:
                    i6 = C0071a.m205g(parcel, A);
                    hashSet.add(Integer.valueOf(25));
                    break;
                case 26:
                    str9 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(26));
                    break;
                case 27:
                    str10 = C0071a.m213o(parcel, A);
                    hashSet.add(Integer.valueOf(27));
                    break;
                case 28:
                    list3 = C0071a.m200c(parcel, A, C1014h.CREATOR);
                    hashSet.add(Integer.valueOf(28));
                    break;
                case 29:
                    z2 = C0071a.m201c(parcel, A);
                    hashSet.add(Integer.valueOf(29));
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new kt(hashSet, i, str, c1006a, str2, str3, i2, c1009b, str4, str5, i3, str6, c1010c, z, str7, c1011d, str8, i4, list, list2, i5, i6, str9, str10, list3, z2);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bG(x0);
    }

    public kt[] dd(int i) {
        return new kt[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return dd(x0);
    }
}
