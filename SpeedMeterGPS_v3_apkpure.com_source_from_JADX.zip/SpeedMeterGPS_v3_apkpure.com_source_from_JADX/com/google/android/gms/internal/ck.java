package com.google.android.gms.internal;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.MediaController;
import android.widget.VideoView;
import com.google.android.gms.tagmanager.DataLayer;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public final class ck extends FrameLayout implements OnCompletionListener, OnErrorListener, OnPreparedListener {
    private final ey lL;
    private final MediaController oG;
    private final C0191a oH;
    private final VideoView oI;
    private long oJ;
    private String oK;

    /* renamed from: com.google.android.gms.internal.ck.a */
    private static final class C0191a {
        private final Runnable le;
        private volatile boolean oL;

        /* renamed from: com.google.android.gms.internal.ck.a.1 */
        class C01901 implements Runnable {
            private final WeakReference<ck> oM;
            final /* synthetic */ ck oN;
            final /* synthetic */ C0191a oO;

            C01901(C0191a c0191a, ck ckVar) {
                this.oO = c0191a;
                this.oN = ckVar;
                this.oM = new WeakReference(this.oN);
            }

            public void run() {
                ck ckVar = (ck) this.oM.get();
                if (!this.oO.oL && ckVar != null) {
                    ckVar.aW();
                    this.oO.aX();
                }
            }
        }

        public C0191a(ck ckVar) {
            this.oL = false;
            this.le = new C01901(this, ckVar);
        }

        public void aX() {
            eu.ss.postDelayed(this.le, 250);
        }

        public void cancel() {
            this.oL = true;
            eu.ss.removeCallbacks(this.le);
        }
    }

    public ck(Context context, ey eyVar) {
        super(context);
        this.lL = eyVar;
        this.oI = new VideoView(context);
        addView(this.oI, new LayoutParams(-1, -1, 17));
        this.oG = new MediaController(context);
        this.oH = new C0191a(this);
        this.oH.aX();
        this.oI.setOnCompletionListener(this);
        this.oI.setOnPreparedListener(this);
        this.oI.setOnErrorListener(this);
    }

    private static void m855a(ey eyVar, String str) {
        m858a(eyVar, str, new HashMap(1));
    }

    public static void m856a(ey eyVar, String str, String str2) {
        Object obj = str2 == null ? 1 : null;
        Map hashMap = new HashMap(obj != null ? 2 : 3);
        hashMap.put("what", str);
        if (obj == null) {
            hashMap.put("extra", str2);
        }
        m858a(eyVar, "error", hashMap);
    }

    private static void m857a(ey eyVar, String str, String str2, String str3) {
        Map hashMap = new HashMap(2);
        hashMap.put(str2, str3);
        m858a(eyVar, str, hashMap);
    }

    private static void m858a(ey eyVar, String str, Map<String, String> map) {
        map.put(DataLayer.EVENT_KEY, str);
        eyVar.m1028a("onVideoEvent", (Map) map);
    }

    public void aV() {
        if (TextUtils.isEmpty(this.oK)) {
            m856a(this.lL, "no_src", null);
        } else {
            this.oI.setVideoPath(this.oK);
        }
    }

    public void aW() {
        long currentPosition = (long) this.oI.getCurrentPosition();
        if (this.oJ != currentPosition) {
            m857a(this.lL, "timeupdate", "time", String.valueOf(((float) currentPosition) / 1000.0f));
            this.oJ = currentPosition;
        }
    }

    public void m859b(MotionEvent motionEvent) {
        this.oI.dispatchTouchEvent(motionEvent);
    }

    public void destroy() {
        this.oH.cancel();
        this.oI.stopPlayback();
    }

    public void m860l(boolean z) {
        if (z) {
            this.oI.setMediaController(this.oG);
            return;
        }
        this.oG.hide();
        this.oI.setMediaController(null);
    }

    public void m861o(String str) {
        this.oK = str;
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        m855a(this.lL, "ended");
    }

    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
        m856a(this.lL, String.valueOf(what), String.valueOf(extra));
        return true;
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        m857a(this.lL, "canplaythrough", "duration", String.valueOf(((float) this.oI.getDuration()) / 1000.0f));
    }

    public void pause() {
        this.oI.pause();
    }

    public void play() {
        this.oI.start();
    }

    public void seekTo(int timeInMilliseconds) {
        this.oI.seekTo(timeInMilliseconds);
    }
}
