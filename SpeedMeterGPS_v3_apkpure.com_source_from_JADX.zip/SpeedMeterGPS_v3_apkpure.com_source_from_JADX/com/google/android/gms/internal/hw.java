package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.hz.C0253b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public final class hw implements SafeParcelable, C0253b<String, Integer> {
    public static final hx CREATOR;
    private final HashMap<String, Integer> GT;
    private final HashMap<Integer, String> GU;
    private final ArrayList<C0656a> GV;
    private final int xJ;

    /* renamed from: com.google.android.gms.internal.hw.a */
    public static final class C0656a implements SafeParcelable {
        public static final hy CREATOR;
        final String GW;
        final int GX;
        final int versionCode;

        static {
            CREATOR = new hy();
        }

        C0656a(int i, String str, int i2) {
            this.versionCode = i;
            this.GW = str;
            this.GX = i2;
        }

        C0656a(String str, int i) {
            this.versionCode = 1;
            this.GW = str;
            this.GX = i;
        }

        public int describeContents() {
            hy hyVar = CREATOR;
            return 0;
        }

        public void writeToParcel(Parcel out, int flags) {
            hy hyVar = CREATOR;
            hy.m1244a(this, out, flags);
        }
    }

    static {
        CREATOR = new hx();
    }

    public hw() {
        this.xJ = 1;
        this.GT = new HashMap();
        this.GU = new HashMap();
        this.GV = null;
    }

    hw(int i, ArrayList<C0656a> arrayList) {
        this.xJ = i;
        this.GT = new HashMap();
        this.GU = new HashMap();
        this.GV = null;
        m2703a((ArrayList) arrayList);
    }

    private void m2703a(ArrayList<C0656a> arrayList) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            C0656a c0656a = (C0656a) it.next();
            m2705f(c0656a.GW, c0656a.GX);
        }
    }

    public String m2704a(Integer num) {
        String str = (String) this.GU.get(num);
        return (str == null && this.GT.containsKey("gms_unknown")) ? "gms_unknown" : str;
    }

    public int describeContents() {
        hx hxVar = CREATOR;
        return 0;
    }

    public hw m2705f(String str, int i) {
        this.GT.put(str, Integer.valueOf(i));
        this.GU.put(Integer.valueOf(i), str);
        return this;
    }

    public int fA() {
        return 0;
    }

    ArrayList<C0656a> fy() {
        ArrayList<C0656a> arrayList = new ArrayList();
        for (String str : this.GT.keySet()) {
            arrayList.add(new C0656a(str, ((Integer) this.GT.get(str)).intValue()));
        }
        return arrayList;
    }

    public int fz() {
        return 7;
    }

    public /* synthetic */ Object m2706g(Object obj) {
        return m2704a((Integer) obj);
    }

    int getVersionCode() {
        return this.xJ;
    }

    public void writeToParcel(Parcel out, int flags) {
        hx hxVar = CREATOR;
        hx.m1242a(this, out, flags);
    }
}
