package com.google.android.gms.internal;

import android.view.View;
import android.webkit.WebChromeClient.CustomViewCallback;

public final class fc extends fa {
    public fc(ey eyVar) {
        super(eyVar);
    }

    public void onShowCustomView(View view, int requestedOrientation, CustomViewCallback customViewCallback) {
        m1049a(view, requestedOrientation, customViewCallback);
    }
}
