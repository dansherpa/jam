package com.google.android.gms.internal;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.internal.lp.C0691a;
import com.google.android.gms.internal.lq.C0693a;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wallet.C0860d;
import com.google.android.gms.wallet.FullWalletRequest;
import com.google.android.gms.wallet.MaskedWalletRequest;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest;
import com.google.android.gms.wearable.DataEvent;
import com.mochii.speedmo.C0450R;

public interface ln extends IInterface {

    /* renamed from: com.google.android.gms.internal.ln.a */
    public static abstract class C0687a extends Binder implements ln {

        /* renamed from: com.google.android.gms.internal.ln.a.a */
        private static class C0686a implements ln {
            private IBinder ko;

            C0686a(IBinder iBinder) {
                this.ko = iBinder;
            }

            public void m2795a(Bundle bundle, lq lqVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lqVar != null) {
                        iBinder = lqVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(5, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2796a(lh lhVar, Bundle bundle, lq lqVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (lhVar != null) {
                        obtain.writeInt(1);
                        lhVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lqVar != null) {
                        iBinder = lqVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(8, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2797a(FullWalletRequest fullWalletRequest, Bundle bundle, lq lqVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (fullWalletRequest != null) {
                        obtain.writeInt(1);
                        fullWalletRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lqVar != null) {
                        iBinder = lqVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(2, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2798a(MaskedWalletRequest maskedWalletRequest, Bundle bundle, lp lpVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (maskedWalletRequest != null) {
                        obtain.writeInt(1);
                        maskedWalletRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lpVar != null) {
                        iBinder = lpVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(7, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2799a(MaskedWalletRequest maskedWalletRequest, Bundle bundle, lq lqVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (maskedWalletRequest != null) {
                        obtain.writeInt(1);
                        maskedWalletRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lqVar != null) {
                        iBinder = lqVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(1, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2800a(NotifyTransactionStatusRequest notifyTransactionStatusRequest, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (notifyTransactionStatusRequest != null) {
                        obtain.writeInt(1);
                        notifyTransactionStatusRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.ko.transact(4, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2801a(C0860d c0860d, Bundle bundle, lq lqVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (c0860d != null) {
                        obtain.writeInt(1);
                        c0860d.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lqVar != null) {
                        iBinder = lqVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(6, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void m2802a(String str, String str2, Bundle bundle, lq lqVar) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lqVar != null) {
                        iBinder = lqVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    this.ko.transact(3, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.ko;
            }

            public void m2803o(Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.wallet.internal.IOwService");
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.ko.transact(9, obtain, null, 1);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public static ln bq(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.wallet.internal.IOwService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ln)) ? new C0686a(iBinder) : (ln) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1344a(data.readInt() != 0 ? (MaskedWalletRequest) MaskedWalletRequest.CREATOR.createFromParcel(data) : null, data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0693a.bt(data.readStrongBinder()));
                    return true;
                case DataEvent.TYPE_DELETED /*2*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1342a(data.readInt() != 0 ? (FullWalletRequest) FullWalletRequest.CREATOR.createFromParcel(data) : null, data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0693a.bt(data.readStrongBinder()));
                    return true;
                case DetectedActivity.STILL /*3*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1347a(data.readString(), data.readString(), data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0693a.bt(data.readStrongBinder()));
                    return true;
                case DetectedActivity.UNKNOWN /*4*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1345a(data.readInt() != 0 ? (NotifyTransactionStatusRequest) NotifyTransactionStatusRequest.CREATOR.createFromParcel(data) : null, data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null);
                    return true;
                case DetectedActivity.TILTING /*5*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1340a(data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0693a.bt(data.readStrongBinder()));
                    return true;
                case Quest.STATE_FAILED /*6*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1346a(data.readInt() != 0 ? (C0860d) C0860d.CREATOR.createFromParcel(data) : null, data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0693a.bt(data.readStrongBinder()));
                    return true;
                case DetectedActivity.WALKING /*7*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1343a(data.readInt() != 0 ? (MaskedWalletRequest) MaskedWalletRequest.CREATOR.createFromParcel(data) : null, data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0691a.bs(data.readStrongBinder()));
                    return true;
                case DetectedActivity.RUNNING /*8*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1341a(data.readInt() != 0 ? (lh) lh.CREATOR.createFromParcel(data) : null, data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null, C0693a.bt(data.readStrongBinder()));
                    return true;
                case C0450R.styleable.WalletFragmentStyle_maskedWalletDetailsLogoTextColor /*9*/:
                    data.enforceInterface("com.google.android.gms.wallet.internal.IOwService");
                    m1348o(data.readInt() != 0 ? (Bundle) Bundle.CREATOR.createFromParcel(data) : null);
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.wallet.internal.IOwService");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void m1340a(Bundle bundle, lq lqVar) throws RemoteException;

    void m1341a(lh lhVar, Bundle bundle, lq lqVar) throws RemoteException;

    void m1342a(FullWalletRequest fullWalletRequest, Bundle bundle, lq lqVar) throws RemoteException;

    void m1343a(MaskedWalletRequest maskedWalletRequest, Bundle bundle, lp lpVar) throws RemoteException;

    void m1344a(MaskedWalletRequest maskedWalletRequest, Bundle bundle, lq lqVar) throws RemoteException;

    void m1345a(NotifyTransactionStatusRequest notifyTransactionStatusRequest, Bundle bundle) throws RemoteException;

    void m1346a(C0860d c0860d, Bundle bundle, lq lqVar) throws RemoteException;

    void m1347a(String str, String str2, Bundle bundle, lq lqVar) throws RemoteException;

    void m1348o(Bundle bundle) throws RemoteException;
}
