package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.Path;
import android.net.Uri;
import android.widget.ImageView;

public final class gw extends ImageView {
    private Uri FL;
    private int FM;
    private int FN;
    private C0241a FO;

    /* renamed from: com.google.android.gms.internal.gw.a */
    public interface C0241a {
        Path m1150d(int i, int i2);
    }

    public void al(int i) {
        this.FM = i;
    }

    public void m1151f(Uri uri) {
        this.FL = uri;
    }

    public int fd() {
        return this.FM;
    }

    protected void onDraw(Canvas canvas) {
        if (this.FO != null) {
            canvas.clipPath(this.FO.m1150d(getWidth(), getHeight()));
        }
        super.onDraw(canvas);
        if (this.FN != 0) {
            canvas.drawColor(this.FN);
        }
    }
}
