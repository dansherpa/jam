package com.google.android.gms.internal;

import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import com.google.android.gms.analytics.ecommerce.Promotion;
import java.util.Map;

public final class bi implements bd {
    private static int m2487a(DisplayMetrics displayMetrics, Map<String, String> map, String str, int i) {
        String str2 = (String) map.get(str);
        if (str2 != null) {
            try {
                i = eu.m1004a(displayMetrics, Integer.parseInt(str2));
            } catch (NumberFormatException e) {
                ev.m1013D("Could not parse " + str + " in a video GMSG: " + str2);
            }
        }
        return i;
    }

    public void m2488b(ey eyVar, Map<String, String> map) {
        String str = (String) map.get("action");
        if (str == null) {
            ev.m1013D("Action missing from video GMSG.");
            return;
        }
        cg bV = eyVar.bV();
        if (bV == null) {
            ev.m1013D("Could not get ad overlay for a video GMSG.");
            return;
        }
        boolean equalsIgnoreCase = "new".equalsIgnoreCase(str);
        boolean equalsIgnoreCase2 = "position".equalsIgnoreCase(str);
        int a;
        if (equalsIgnoreCase || equalsIgnoreCase2) {
            DisplayMetrics displayMetrics = eyVar.getContext().getResources().getDisplayMetrics();
            a = m2487a(displayMetrics, map, "x", 0);
            int a2 = m2487a(displayMetrics, map, "y", 0);
            int a3 = m2487a(displayMetrics, map, "w", -1);
            int a4 = m2487a(displayMetrics, map, "h", -1);
            if (equalsIgnoreCase && bV.aL() == null) {
                bV.m3549c(a, a2, a3, a4);
                return;
            } else {
                bV.m3548b(a, a2, a3, a4);
                return;
            }
        }
        ck aL = bV.aL();
        if (aL == null) {
            ck.m856a(eyVar, "no_video_view", null);
        } else if (Promotion.ACTION_CLICK.equalsIgnoreCase(str)) {
            displayMetrics = eyVar.getContext().getResources().getDisplayMetrics();
            int a5 = m2487a(displayMetrics, map, "x", 0);
            a = m2487a(displayMetrics, map, "y", 0);
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 0, (float) a5, (float) a, 0);
            aL.m859b(obtain);
            obtain.recycle();
        } else if ("controls".equalsIgnoreCase(str)) {
            str = (String) map.get("enabled");
            if (str == null) {
                ev.m1013D("Enabled parameter missing from controls video GMSG.");
            } else {
                aL.m860l(Boolean.parseBoolean(str));
            }
        } else if ("currentTime".equalsIgnoreCase(str)) {
            str = (String) map.get("time");
            if (str == null) {
                ev.m1013D("Time parameter missing from currentTime video GMSG.");
                return;
            }
            try {
                aL.seekTo((int) (Float.parseFloat(str) * 1000.0f));
            } catch (NumberFormatException e) {
                ev.m1013D("Could not parse time parameter from currentTime video GMSG: " + str);
            }
        } else if ("hide".equalsIgnoreCase(str)) {
            aL.setVisibility(4);
        } else if ("load".equalsIgnoreCase(str)) {
            aL.aV();
        } else if ("pause".equalsIgnoreCase(str)) {
            aL.pause();
        } else if ("play".equalsIgnoreCase(str)) {
            aL.play();
        } else if ("show".equalsIgnoreCase(str)) {
            aL.setVisibility(0);
        } else if ("src".equalsIgnoreCase(str)) {
            aL.m861o((String) map.get("src"));
        } else {
            ev.m1013D("Unknown video action: " + str);
        }
    }
}
