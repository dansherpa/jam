package com.google.android.gms.internal;

import android.text.TextUtils;
import android.util.Log;

public class go {
    private static boolean Ci;
    private boolean Cj;
    private boolean Ck;
    private String Cl;
    private final String mTag;

    static {
        Ci = false;
    }

    public go(String str) {
        this(str, en());
    }

    public go(String str, boolean z) {
        this.mTag = str;
        this.Cj = z;
        this.Ck = false;
    }

    private String m1130e(String str, Object... objArr) {
        String format = String.format(str, objArr);
        return !TextUtils.isEmpty(this.Cl) ? this.Cl + format : format;
    }

    public static boolean en() {
        return Ci;
    }

    public void m1131a(String str, Object... objArr) {
        if (em()) {
            Log.v(this.mTag, m1130e(str, objArr));
        }
    }

    public void m1132a(Throwable th, String str, Object... objArr) {
        if (el() || Ci) {
            Log.d(this.mTag, m1130e(str, objArr), th);
        }
    }

    public void ap(String str) {
        String str2;
        if (TextUtils.isEmpty(str)) {
            str2 = null;
        } else {
            str2 = String.format("[%s] ", new Object[]{str});
        }
        this.Cl = str2;
    }

    public void m1133b(String str, Object... objArr) {
        if (el() || Ci) {
            Log.d(this.mTag, m1130e(str, objArr));
        }
    }

    public void m1134c(String str, Object... objArr) {
        Log.i(this.mTag, m1130e(str, objArr));
    }

    public void m1135d(String str, Object... objArr) {
        Log.w(this.mTag, m1130e(str, objArr));
    }

    public boolean el() {
        return this.Cj;
    }

    public boolean em() {
        return this.Ck;
    }
}
