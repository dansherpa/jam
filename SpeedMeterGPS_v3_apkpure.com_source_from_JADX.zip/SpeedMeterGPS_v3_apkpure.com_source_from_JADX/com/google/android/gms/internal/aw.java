package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.doubleclick.AppEventListener;
import com.google.android.gms.ads.purchase.InAppPurchaseListener;
import com.google.android.gms.ads.purchase.PlayStorePurchaseListener;

public final class aw {
    private AdListener lO;
    private PlayStorePurchaseListener mA;
    private final Context mContext;
    private AppEventListener mf;
    private String mh;
    private final bt mu;
    private final al mv;
    private ar mw;
    private String mx;
    private InAppPurchaseListener mz;

    public aw(Context context) {
        this(context, al.aA());
    }

    public aw(Context context, al alVar) {
        this.mu = new bt();
        this.mContext = context;
        this.mv = alVar;
    }

    private void m817k(String str) throws RemoteException {
        if (this.mh == null) {
            m818l(str);
        }
        this.mw = ai.m2454a(this.mContext, new am(), this.mh, this.mu);
        if (this.lO != null) {
            this.mw.m786a(new ah(this.lO));
        }
        if (this.mf != null) {
            this.mw.m787a(new ao(this.mf));
        }
        if (this.mz != null) {
            this.mw.m788a(new di(this.mz));
        }
        if (this.mA != null) {
            this.mw.m789a(new dm(this.mA), this.mx);
        }
    }

    private void m818l(String str) {
        if (this.mw == null) {
            throw new IllegalStateException("The ad unit ID must be set on InterstitialAd before " + str + " is called.");
        }
    }

    public void m819a(au auVar) {
        try {
            if (this.mw == null) {
                m817k("loadAd");
            }
            if (this.mw.m790a(this.mv.m777a(this.mContext, auVar))) {
                this.mu.m3474c(auVar.aD());
            }
        } catch (Throwable e) {
            ev.m1016c("Failed to load ad.", e);
        }
    }

    public AdListener getAdListener() {
        return this.lO;
    }

    public String getAdUnitId() {
        return this.mh;
    }

    public AppEventListener getAppEventListener() {
        return this.mf;
    }

    public InAppPurchaseListener getInAppPurchaseListener() {
        return this.mz;
    }

    public boolean isLoaded() {
        boolean z = false;
        try {
            if (this.mw != null) {
                z = this.mw.isReady();
            }
        } catch (Throwable e) {
            ev.m1016c("Failed to check if ad is ready.", e);
        }
        return z;
    }

    public void setAdListener(AdListener adListener) {
        try {
            this.lO = adListener;
            if (this.mw != null) {
                this.mw.m786a(adListener != null ? new ah(adListener) : null);
            }
        } catch (Throwable e) {
            ev.m1016c("Failed to set the AdListener.", e);
        }
    }

    public void setAdUnitId(String adUnitId) {
        if (this.mh != null) {
            throw new IllegalStateException("The ad unit ID can only be set once on InterstitialAd.");
        }
        this.mh = adUnitId;
    }

    public void setAppEventListener(AppEventListener appEventListener) {
        try {
            this.mf = appEventListener;
            if (this.mw != null) {
                this.mw.m787a(appEventListener != null ? new ao(appEventListener) : null);
            }
        } catch (Throwable e) {
            ev.m1016c("Failed to set the AppEventListener.", e);
        }
    }

    public void setInAppPurchaseListener(InAppPurchaseListener inAppPurchaseListener) {
        if (this.mA != null) {
            throw new IllegalStateException("Play store purchase parameter has already been set.");
        }
        try {
            this.mz = inAppPurchaseListener;
            if (this.mw != null) {
                this.mw.m788a(inAppPurchaseListener != null ? new di(inAppPurchaseListener) : null);
            }
        } catch (Throwable e) {
            ev.m1016c("Failed to set the InAppPurchaseListener.", e);
        }
    }

    public void setPlayStorePurchaseParams(PlayStorePurchaseListener playStorePurchaseListener, String publicKey) {
        try {
            this.mA = playStorePurchaseListener;
            if (this.mw != null) {
                this.mw.m789a(playStorePurchaseListener != null ? new dm(playStorePurchaseListener) : null, publicKey);
            }
        } catch (Throwable e) {
            ev.m1016c("Failed to set the play store purchase parameter.", e);
        }
    }

    public void show() {
        try {
            m818l("show");
            this.mw.showInterstitial();
        } catch (Throwable e) {
            ev.m1016c("Failed to show interstitial.", e);
        }
    }
}
