package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.Cast;
import com.google.android.gms.cast.Cast.ApplicationConnectionResult;
import com.google.android.gms.cast.Cast.Listener;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.CastStatusCodes;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.gm.C0642a;
import com.google.android.gms.internal.gn.C0643a;
import com.google.android.gms.internal.hc.C0993e;
import com.google.android.gms.location.GeofenceStatusCodes;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class gi extends hc<gm> {
    private static final go BD;
    private static final Object BX;
    private static final Object BY;
    private double AM;
    private boolean AN;
    private final Listener Ab;
    private ApplicationMetadata BE;
    private final CastDevice BF;
    private final gn BG;
    private final Map<String, MessageReceivedCallback> BH;
    private final long BI;
    private String BJ;
    private boolean BK;
    private boolean BL;
    private boolean BM;
    private AtomicBoolean BN;
    private int BO;
    private final AtomicLong BP;
    private String BQ;
    private String BR;
    private Bundle BS;
    private Map<Long, C0052d<Status>> BT;
    private C0992b BU;
    private C0052d<ApplicationConnectionResult> BV;
    private C0052d<Status> BW;
    private final Handler mHandler;

    /* renamed from: com.google.android.gms.internal.gi.1 */
    class C09901 extends C0643a {
        final /* synthetic */ gi BZ;

        /* renamed from: com.google.android.gms.internal.gi.1.1 */
        class C02311 implements Runnable {
            final /* synthetic */ int Ca;
            final /* synthetic */ C09901 Cb;

            C02311(C09901 c09901, int i) {
                this.Cb = c09901;
                this.Ca = i;
            }

            public void run() {
                if (this.Cb.BZ.Ab != null) {
                    this.Cb.BZ.Ab.onApplicationDisconnected(this.Ca);
                }
            }
        }

        /* renamed from: com.google.android.gms.internal.gi.1.2 */
        class C02322 implements Runnable {
            final /* synthetic */ C09901 Cb;
            final /* synthetic */ gk Cc;

            C02322(C09901 c09901, gk gkVar) {
                this.Cb = c09901;
                this.Cc = gkVar;
            }

            public void run() {
                this.Cb.BZ.m3613a(this.Cc);
            }
        }

        /* renamed from: com.google.android.gms.internal.gi.1.3 */
        class C02333 implements Runnable {
            final /* synthetic */ C09901 Cb;
            final /* synthetic */ gf Cd;

            C02333(C09901 c09901, gf gfVar) {
                this.Cb = c09901;
                this.Cd = gfVar;
            }

            public void run() {
                this.Cb.BZ.m3610a(this.Cd);
            }
        }

        /* renamed from: com.google.android.gms.internal.gi.1.4 */
        class C02344 implements Runnable {
            final /* synthetic */ C09901 Cb;
            final /* synthetic */ String Ce;
            final /* synthetic */ String zR;

            C02344(C09901 c09901, String str, String str2) {
                this.Cb = c09901;
                this.zR = str;
                this.Ce = str2;
            }

            public void run() {
                synchronized (this.Cb.BZ.BH) {
                    MessageReceivedCallback messageReceivedCallback = (MessageReceivedCallback) this.Cb.BZ.BH.get(this.zR);
                }
                if (messageReceivedCallback != null) {
                    messageReceivedCallback.onMessageReceived(this.Cb.BZ.BF, this.zR, this.Ce);
                    return;
                }
                gi.BD.m1133b("Discarded message for unknown namespace '%s'", this.zR);
            }
        }

        C09901(gi giVar) {
            this.BZ = giVar;
        }

        private boolean m3593X(int i) {
            synchronized (gi.BY) {
                if (this.BZ.BW != null) {
                    this.BZ.BW.m147a(new Status(i));
                    this.BZ.BW = null;
                    return true;
                }
                return false;
            }
        }

        private void m3594b(long j, int i) {
            synchronized (this.BZ.BT) {
                C0052d c0052d = (C0052d) this.BZ.BT.remove(Long.valueOf(j));
            }
            if (c0052d != null) {
                c0052d.m147a(new Status(i));
            }
        }

        public void m3595T(int i) {
            gi.BD.m1133b("ICastDeviceControllerListener.onDisconnected: %d", Integer.valueOf(i));
            this.BZ.BM = false;
            this.BZ.BN.set(false);
            this.BZ.BE = null;
            if (i != 0) {
                this.BZ.an(2);
            }
        }

        public void m3596U(int i) {
            synchronized (gi.BX) {
                if (this.BZ.BV != null) {
                    this.BZ.BV.m147a(new C0991a(new Status(i)));
                    this.BZ.BV = null;
                }
            }
        }

        public void m3597V(int i) {
            m3593X(i);
        }

        public void m3598W(int i) {
            m3593X(i);
        }

        public void m3599a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
            this.BZ.BE = applicationMetadata;
            this.BZ.BQ = applicationMetadata.getApplicationId();
            this.BZ.BR = str2;
            synchronized (gi.BX) {
                if (this.BZ.BV != null) {
                    this.BZ.BV.m147a(new C0991a(new Status(0), applicationMetadata, str, str2, z));
                    this.BZ.BV = null;
                }
            }
        }

        public void m3600a(String str, double d, boolean z) {
            gi.BD.m1133b("Deprecated callback: \"onStatusreceived\"", new Object[0]);
        }

        public void m3601a(String str, long j) {
            m3594b(j, 0);
        }

        public void m3602a(String str, long j, int i) {
            m3594b(j, i);
        }

        public void m3603b(gf gfVar) {
            gi.BD.m1133b("onApplicationStatusChanged", new Object[0]);
            this.BZ.mHandler.post(new C02333(this, gfVar));
        }

        public void m3604b(gk gkVar) {
            gi.BD.m1133b("onDeviceStatusChanged", new Object[0]);
            this.BZ.mHandler.post(new C02322(this, gkVar));
        }

        public void m3605b(String str, byte[] bArr) {
            gi.BD.m1133b("IGNORING: Receive (type=binary, ns=%s) <%d bytes>", str, Integer.valueOf(bArr.length));
        }

        public void m3606g(String str, String str2) {
            gi.BD.m1133b("Receive (type=text, ns=%s) %s", str, str2);
            this.BZ.mHandler.post(new C02344(this, str, str2));
        }

        public void onApplicationDisconnected(int statusCode) {
            this.BZ.BQ = null;
            this.BZ.BR = null;
            m3593X(statusCode);
            if (this.BZ.Ab != null) {
                this.BZ.mHandler.post(new C02311(this, statusCode));
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.gi.a */
    private static final class C0991a implements ApplicationConnectionResult {
        private final ApplicationMetadata Cf;
        private final String Cg;
        private final boolean Ch;
        private final String rO;
        private final Status yw;

        public C0991a(Status status) {
            this(status, null, null, null, false);
        }

        public C0991a(Status status, ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
            this.yw = status;
            this.Cf = applicationMetadata;
            this.Cg = str;
            this.rO = str2;
            this.Ch = z;
        }

        public ApplicationMetadata getApplicationMetadata() {
            return this.Cf;
        }

        public String getApplicationStatus() {
            return this.Cg;
        }

        public String getSessionId() {
            return this.rO;
        }

        public Status getStatus() {
            return this.yw;
        }

        public boolean getWasLaunched() {
            return this.Ch;
        }
    }

    /* renamed from: com.google.android.gms.internal.gi.b */
    private class C0992b implements OnConnectionFailedListener {
        final /* synthetic */ gi BZ;

        private C0992b(gi giVar) {
            this.BZ = giVar;
        }

        public void onConnectionFailed(ConnectionResult result) {
            this.BZ.ed();
        }
    }

    static {
        BD = new go("CastClientImpl");
        BX = new Object();
        BY = new Object();
    }

    public gi(Context context, Looper looper, CastDevice castDevice, long j, Listener listener, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, (String[]) null);
        this.BF = castDevice;
        this.Ab = listener;
        this.BI = j;
        this.mHandler = new Handler(looper);
        this.BH = new HashMap();
        this.BM = false;
        this.BO = -1;
        this.BE = null;
        this.BJ = null;
        this.BN = new AtomicBoolean(false);
        this.AM = 0.0d;
        this.AN = false;
        this.BP = new AtomicLong(0);
        this.BT = new HashMap();
        this.BU = new C0992b();
        registerConnectionFailedListener(this.BU);
        this.BG = new C09901(this);
    }

    private void m3610a(gf gfVar) {
        boolean z;
        String dX = gfVar.dX();
        if (gj.m1104a(dX, this.BJ)) {
            z = false;
        } else {
            this.BJ = dX;
            z = true;
        }
        BD.m1133b("hasChanged=%b, mFirstApplicationStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.BK));
        if (this.Ab != null && (z || this.BK)) {
            this.Ab.onApplicationStatusChanged();
        }
        this.BK = false;
    }

    private void m3613a(gk gkVar) {
        boolean z;
        double ec = gkVar.ec();
        if (ec == Double.NaN || ec == this.AM) {
            z = false;
        } else {
            this.AM = ec;
            z = true;
        }
        boolean ei = gkVar.ei();
        if (ei != this.AN) {
            this.AN = ei;
            z = true;
        }
        BD.m1133b("hasVolumeChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.BL));
        if (this.Ab != null && (z || this.BL)) {
            this.Ab.onVolumeChanged();
        }
        int ej = gkVar.ej();
        if (ej != this.BO) {
            this.BO = ej;
            z = true;
        } else {
            z = false;
        }
        BD.m1133b("hasActiveInputChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.BL));
        if (this.Ab != null && (z || this.BL)) {
            this.Ab.m90O(this.BO);
        }
        this.BL = false;
    }

    private void m3619c(C0052d<ApplicationConnectionResult> c0052d) {
        synchronized (BX) {
            if (this.BV != null) {
                this.BV.m147a(new C0991a(new Status(CastStatusCodes.CANCELED)));
            }
            this.BV = c0052d;
        }
    }

    private void m3622e(C0052d<Status> c0052d) {
        synchronized (BY) {
            if (this.BW != null) {
                c0052d.m147a(new Status(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE));
                return;
            }
            this.BW = c0052d;
        }
    }

    private void ed() {
        BD.m1133b("removing all MessageReceivedCallbacks", new Object[0]);
        synchronized (this.BH) {
            this.BH.clear();
        }
    }

    private void ee() throws IllegalStateException {
        if (!this.BM || this.BN.get()) {
            throw new IllegalStateException("Not connected to a device");
        }
    }

    protected gm m3628G(IBinder iBinder) {
        return C0642a.m2621H(iBinder);
    }

    public void m3629a(double d) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            throw new IllegalArgumentException("Volume cannot be " + d);
        }
        ((gm) fo()).m1111a(d, this.AM, this.AN);
    }

    protected void m3630a(int i, IBinder iBinder, Bundle bundle) {
        BD.m1133b("in onPostInitHandler; statusCode=%d", Integer.valueOf(i));
        if (i == 0 || i == GeofenceStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES) {
            this.BM = true;
            this.BK = true;
            this.BL = true;
        } else {
            this.BM = false;
        }
        if (i == GeofenceStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES) {
            this.BS = new Bundle();
            this.BS.putBoolean(Cast.EXTRA_APP_NO_LONGER_RUNNING, true);
            i = 0;
        }
        super.m2652a(i, iBinder, bundle);
    }

    protected void m3631a(hj hjVar, C0993e c0993e) throws RemoteException {
        Bundle bundle = new Bundle();
        BD.m1133b("getServiceFromBroker(): mLastApplicationId=%s, mLastSessionId=%s", this.BQ, this.BR);
        this.BF.putInBundle(bundle);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.BI);
        if (this.BQ != null) {
            bundle.putString("last_application_id", this.BQ);
            if (this.BR != null) {
                bundle.putString("last_session_id", this.BR);
            }
        }
        hjVar.m1185a((hi) c0993e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.BG.asBinder(), bundle);
    }

    public void m3632a(String str, MessageReceivedCallback messageReceivedCallback) throws IllegalArgumentException, IllegalStateException, RemoteException {
        gj.ak(str);
        aj(str);
        if (messageReceivedCallback != null) {
            synchronized (this.BH) {
                this.BH.put(str, messageReceivedCallback);
            }
            ((gm) fo()).an(str);
        }
    }

    public void m3633a(String str, LaunchOptions launchOptions, C0052d<ApplicationConnectionResult> c0052d) throws IllegalStateException, RemoteException {
        m3619c((C0052d) c0052d);
        ((gm) fo()).m1112a(str, launchOptions);
    }

    public void m3634a(String str, C0052d<Status> c0052d) throws IllegalStateException, RemoteException {
        m3622e((C0052d) c0052d);
        ((gm) fo()).am(str);
    }

    public void m3635a(String str, String str2, C0052d<Status> c0052d) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (TextUtils.isEmpty(str2)) {
            throw new IllegalArgumentException("The message payload cannot be null or empty");
        } else if (str2.length() > Cast.MAX_MESSAGE_LENGTH) {
            throw new IllegalArgumentException("Message exceeds maximum size");
        } else {
            gj.ak(str);
            ee();
            long incrementAndGet = this.BP.incrementAndGet();
            ((gm) fo()).m1113a(str, str2, incrementAndGet);
            this.BT.put(Long.valueOf(incrementAndGet), c0052d);
        }
    }

    public void m3636a(String str, boolean z, C0052d<ApplicationConnectionResult> c0052d) throws IllegalStateException, RemoteException {
        m3619c((C0052d) c0052d);
        ((gm) fo()).m1116e(str, z);
    }

    public void aj(String str) throws IllegalArgumentException, RemoteException {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Channel namespace cannot be null or empty");
        }
        synchronized (this.BH) {
            MessageReceivedCallback messageReceivedCallback = (MessageReceivedCallback) this.BH.remove(str);
        }
        if (messageReceivedCallback != null) {
            try {
                ((gm) fo()).ao(str);
            } catch (Throwable e) {
                BD.m1132a(e, "Error unregistering namespace (%s): %s", str, e.getMessage());
            }
        }
    }

    public void m3637b(String str, String str2, C0052d<ApplicationConnectionResult> c0052d) throws IllegalStateException, RemoteException {
        m3619c((C0052d) c0052d);
        ((gm) fo()).m1117h(str, str2);
    }

    protected String bp() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }

    protected String bq() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    public void m3638d(C0052d<Status> c0052d) throws IllegalStateException, RemoteException {
        m3622e((C0052d) c0052d);
        ((gm) fo()).ek();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void disconnect() {
        /*
        r6 = this;
        r5 = 1;
        r4 = 0;
        r0 = BD;
        r1 = "disconnect(); mDisconnecting=%b, isConnected=%b";
        r2 = 2;
        r2 = new java.lang.Object[r2];
        r3 = r6.BN;
        r3 = r3.get();
        r3 = java.lang.Boolean.valueOf(r3);
        r2[r4] = r3;
        r3 = r6.isConnected();
        r3 = java.lang.Boolean.valueOf(r3);
        r2[r5] = r3;
        r0.m1133b(r1, r2);
        r0 = r6.BN;
        r0 = r0.getAndSet(r5);
        if (r0 == 0) goto L_0x0034;
    L_0x002a:
        r0 = BD;
        r1 = "mDisconnecting is set, so short-circuiting";
        r2 = new java.lang.Object[r4];
        r0.m1133b(r1, r2);
    L_0x0033:
        return;
    L_0x0034:
        r6.ed();
        r0 = r6.isConnected();	 Catch:{ RemoteException -> 0x0050 }
        if (r0 != 0) goto L_0x0043;
    L_0x003d:
        r0 = r6.isConnecting();	 Catch:{ RemoteException -> 0x0050 }
        if (r0 == 0) goto L_0x004c;
    L_0x0043:
        r0 = r6.fo();	 Catch:{ RemoteException -> 0x0050 }
        r0 = (com.google.android.gms.internal.gm) r0;	 Catch:{ RemoteException -> 0x0050 }
        r0.disconnect();	 Catch:{ RemoteException -> 0x0050 }
    L_0x004c:
        super.disconnect();
        goto L_0x0033;
    L_0x0050:
        r0 = move-exception;
        r1 = BD;	 Catch:{ all -> 0x0066 }
        r2 = "Error while disconnecting the controller interface: %s";
        r3 = 1;
        r3 = new java.lang.Object[r3];	 Catch:{ all -> 0x0066 }
        r4 = 0;
        r5 = r0.getMessage();	 Catch:{ all -> 0x0066 }
        r3[r4] = r5;	 Catch:{ all -> 0x0066 }
        r1.m1132a(r0, r2, r3);	 Catch:{ all -> 0x0066 }
        super.disconnect();
        goto L_0x0033;
    L_0x0066:
        r0 = move-exception;
        super.disconnect();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.gi.disconnect():void");
    }

    public Bundle ea() {
        if (this.BS == null) {
            return super.ea();
        }
        Bundle bundle = this.BS;
        this.BS = null;
        return bundle;
    }

    public void eb() throws IllegalStateException, RemoteException {
        ((gm) fo()).eb();
    }

    public double ec() throws IllegalStateException {
        ee();
        return this.AM;
    }

    public ApplicationMetadata getApplicationMetadata() throws IllegalStateException {
        ee();
        return this.BE;
    }

    public String getApplicationStatus() throws IllegalStateException {
        ee();
        return this.BJ;
    }

    public boolean isMute() throws IllegalStateException {
        ee();
        return this.AN;
    }

    protected /* synthetic */ IInterface m3639x(IBinder iBinder) {
        return m3628G(iBinder);
    }

    public void m3640y(boolean z) throws IllegalStateException, RemoteException {
        ((gm) fo()).m1115a(z, this.AM, this.AN);
    }
}
