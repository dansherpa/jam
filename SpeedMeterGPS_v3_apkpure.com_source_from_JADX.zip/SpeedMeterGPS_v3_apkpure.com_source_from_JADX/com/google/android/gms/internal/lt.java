package com.google.android.gms.internal;

import android.app.Activity;
import android.os.IBinder;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.C0151c;
import com.google.android.gms.dynamic.C0155g;
import com.google.android.gms.dynamic.C0931e;
import com.google.android.gms.internal.lo.C0689a;
import com.google.android.gms.wallet.fragment.WalletFragmentOptions;

public class lt extends C0155g<lo> {
    private static lt akK;

    protected lt() {
        super("com.google.android.gms.wallet.dynamite.WalletDynamiteCreatorImpl");
    }

    public static ll m2811a(Activity activity, C0151c c0151c, WalletFragmentOptions walletFragmentOptions, lm lmVar) throws GooglePlayServicesNotAvailableException {
        int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(activity);
        if (isGooglePlayServicesAvailable != 0) {
            throw new GooglePlayServicesNotAvailableException(isGooglePlayServicesAvailable);
        }
        try {
            return ((lo) ne().m462D(activity)).m1349a(C0931e.m3242h(activity), c0151c, walletFragmentOptions, lmVar);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        } catch (Throwable e2) {
            throw new RuntimeException(e2);
        }
    }

    private static lt ne() {
        if (akK == null) {
            akK = new lt();
        }
        return akK;
    }

    protected lo bv(IBinder iBinder) {
        return C0689a.br(iBinder);
    }

    protected /* synthetic */ Object m2812d(IBinder iBinder) {
        return bv(iBinder);
    }
}
