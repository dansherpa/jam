package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import com.google.android.gms.ads.AdActivity;

public class ej {
    private final Object lq;
    private final String rO;
    private int rU;
    private long rV;
    private long rW;
    private int rX;
    private int rY;

    public ej(String str) {
        this.lq = new Object();
        this.rU = 0;
        this.rV = -1;
        this.rW = -1;
        this.rX = 0;
        this.rY = -1;
        this.rO = str;
    }

    public static boolean m960i(Context context) {
        int identifier = context.getResources().getIdentifier("Theme.Translucent", "style", "android");
        if (identifier == 0) {
            ev.m1011B("Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad.");
            return false;
        }
        try {
            if (identifier == context.getPackageManager().getActivityInfo(new ComponentName(context.getPackageName(), AdActivity.CLASS_NAME), 0).theme) {
                return true;
            }
            ev.m1011B("Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad.");
            return false;
        } catch (NameNotFoundException e) {
            ev.m1013D("Fail to fetch AdActivity theme");
            ev.m1011B("Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad.");
            return false;
        }
    }

    public Bundle m961b(Context context, String str) {
        Bundle bundle;
        synchronized (this.lq) {
            bundle = new Bundle();
            bundle.putString("session_id", this.rO);
            bundle.putLong("basets", this.rW);
            bundle.putLong("currts", this.rV);
            bundle.putString("seq_num", str);
            bundle.putInt("preqs", this.rY);
            bundle.putInt("pclick", this.rU);
            bundle.putInt("pimp", this.rX);
            bundle.putBoolean("support_transparent_background", m960i(context));
        }
        return bundle;
    }

    public void m962b(aj ajVar, long j) {
        synchronized (this.lq) {
            if (this.rW == -1) {
                this.rW = j;
                this.rV = this.rW;
            } else {
                this.rV = j;
            }
            if (ajVar.extras == null || ajVar.extras.getInt("gw", 2) != 1) {
                this.rY++;
                return;
            }
        }
    }

    public long bJ() {
        return this.rW;
    }

    public void bw() {
        synchronized (this.lq) {
            this.rX++;
        }
    }

    public void bx() {
        synchronized (this.lq) {
            this.rU++;
        }
    }
}
