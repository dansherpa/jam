package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.hz.C0253b;

public class hu implements SafeParcelable {
    public static final hv CREATOR;
    private final hw GS;
    private final int xJ;

    static {
        CREATOR = new hv();
    }

    hu(int i, hw hwVar) {
        this.xJ = i;
        this.GS = hwVar;
    }

    private hu(hw hwVar) {
        this.xJ = 1;
        this.GS = hwVar;
    }

    public static hu m2702a(C0253b<?, ?> c0253b) {
        if (c0253b instanceof hw) {
            return new hu((hw) c0253b);
        }
        throw new IllegalArgumentException("Unsupported safe parcelable field converter class.");
    }

    public int describeContents() {
        hv hvVar = CREATOR;
        return 0;
    }

    hw fw() {
        return this.GS;
    }

    public C0253b<?, ?> fx() {
        if (this.GS != null) {
            return this.GS;
        }
        throw new IllegalStateException("There was no converter wrapped in this ConverterWrapper.");
    }

    int getVersionCode() {
        return this.xJ;
    }

    public void writeToParcel(Parcel out, int flags) {
        hv hvVar = CREATOR;
        hv.m1240a(this, out, flags);
    }
}
