package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;

public final class ac implements ae {
    private final Object lq;
    private WeakHashMap<eg, ad> lr;
    private ArrayList<ad> ls;

    public ac() {
        this.lq = new Object();
        this.lr = new WeakHashMap();
        this.ls = new ArrayList();
    }

    public ad m2441a(am amVar, eg egVar) {
        ad adVar;
        synchronized (this.lq) {
            if (m2443c(egVar)) {
                adVar = (ad) this.lr.get(egVar);
            } else {
                adVar = new ad(amVar, egVar);
                adVar.m758a((ae) this);
                this.lr.put(egVar, adVar);
                this.ls.add(adVar);
            }
        }
        return adVar;
    }

    public void m2442a(ad adVar) {
        synchronized (this.lq) {
            if (!adVar.au()) {
                this.ls.remove(adVar);
            }
        }
    }

    public boolean m2443c(eg egVar) {
        boolean z;
        synchronized (this.lq) {
            ad adVar = (ad) this.lr.get(egVar);
            z = adVar != null && adVar.au();
        }
        return z;
    }

    public void m2444d(eg egVar) {
        synchronized (this.lq) {
            ad adVar = (ad) this.lr.get(egVar);
            if (adVar != null) {
                adVar.as();
            }
        }
    }

    public void pause() {
        synchronized (this.lq) {
            Iterator it = this.ls.iterator();
            while (it.hasNext()) {
                ((ad) it.next()).pause();
            }
        }
    }

    public void resume() {
        synchronized (this.lq) {
            Iterator it = this.ls.iterator();
            while (it.hasNext()) {
                ((ad) it.next()).resume();
            }
        }
    }

    public void stop() {
        synchronized (this.lq) {
            Iterator it = this.ls.iterator();
            while (it.hasNext()) {
                ((ad) it.next()).stop();
            }
        }
    }
}
