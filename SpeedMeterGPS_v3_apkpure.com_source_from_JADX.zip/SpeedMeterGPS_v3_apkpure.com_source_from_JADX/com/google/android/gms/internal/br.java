package com.google.android.gms.internal;

public final class br {
    public final int nJ;
    public final bm nK;
    public final bv nL;
    public final String nM;
    public final bp nN;

    /* renamed from: com.google.android.gms.internal.br.a */
    public interface C0175a {
        void m833g(int i);
    }

    public br(int i) {
        this(null, null, null, null, i);
    }

    public br(bm bmVar, bv bvVar, String str, bp bpVar, int i) {
        this.nK = bmVar;
        this.nL = bvVar;
        this.nM = str;
        this.nN = bpVar;
        this.nJ = i;
    }
}
