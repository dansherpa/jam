package com.google.android.gms.internal;

public interface ee {
    String m948u(String str);
}
