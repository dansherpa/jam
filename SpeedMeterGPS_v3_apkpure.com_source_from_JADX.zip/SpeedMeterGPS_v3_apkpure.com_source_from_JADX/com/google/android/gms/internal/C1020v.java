package com.google.android.gms.internal;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.widget.ViewSwitcher;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.C0152d;
import com.google.android.gms.dynamic.C0931e;
import com.google.android.gms.internal.ar.C0573a;
import com.google.android.gms.internal.dn.C0197a;
import com.google.android.gms.internal.dt.C0205a;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

/* renamed from: com.google.android.gms.internal.v */
public class C1020v extends C0573a implements bb, be, bg, bo, cj, cm, C0197a, ek, C0271u {
    private final C0274c kA;
    private final C0278z kB;
    private final ac kC;
    private boolean kD;
    private final ComponentCallbacks kE;
    private final bu kz;

    /* renamed from: com.google.android.gms.internal.v.1 */
    class C02721 implements ComponentCallbacks {
        final /* synthetic */ C1020v kF;

        C02721(C1020v c1020v) {
            this.kF = c1020v;
        }

        public void onConfigurationChanged(Configuration newConfig) {
            if (this.kF.kA != null && this.kF.kA.kS != null && this.kF.kA.kS.ow != null) {
                this.kF.kA.kS.ow.bS();
            }
        }

        public void onLowMemory() {
        }
    }

    /* renamed from: com.google.android.gms.internal.v.a */
    private static final class C0273a extends ViewSwitcher {
        private final eq kG;

        public C0273a(Context context) {
            super(context);
            this.kG = new eq(context);
        }

        public boolean onInterceptTouchEvent(MotionEvent event) {
            this.kG.m994c(event);
            return false;
        }
    }

    /* renamed from: com.google.android.gms.internal.v.c */
    private static final class C0274c {
        public final C0273a kK;
        public final String kL;
        public final Context kM;
        public final C0259l kN;
        public final ew kO;
        public aq kP;
        public en kQ;
        public am kR;
        public eg kS;
        public eh kT;
        public at kU;
        public dh kV;
        public dd kW;
        public da kX;
        public el kY;
        public boolean kZ;
        private HashSet<eh> la;

        public C0274c(Context context, am amVar, String str, ew ewVar) {
            this.kY = null;
            this.kZ = false;
            this.la = null;
            if (amVar.md) {
                this.kK = null;
            } else {
                this.kK = new C0273a(context);
                this.kK.setMinimumWidth(amVar.widthPixels);
                this.kK.setMinimumHeight(amVar.heightPixels);
                this.kK.setVisibility(4);
            }
            this.kR = amVar;
            this.kL = str;
            this.kM = context;
            this.kO = ewVar;
            this.kN = new C0259l(new C0699b(this));
        }

        public void m1458a(HashSet<eh> hashSet) {
            this.la = hashSet;
        }

        public HashSet<eh> al() {
            return this.la;
        }
    }

    /* renamed from: com.google.android.gms.internal.v.b */
    private static final class C0699b implements C0243h, Runnable {
        private C0274c kA;
        private final List<Object[]> kH;
        private final CountDownLatch kI;
        private final AtomicReference<C0243h> kJ;

        public C0699b(C0274c c0274c) {
            this.kH = new Vector();
            this.kI = new CountDownLatch(1);
            this.kJ = new AtomicReference();
            this.kA = c0274c;
            if (eu.bR()) {
                eo.execute(this);
            } else {
                run();
            }
        }

        private void aj() {
            try {
                this.kI.await();
            } catch (Throwable e) {
                ev.m1016c("Interrupted during GADSignals creation.", e);
            }
        }

        private void ak() {
            if (!this.kH.isEmpty()) {
                for (Object[] objArr : this.kH) {
                    if (objArr.length == 1) {
                        ((C0243h) this.kJ.get()).m1158a((MotionEvent) objArr[0]);
                    } else if (objArr.length == 3) {
                        ((C0243h) this.kJ.get()).m1157a(((Integer) objArr[0]).intValue(), ((Integer) objArr[1]).intValue(), ((Integer) objArr[2]).intValue());
                    }
                }
            }
        }

        public String m2827a(Context context) {
            aj();
            ak();
            return ((C0243h) this.kJ.get()).m1155a(context);
        }

        public String m2828a(Context context, String str) {
            aj();
            ak();
            return ((C0243h) this.kJ.get()).m1156a(context, str);
        }

        public void m2829a(int i, int i2, int i3) {
            C0243h c0243h = (C0243h) this.kJ.get();
            if (c0243h != null) {
                ak();
                c0243h.m1157a(i, i2, i3);
                return;
            }
            this.kH.add(new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)});
        }

        public void m2830a(MotionEvent motionEvent) {
            C0243h c0243h = (C0243h) this.kJ.get();
            if (c0243h != null) {
                ak();
                c0243h.m1158a(motionEvent);
                return;
            }
            this.kH.add(new Object[]{motionEvent});
        }

        public void run() {
            try {
                this.kJ.set(C1091k.m4057a(this.kA.kO.st, this.kA.kM));
            } finally {
                this.kI.countDown();
                this.kA = null;
            }
        }
    }

    public C1020v(Context context, am amVar, String str, bu buVar, ew ewVar) {
        this.kE = new C02721(this);
        this.kA = new C0274c(context, amVar, str, ewVar);
        this.kz = buVar;
        this.kB = new C0278z(this);
        this.kC = new ac();
        ep.m984k(context);
        m3735R();
    }

    private void m3735R() {
        if (VERSION.SDK_INT >= 14 && this.kA != null && this.kA.kM != null) {
            this.kA.kM.registerComponentCallbacks(this.kE);
        }
    }

    private void m3736S() {
        if (VERSION.SDK_INT >= 14 && this.kA != null && this.kA.kM != null) {
            this.kA.kM.unregisterComponentCallbacks(this.kE);
        }
    }

    private void m3738a(int i) {
        ev.m1013D("Failed to load ad: " + i);
        if (this.kA.kP != null) {
            try {
                this.kA.kP.onAdFailedToLoad(i);
            } catch (Throwable e) {
                ev.m1016c("Could not call AdListener.onAdFailedToLoad().", e);
            }
        }
    }

    private void ac() {
        ev.m1011B("Ad closing.");
        if (this.kA.kP != null) {
            try {
                this.kA.kP.onAdClosed();
            } catch (Throwable e) {
                ev.m1016c("Could not call AdListener.onAdClosed().", e);
            }
        }
    }

    private void ad() {
        ev.m1011B("Ad leaving application.");
        if (this.kA.kP != null) {
            try {
                this.kA.kP.onAdLeftApplication();
            } catch (Throwable e) {
                ev.m1016c("Could not call AdListener.onAdLeftApplication().", e);
            }
        }
    }

    private void ae() {
        ev.m1011B("Ad opening.");
        if (this.kA.kP != null) {
            try {
                this.kA.kP.onAdOpened();
            } catch (Throwable e) {
                ev.m1016c("Could not call AdListener.onAdOpened().", e);
            }
        }
    }

    private void af() {
        ev.m1011B("Ad finished loading.");
        if (this.kA.kP != null) {
            try {
                this.kA.kP.onAdLoaded();
            } catch (Throwable e) {
                ev.m1016c("Could not call AdListener.onAdLoaded().", e);
            }
        }
    }

    private boolean ag() {
        boolean z = true;
        if (!ep.m977a(this.kA.kM.getPackageManager(), this.kA.kM.getPackageName(), "android.permission.INTERNET")) {
            if (!this.kA.kR.md) {
                eu.m1007a(this.kA.kK, this.kA.kR, "Missing internet permission in AndroidManifest.xml.", "Missing internet permission in AndroidManifest.xml. You must have the following declaration: <uses-permission android:name=\"android.permission.INTERNET\" />");
            }
            z = false;
        }
        if (!ep.m983j(this.kA.kM)) {
            if (!this.kA.kR.md) {
                eu.m1007a(this.kA.kK, this.kA.kR, "Missing AdActivity with android:configChanges in AndroidManifest.xml.", "Missing AdActivity with android:configChanges in AndroidManifest.xml. You must have the following declaration within the <application> element: <activity android:name=\"com.google.android.gms.ads.AdActivity\" android:configChanges=\"keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize\" />");
            }
            z = false;
        }
        if (!(z || this.kA.kR.md)) {
            this.kA.kK.setVisibility(0);
        }
        return z;
    }

    private void ah() {
        if (this.kA.kS == null) {
            ev.m1013D("Ad state was null when trying to ping click URLs.");
            return;
        }
        ev.m1018z("Pinging click URLs.");
        this.kA.kT.bx();
        if (this.kA.kS.nr != null) {
            ep.m972a(this.kA.kM, this.kA.kO.st, this.kA.kS.nr);
        }
        if (this.kA.kS.rw != null && this.kA.kS.rw.nr != null) {
            bs.m835a(this.kA.kM, this.kA.kO.st, this.kA.kS, this.kA.kL, false, this.kA.kS.rw.nr);
        }
    }

    private void ai() {
        if (this.kA.kS != null) {
            this.kA.kS.ow.destroy();
            this.kA.kS = null;
        }
    }

    private void m3739b(View view) {
        this.kA.kK.addView(view, new LayoutParams(-2, -2));
    }

    private boolean m3740b(eg egVar) {
        View view;
        if (egVar.qd) {
            try {
                view = (View) C0931e.m3241e(egVar.nL.getView());
                View nextView = this.kA.kK.getNextView();
                if (nextView != null) {
                    this.kA.kK.removeView(nextView);
                }
                try {
                    m3739b(view);
                } catch (Throwable th) {
                    ev.m1016c("Could not add mediation view to view hierarchy.", th);
                    return false;
                }
            } catch (Throwable th2) {
                ev.m1016c("Could not get View from mediation adapter.", th2);
                return false;
            }
        } else if (egVar.rx != null) {
            egVar.ow.m1026a(egVar.rx);
            this.kA.kK.removeAllViews();
            this.kA.kK.setMinimumWidth(egVar.rx.widthPixels);
            this.kA.kK.setMinimumHeight(egVar.rx.heightPixels);
            m3739b(egVar.ow);
        }
        if (this.kA.kK.getChildCount() > 1) {
            this.kA.kK.showNext();
        }
        if (this.kA.kS != null) {
            view = this.kA.kK.getNextView();
            if (view instanceof ey) {
                ((ey) view).m1025a(this.kA.kM, this.kA.kR);
            } else if (view != null) {
                this.kA.kK.removeView(view);
            }
            if (this.kA.kS.nL != null) {
                try {
                    this.kA.kS.nL.destroy();
                } catch (RemoteException e) {
                    ev.m1013D("Could not destroy previous mediation adapter.");
                }
            }
        }
        this.kA.kK.setVisibility(0);
        return true;
    }

    private C0205a m3741c(aj ajVar) {
        PackageInfo packageInfo;
        Bundle bundle;
        ApplicationInfo applicationInfo = this.kA.kM.getApplicationInfo();
        try {
            packageInfo = this.kA.kM.getPackageManager().getPackageInfo(applicationInfo.packageName, 0);
        } catch (NameNotFoundException e) {
            packageInfo = null;
        }
        if (this.kA.kR.md || this.kA.kK.getParent() == null) {
            bundle = null;
        } else {
            int[] iArr = new int[2];
            this.kA.kK.getLocationOnScreen(iArr);
            int i = iArr[0];
            int i2 = iArr[1];
            DisplayMetrics displayMetrics = this.kA.kM.getResources().getDisplayMetrics();
            int width = this.kA.kK.getWidth();
            int height = this.kA.kK.getHeight();
            int i3 = (!this.kA.kK.isShown() || i + width <= 0 || i2 + height <= 0 || i > displayMetrics.widthPixels || i2 > displayMetrics.heightPixels) ? 0 : 1;
            bundle = new Bundle(5);
            bundle.putInt("x", i);
            bundle.putInt("y", i2);
            bundle.putInt("width", width);
            bundle.putInt("height", height);
            bundle.putInt("visible", i3);
        }
        String bD = ei.bD();
        this.kA.kT = new eh(bD, this.kA.kL);
        this.kA.kT.m949f(ajVar);
        return new C0205a(bundle, ajVar, this.kA.kR, this.kA.kL, applicationInfo, packageInfo, bD, ei.rN, this.kA.kO, ei.m954a(this.kA.kM, this, bD));
    }

    private void m3742c(boolean z) {
        if (this.kA.kS == null) {
            ev.m1013D("Ad state was null when trying to ping impression URLs.");
            return;
        }
        ev.m1018z("Pinging Impression URLs.");
        this.kA.kT.bw();
        if (this.kA.kS.ns != null) {
            ep.m972a(this.kA.kM, this.kA.kO.st, this.kA.kS.ns);
        }
        if (!(this.kA.kS.rw == null || this.kA.kS.rw.ns == null)) {
            bs.m835a(this.kA.kM, this.kA.kO.st, this.kA.kS, this.kA.kL, z, this.kA.kS.rw.ns);
        }
        if (this.kA.kS.nK != null && this.kA.kS.nK.nn != null) {
            bs.m835a(this.kA.kM, this.kA.kO.st, this.kA.kS, this.kA.kL, z, this.kA.kS.nK.nn);
        }
    }

    public C0152d m3743P() {
        hn.ay("getAdFrame must be called on the main UI thread.");
        return C0931e.m3242h(this.kA.kK);
    }

    public am m3744Q() {
        hn.ay("getAdSize must be called on the main UI thread.");
        return this.kA.kR;
    }

    public void m3745T() {
        ad();
    }

    public void m3746U() {
        this.kC.m2444d(this.kA.kS);
        if (this.kA.kR.md) {
            ai();
        }
        this.kD = false;
        ac();
        this.kA.kT.by();
    }

    public void m3747V() {
        if (this.kA.kR.md) {
            m3742c(false);
        }
        this.kD = true;
        ae();
    }

    public void m3748W() {
        onAdClicked();
    }

    public void m3749X() {
        m3746U();
    }

    public void m3750Y() {
        m3745T();
    }

    public void m3751Z() {
        m3747V();
    }

    public void m3752a(am amVar) {
        hn.ay("setAdSize must be called on the main UI thread.");
        this.kA.kR = amVar;
        if (this.kA.kS != null) {
            this.kA.kS.ow.m1026a(amVar);
        }
        if (this.kA.kK.getChildCount() > 1) {
            this.kA.kK.removeView(this.kA.kK.getNextView());
        }
        this.kA.kK.setMinimumWidth(amVar.widthPixels);
        this.kA.kK.setMinimumHeight(amVar.heightPixels);
        this.kA.kK.requestLayout();
    }

    public void m3753a(aq aqVar) {
        hn.ay("setAdListener must be called on the main UI thread.");
        this.kA.kP = aqVar;
    }

    public void m3754a(at atVar) {
        hn.ay("setAppEventListener must be called on the main UI thread.");
        this.kA.kU = atVar;
    }

    public void m3755a(dd ddVar) {
        hn.ay("setInAppPurchaseListener must be called on the main UI thread.");
        this.kA.kW = ddVar;
    }

    public void m3756a(dh dhVar, String str) {
        hn.ay("setPlayStorePurchaseParams must be called on the main UI thread.");
        this.kA.kX = new da(str);
        this.kA.kV = dhVar;
        if (!ei.bH() && dhVar != null) {
            new ct(this.kA.kM, this.kA.kV, this.kA.kX).start();
        }
    }

    public void m3757a(eg egVar) {
        int i = 0;
        this.kA.kQ = null;
        if (!(egVar.errorCode == -2 || egVar.errorCode == 3)) {
            ei.m955b(this.kA.al());
        }
        if (egVar.errorCode != -1) {
            boolean z = egVar.pV.extras != null ? egVar.pV.extras.getBoolean("_noRefresh", false) : false;
            if (this.kA.kR.md) {
                ep.m974a(egVar.ow);
            } else if (!z) {
                if (egVar.nv > 0) {
                    this.kB.m1464a(egVar.pV, egVar.nv);
                } else if (egVar.rw != null && egVar.rw.nv > 0) {
                    this.kB.m1464a(egVar.pV, egVar.rw.nv);
                } else if (!egVar.qd && egVar.errorCode == 2) {
                    this.kB.m1465d(egVar.pV);
                }
            }
            if (!(egVar.errorCode != 3 || egVar.rw == null || egVar.rw.nt == null)) {
                ev.m1018z("Pinging no fill URLs.");
                bs.m835a(this.kA.kM, this.kA.kO.st, egVar, this.kA.kL, false, egVar.rw.nt);
            }
            if (egVar.errorCode != -2) {
                m3738a(egVar.errorCode);
                return;
            }
            int i2;
            if (!this.kA.kR.md) {
                if (!m3740b(egVar)) {
                    m3738a(0);
                    return;
                } else if (this.kA.kK != null) {
                    this.kA.kK.kG.m995x(egVar.qi);
                }
            }
            if (!(this.kA.kS == null || this.kA.kS.nN == null)) {
                this.kA.kS.nN.m3471a(null);
            }
            if (egVar.nN != null) {
                egVar.nN.m3471a((bo) this);
            }
            this.kC.m2444d(this.kA.kS);
            this.kA.kS = egVar;
            if (egVar.rx != null) {
                this.kA.kR = egVar.rx;
            }
            this.kA.kT.m950j(egVar.ry);
            this.kA.kT.m951k(egVar.rz);
            this.kA.kT.m952n(this.kA.kR.md);
            this.kA.kT.m953o(egVar.qd);
            if (!this.kA.kR.md) {
                m3742c(false);
            }
            if (this.kA.kY == null) {
                this.kA.kY = new el(this.kA.kL);
            }
            if (egVar.rw != null) {
                i2 = egVar.rw.nw;
                i = egVar.rw.nx;
            } else {
                i2 = 0;
            }
            this.kA.kY.m964a(i2, i);
            if (!(this.kA.kR.md || egVar.ow == null || (!egVar.ow.bW().ce() && egVar.rv == null))) {
                ad a = this.kC.m2441a(this.kA.kR, this.kA.kS);
                if (egVar.ow.bW().ce() && a != null) {
                    a.m757a(new C0701y(egVar.ow));
                }
            }
            this.kA.kS.ow.bS();
            af();
        }
    }

    public void m3758a(String str, ArrayList<String> arrayList) {
        dc cuVar = new cu(str, arrayList, this.kA.kM, this.kA.kO.st);
        if (this.kA.kW == null) {
            ev.m1013D("InAppPurchaseListener is not set. Try to launch default purchase flow.");
            if (GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.kA.kM) != 0) {
                ev.m1013D("Google Play Service unavailable, cannot launch default purchase flow.");
                return;
            } else if (this.kA.kV == null) {
                ev.m1013D("PlayStorePurchaseListener is not set.");
                return;
            } else if (this.kA.kX == null) {
                ev.m1013D("PlayStorePurchaseVerifier is not initialized.");
                return;
            } else {
                try {
                    if (!this.kA.kV.isValidPurchase(str)) {
                        return;
                    }
                } catch (RemoteException e) {
                    ev.m1013D("Could not start In-App purchase.");
                }
                cv.m3554a(this.kA.kM, this.kA.kO.sw, new cr(cuVar, this.kA.kV, this.kA.kX, this.kA.kM));
                return;
            }
        }
        try {
            this.kA.kW.m888a(cuVar);
        } catch (RemoteException e2) {
            ev.m1013D("Could not start In-App purchase.");
        }
    }

    public void m3759a(HashSet<eh> hashSet) {
        this.kA.m1458a(hashSet);
    }

    public boolean m3760a(aj ajVar) {
        hn.ay("loadAd must be called on the main UI thread.");
        if (this.kA.kQ != null) {
            ev.m1013D("An ad request is already in progress. Aborting.");
            return false;
        } else if (this.kA.kR.md && this.kA.kS != null) {
            ev.m1013D("An interstitial is already loading. Aborting.");
            return false;
        } else if (!ag()) {
            return false;
        } else {
            ey eyVar;
            ev.m1011B("Starting ad request.");
            if (!ajVar.lT) {
                ev.m1011B("Use AdRequest.Builder.addTestDevice(\"" + eu.m1008o(this.kA.kM) + "\") to get test ads on this device.");
            }
            this.kB.cancel();
            this.kA.kZ = false;
            C0205a c = m3741c(ajVar);
            if (this.kA.kR.md) {
                ey a = ey.m1022a(this.kA.kM, this.kA.kR, false, false, this.kA.kN, this.kA.kO);
                a.bW().m1039a(this, null, this, this, true, this, this);
                eyVar = a;
            } else {
                ey eyVar2;
                View nextView = this.kA.kK.getNextView();
                if (nextView instanceof ey) {
                    eyVar2 = (ey) nextView;
                    eyVar2.m1025a(this.kA.kM, this.kA.kR);
                } else {
                    if (nextView != null) {
                        this.kA.kK.removeView(nextView);
                    }
                    nextView = ey.m1022a(this.kA.kM, this.kA.kR, false, false, this.kA.kN, this.kA.kO);
                    if (this.kA.kR.me == null) {
                        m3739b(nextView);
                    }
                }
                eyVar2.bW().m1038a(this, this, this, this, false, this);
                eyVar = eyVar2;
            }
            this.kA.kQ = dn.m892a(this.kA.kM, c, this.kA.kN, eyVar, this.kz, this);
            return true;
        }
    }

    public void aa() {
        if (this.kA.kS != null) {
            ev.m1013D("Mediation adapter " + this.kA.kS.nM + " refreshed, but mediation adapters should never refresh.");
        }
        m3742c(true);
        af();
    }

    public void ab() {
        hn.ay("recordManualImpression must be called on the main UI thread.");
        if (this.kA.kS == null) {
            ev.m1013D("Ad state was null when trying to ping manual tracking URLs.");
            return;
        }
        ev.m1018z("Pinging manual tracking URLs.");
        if (this.kA.kS.qf != null) {
            ep.m972a(this.kA.kM, this.kA.kO.st, this.kA.kS.qf);
        }
    }

    public void m3761b(aj ajVar) {
        ViewParent parent = this.kA.kK.getParent();
        if ((parent instanceof View) && ((View) parent).isShown() && ep.bL() && !this.kD) {
            m3760a(ajVar);
            return;
        }
        ev.m1011B("Ad is not visible. Not refreshing ad.");
        this.kB.m1465d(ajVar);
    }

    public void m3762b(boolean z) {
        this.kA.kZ = z;
    }

    public void destroy() {
        hn.ay("destroy must be called on the main UI thread.");
        m3736S();
        this.kA.kP = null;
        this.kA.kU = null;
        this.kB.cancel();
        this.kC.stop();
        stopLoading();
        if (this.kA.kK != null) {
            this.kA.kK.removeAllViews();
        }
        if (!(this.kA.kS == null || this.kA.kS.ow == null)) {
            this.kA.kS.ow.destroy();
        }
        if (this.kA.kS != null && this.kA.kS.nL != null) {
            try {
                this.kA.kS.nL.destroy();
            } catch (RemoteException e) {
                ev.m1013D("Could not destroy mediation adapter.");
            }
        }
    }

    public boolean isReady() {
        hn.ay("isLoaded must be called on the main UI thread.");
        return this.kA.kQ == null && this.kA.kS != null;
    }

    public void onAdClicked() {
        ah();
    }

    public void onAppEvent(String name, String info) {
        if (this.kA.kU != null) {
            try {
                this.kA.kU.onAppEvent(name, info);
            } catch (Throwable e) {
                ev.m1016c("Could not call the AppEventListener.", e);
            }
        }
    }

    public void pause() {
        hn.ay("pause must be called on the main UI thread.");
        if (this.kA.kS != null) {
            ep.m974a(this.kA.kS.ow);
        }
        if (!(this.kA.kS == null || this.kA.kS.nL == null)) {
            try {
                this.kA.kS.nL.pause();
            } catch (RemoteException e) {
                ev.m1013D("Could not pause mediation adapter.");
            }
        }
        this.kC.pause();
        this.kB.pause();
    }

    public void resume() {
        hn.ay("resume must be called on the main UI thread.");
        if (this.kA.kS != null) {
            ep.m981b(this.kA.kS.ow);
        }
        if (!(this.kA.kS == null || this.kA.kS.nL == null)) {
            try {
                this.kA.kS.nL.resume();
            } catch (RemoteException e) {
                ev.m1013D("Could not resume mediation adapter.");
            }
        }
        this.kB.resume();
        this.kC.resume();
    }

    public void showInterstitial() {
        hn.ay("showInterstitial must be called on the main UI thread.");
        if (!this.kA.kR.md) {
            ev.m1013D("Cannot call showInterstitial on a banner ad.");
        } else if (this.kA.kS == null) {
            ev.m1013D("The interstitial has not loaded.");
        } else if (this.kA.kS.ow.bZ()) {
            ev.m1013D("The interstitial is already showing.");
        } else {
            this.kA.kS.ow.m1031q(true);
            if (this.kA.kS.ow.bW().ce() || this.kA.kS.rv != null) {
                ad a = this.kC.m2441a(this.kA.kR, this.kA.kS);
                if (this.kA.kS.ow.bW().ce() && a != null) {
                    a.m757a(new C0701y(this.kA.kS.ow));
                }
            }
            if (this.kA.kS.qd) {
                try {
                    this.kA.kS.nL.showInterstitial();
                    return;
                } catch (Throwable e) {
                    ev.m1016c("Could not show interstitial.", e);
                    ai();
                    return;
                }
            }
            C0700w c0700w = new C0700w(this.kA.kZ, false);
            if (this.kA.kM instanceof Activity) {
                Window window = ((Activity) this.kA.kM).getWindow();
                Rect rect = new Rect();
                Rect rect2 = new Rect();
                window.getDecorView().getGlobalVisibleRect(rect);
                window.getDecorView().getWindowVisibleDisplayFrame(rect2);
                if (!(rect.bottom == 0 || rect2.bottom == 0)) {
                    c0700w = new C0700w(this.kA.kZ, rect.top == rect2.top);
                }
            }
            cg.m3544a(this.kA.kM, new ci(this, this, this, this.kA.kS.ow, this.kA.kS.orientation, this.kA.kO, this.kA.kS.qi, c0700w));
        }
    }

    public void stopLoading() {
        hn.ay("stopLoading must be called on the main UI thread.");
        if (this.kA.kS != null) {
            this.kA.kS.ow.stopLoading();
            this.kA.kS = null;
        }
        if (this.kA.kQ != null) {
            this.kA.kQ.cancel();
        }
    }
}
