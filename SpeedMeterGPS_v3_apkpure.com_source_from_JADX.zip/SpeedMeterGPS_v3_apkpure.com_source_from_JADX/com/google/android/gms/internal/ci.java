package com.google.android.gms.internal;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.dynamic.C0152d.C0560a;
import com.google.android.gms.dynamic.C0931e;

public final class ci implements SafeParcelable {
    public static final ch CREATOR;
    public final ew kO;
    public final String nZ;
    public final String oA;
    public final cm oB;
    public final int oC;
    public final be oD;
    public final String oE;
    public final C0700w oF;
    public final int orientation;
    public final cf ot;
    public final C0271u ou;
    public final cj ov;
    public final ey ow;
    public final bb ox;
    public final String oy;
    public final boolean oz;
    public final int versionCode;

    static {
        CREATOR = new ch();
    }

    ci(int i, cf cfVar, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i2, int i3, String str3, ew ewVar, IBinder iBinder6, String str4, C0700w c0700w) {
        this.versionCode = i;
        this.ot = cfVar;
        this.ou = (C0271u) C0931e.m3241e(C0560a.ag(iBinder));
        this.ov = (cj) C0931e.m3241e(C0560a.ag(iBinder2));
        this.ow = (ey) C0931e.m3241e(C0560a.ag(iBinder3));
        this.ox = (bb) C0931e.m3241e(C0560a.ag(iBinder4));
        this.oy = str;
        this.oz = z;
        this.oA = str2;
        this.oB = (cm) C0931e.m3241e(C0560a.ag(iBinder5));
        this.orientation = i2;
        this.oC = i3;
        this.nZ = str3;
        this.kO = ewVar;
        this.oD = (be) C0931e.m3241e(C0560a.ag(iBinder6));
        this.oE = str4;
        this.oF = c0700w;
    }

    public ci(cf cfVar, C0271u c0271u, cj cjVar, cm cmVar, ew ewVar) {
        this.versionCode = 4;
        this.ot = cfVar;
        this.ou = c0271u;
        this.ov = cjVar;
        this.ow = null;
        this.ox = null;
        this.oy = null;
        this.oz = false;
        this.oA = null;
        this.oB = cmVar;
        this.orientation = -1;
        this.oC = 4;
        this.nZ = null;
        this.kO = ewVar;
        this.oD = null;
        this.oE = null;
        this.oF = null;
    }

    public ci(C0271u c0271u, cj cjVar, bb bbVar, cm cmVar, ey eyVar, boolean z, int i, String str, ew ewVar, be beVar) {
        this.versionCode = 4;
        this.ot = null;
        this.ou = c0271u;
        this.ov = cjVar;
        this.ow = eyVar;
        this.ox = bbVar;
        this.oy = null;
        this.oz = z;
        this.oA = null;
        this.oB = cmVar;
        this.orientation = i;
        this.oC = 3;
        this.nZ = str;
        this.kO = ewVar;
        this.oD = beVar;
        this.oE = null;
        this.oF = null;
    }

    public ci(C0271u c0271u, cj cjVar, bb bbVar, cm cmVar, ey eyVar, boolean z, int i, String str, String str2, ew ewVar, be beVar) {
        this.versionCode = 4;
        this.ot = null;
        this.ou = c0271u;
        this.ov = cjVar;
        this.ow = eyVar;
        this.ox = bbVar;
        this.oy = str2;
        this.oz = z;
        this.oA = str;
        this.oB = cmVar;
        this.orientation = i;
        this.oC = 3;
        this.nZ = null;
        this.kO = ewVar;
        this.oD = beVar;
        this.oE = null;
        this.oF = null;
    }

    public ci(C0271u c0271u, cj cjVar, cm cmVar, ey eyVar, int i, ew ewVar, String str, C0700w c0700w) {
        this.versionCode = 4;
        this.ot = null;
        this.ou = c0271u;
        this.ov = cjVar;
        this.ow = eyVar;
        this.ox = null;
        this.oy = null;
        this.oz = false;
        this.oA = null;
        this.oB = cmVar;
        this.orientation = i;
        this.oC = 1;
        this.nZ = null;
        this.kO = ewVar;
        this.oD = null;
        this.oE = str;
        this.oF = c0700w;
    }

    public ci(C0271u c0271u, cj cjVar, cm cmVar, ey eyVar, boolean z, int i, ew ewVar) {
        this.versionCode = 4;
        this.ot = null;
        this.ou = c0271u;
        this.ov = cjVar;
        this.ow = eyVar;
        this.ox = null;
        this.oy = null;
        this.oz = z;
        this.oA = null;
        this.oB = cmVar;
        this.orientation = i;
        this.oC = 2;
        this.nZ = null;
        this.kO = ewVar;
        this.oD = null;
        this.oE = null;
        this.oF = null;
    }

    public static ci m2512a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(ci.class.getClassLoader());
            return (ci) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception e) {
            return null;
        }
    }

    public static void m2513a(Intent intent, ci ciVar) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", ciVar);
        intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
    }

    IBinder aP() {
        return C0931e.m3242h(this.ou).asBinder();
    }

    IBinder aQ() {
        return C0931e.m3242h(this.ov).asBinder();
    }

    IBinder aR() {
        return C0931e.m3242h(this.ow).asBinder();
    }

    IBinder aS() {
        return C0931e.m3242h(this.ox).asBinder();
    }

    IBinder aT() {
        return C0931e.m3242h(this.oD).asBinder();
    }

    IBinder aU() {
        return C0931e.m3242h(this.oB).asBinder();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        ch.m849a(this, out, flags);
    }
}
