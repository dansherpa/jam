package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.dynamic.C0152d.C0560a;
import com.google.android.gms.dynamic.C0931e;

public final class cr implements SafeParcelable {
    public static final cq CREATOR;
    public final dh kV;
    public final da kX;
    public final dc oR;
    public final Context oS;
    public final int versionCode;

    static {
        CREATOR = new cq();
    }

    cr(int i, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4) {
        this.versionCode = i;
        this.kV = (dh) C0931e.m3241e(C0560a.ag(iBinder));
        this.kX = (da) C0931e.m3241e(C0560a.ag(iBinder2));
        this.oR = (dc) C0931e.m3241e(C0560a.ag(iBinder3));
        this.oS = (Context) C0931e.m3241e(C0560a.ag(iBinder4));
    }

    public cr(dc dcVar, dh dhVar, da daVar, Context context) {
        this.versionCode = 1;
        this.oR = dcVar;
        this.kV = dhVar;
        this.kX = daVar;
        this.oS = context;
    }

    public static void m2523a(Intent intent, cr crVar) {
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", crVar);
        intent.putExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo", bundle);
    }

    public static cr m2524b(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
            bundleExtra.setClassLoader(cr.class.getClassLoader());
            return (cr) bundleExtra.getParcelable("com.google.android.gms.ads.internal.purchase.InAppPurchaseManagerInfo");
        } catch (Exception e) {
            return null;
        }
    }

    IBinder aY() {
        return C0931e.m3242h(this.kV).asBinder();
    }

    IBinder aZ() {
        return C0931e.m3242h(this.kX).asBinder();
    }

    IBinder ba() {
        return C0931e.m3242h(this.oR).asBinder();
    }

    IBinder bb() {
        return C0931e.m3242h(this.oS).asBinder();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        cq.m866a(this, out, flags);
    }
}
