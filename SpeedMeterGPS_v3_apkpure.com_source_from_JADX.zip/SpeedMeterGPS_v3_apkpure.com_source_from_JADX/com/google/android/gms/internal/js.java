package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.wearable.DataEvent;

public class js implements Creator<jr> {
    static void m1308a(jr jrVar, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE, jrVar.xJ);
        C0072b.m236a(parcel, 2, jrVar.ja(), i, false);
        C0072b.m232a(parcel, 3, jrVar.getInterval());
        C0072b.m252c(parcel, 4, jrVar.getPriority());
        C0072b.m228G(parcel, C);
    }

    public jr bx(Parcel parcel) {
        int B = C0071a.m189B(parcel);
        int i = 0;
        jn jnVar = null;
        long j = jr.Wj;
        int i2 = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_DELETED /*2*/:
                    jnVar = (jn) C0071a.m194a(parcel, A, jn.CREATOR);
                    break;
                case DetectedActivity.STILL /*3*/:
                    j = C0071a.m207i(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new jr(i, jnVar, j, i2);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public jr[] cS(int i) {
        return new jr[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bx(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cS(x0);
    }
}
