package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.C0053a.C0903b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.ke.C0679a;
import com.google.android.gms.panorama.Panorama;
import com.google.android.gms.panorama.PanoramaApi;
import com.google.android.gms.panorama.PanoramaApi.C1035a;
import com.google.android.gms.panorama.PanoramaApi.PanoramaResult;

public class kg implements PanoramaApi {

    /* renamed from: com.google.android.gms.internal.kg.4 */
    static class C10014 extends C0679a {
        final /* synthetic */ Uri abh;
        final /* synthetic */ ke abk;
        final /* synthetic */ Context qr;

        C10014(Context context, Uri uri, ke keVar) {
            this.qr = context;
            this.abh = uri;
            this.abk = keVar;
        }

        public void m3670a(int i, Bundle bundle, int i2, Intent intent) throws RemoteException {
            kg.m2788a(this.qr, this.abh);
            this.abk.m1316a(i, bundle, i2, intent);
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.a */
    private static final class C1002a extends C0679a {
        private final C0052d<C1035a> yO;

        public C1002a(C0052d<C1035a> c0052d) {
            this.yO = c0052d;
        }

        public void m3671a(int i, Bundle bundle, int i2, Intent intent) {
            this.yO.m147a(new kd(new Status(i, null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null), intent, i2));
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.c */
    private static final class C1003c extends C0679a {
        private final C0052d<PanoramaResult> yO;

        public C1003c(C0052d<PanoramaResult> c0052d) {
            this.yO = c0052d;
        }

        public void m3672a(int i, Bundle bundle, int i2, Intent intent) {
            this.yO.m147a(new ki(new Status(i, null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null), intent));
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.d */
    private static abstract class C1092d<R extends Result> extends C0903b<R, kh> {
        protected C1092d() {
            super(Panorama.yE);
        }

        protected abstract void m4060a(Context context, kf kfVar) throws RemoteException;

        protected final void m4062a(kh khVar) throws RemoteException {
            m4060a(khVar.getContext(), (kf) khVar.fo());
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.1 */
    class C11501 extends C1092d<C1035a> {
        final /* synthetic */ Uri abh;
        final /* synthetic */ Bundle abi;

        protected void m4240a(Context context, kf kfVar) throws RemoteException {
            kg.m2789a(context, kfVar, new C1002a(this), this.abh, this.abi);
        }

        protected C1035a aj(Status status) {
            return new kd(status, null, 0);
        }

        protected /* synthetic */ Result m4241c(Status status) {
            return aj(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.b */
    private static abstract class C1151b extends C1092d<PanoramaResult> {
        private C1151b() {
        }

        protected PanoramaResult ak(Status status) {
            return new ki(status, null);
        }

        protected /* synthetic */ Result m4242c(Status status) {
            return ak(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.2 */
    class C13042 extends C1151b {
        final /* synthetic */ Uri abh;
        final /* synthetic */ kg abj;

        C13042(kg kgVar, Uri uri) {
            this.abj = kgVar;
            this.abh = uri;
            super();
        }

        protected void m4640a(Context context, kf kfVar) throws RemoteException {
            kfVar.m1317a(new C1003c(this), this.abh, null, false);
        }
    }

    /* renamed from: com.google.android.gms.internal.kg.3 */
    class C13053 extends C1151b {
        final /* synthetic */ Uri abh;
        final /* synthetic */ kg abj;

        C13053(kg kgVar, Uri uri) {
            this.abj = kgVar;
            this.abh = uri;
            super();
        }

        protected void m4641a(Context context, kf kfVar) throws RemoteException {
            kg.m2789a(context, kfVar, new C1003c(this), this.abh, null);
        }
    }

    private static void m2788a(Context context, Uri uri) {
        context.revokeUriPermission(uri, 1);
    }

    private static void m2789a(Context context, kf kfVar, ke keVar, Uri uri, Bundle bundle) throws RemoteException {
        context.grantUriPermission(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, uri, 1);
        try {
            kfVar.m1317a(new C10014(context, uri, keVar), uri, bundle, true);
        } catch (RemoteException e) {
            m2788a(context, uri);
            throw e;
        } catch (RuntimeException e2) {
            m2788a(context, uri);
            throw e2;
        }
    }

    public PendingResult<PanoramaResult> loadPanoramaInfo(GoogleApiClient client, Uri uri) {
        return client.m139a(new C13042(this, uri));
    }

    public PendingResult<PanoramaResult> loadPanoramaInfoAndGrantAccess(GoogleApiClient client, Uri uri) {
        return client.m139a(new C13053(this, uri));
    }
}
