package com.google.android.gms.wearable;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.hl;

/* renamed from: com.google.android.gms.wearable.c */
public class C0874c implements SafeParcelable {
    public static final Creator<C0874c> CREATOR;
    private final int AQ;
    private final String YI;
    private final int alf;
    private final boolean alg;
    private final String mName;
    final int xJ;

    static {
        CREATOR = new C0436d();
    }

    C0874c(int i, String str, String str2, int i2, int i3, boolean z) {
        this.xJ = i;
        this.mName = str;
        this.YI = str2;
        this.AQ = i2;
        this.alf = i3;
        this.alg = z;
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object o) {
        if (!(o instanceof C0874c)) {
            return false;
        }
        C0874c c0874c = (C0874c) o;
        return hl.equal(Integer.valueOf(this.xJ), Integer.valueOf(c0874c.xJ)) && hl.equal(this.mName, c0874c.mName) && hl.equal(this.YI, c0874c.YI) && hl.equal(Integer.valueOf(this.AQ), Integer.valueOf(c0874c.AQ)) && hl.equal(Integer.valueOf(this.alf), Integer.valueOf(c0874c.alf)) && hl.equal(Boolean.valueOf(this.alg), Boolean.valueOf(c0874c.alg));
    }

    public String getAddress() {
        return this.YI;
    }

    public String getName() {
        return this.mName;
    }

    public int getRole() {
        return this.alf;
    }

    public int getType() {
        return this.AQ;
    }

    public int hashCode() {
        return hl.hashCode(Integer.valueOf(this.xJ), this.mName, this.YI, Integer.valueOf(this.AQ), Integer.valueOf(this.alf), Boolean.valueOf(this.alg));
    }

    public boolean isEnabled() {
        return this.alg;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("ConnectionConfiguration[ ");
        stringBuilder.append("mName=" + this.mName);
        stringBuilder.append(", mAddress=" + this.YI);
        stringBuilder.append(", mType=" + this.AQ);
        stringBuilder.append(", mRole=" + this.alf);
        stringBuilder.append(", mEnabled=" + this.alg);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0436d.m1811a(this, dest, flags);
    }
}
