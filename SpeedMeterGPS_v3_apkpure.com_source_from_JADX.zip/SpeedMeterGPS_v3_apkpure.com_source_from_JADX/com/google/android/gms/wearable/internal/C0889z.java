package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.internal.z */
public class C0889z implements SafeParcelable {
    public static final Creator<C0889z> CREATOR;
    public final ai alN;
    public final int statusCode;
    public final int versionCode;

    static {
        CREATOR = new aa();
    }

    C0889z(int i, int i2, ai aiVar) {
        this.versionCode = i;
        this.statusCode = i2;
        this.alN = aiVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        aa.m1813a(this, dest, flags);
    }
}
