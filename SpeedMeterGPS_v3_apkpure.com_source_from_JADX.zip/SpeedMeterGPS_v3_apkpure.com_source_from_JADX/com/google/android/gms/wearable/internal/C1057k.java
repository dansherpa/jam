package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.data.C0060d;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataItemAsset;

/* renamed from: com.google.android.gms.wearable.internal.k */
public class C1057k extends C0060d implements DataItemAsset {
    public C1057k(DataHolder dataHolder, int i) {
        super(dataHolder, i);
    }

    public /* synthetic */ Object freeze() {
        return nl();
    }

    public String getDataItemKey() {
        return getString("asset_key");
    }

    public String getId() {
        return getString("asset_id");
    }

    public DataItemAsset nl() {
        return new C1056i(this);
    }
}
