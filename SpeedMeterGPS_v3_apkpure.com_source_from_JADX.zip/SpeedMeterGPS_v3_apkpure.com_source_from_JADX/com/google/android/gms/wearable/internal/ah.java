package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.NodeApi.GetConnectedNodesResult;
import com.google.android.gms.wearable.NodeApi.GetLocalNodeResult;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import java.util.List;

public final class ah implements NodeApi {

    /* renamed from: com.google.android.gms.wearable.internal.ah.a */
    public static class C1049a implements GetConnectedNodesResult {
        private final List<Node> alW;
        private final Status yw;

        public C1049a(Status status, List<Node> list) {
            this.yw = status;
            this.alW = list;
        }

        public List<Node> getNodes() {
            return this.alW;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ah.b */
    public static class C1050b implements GetLocalNodeResult {
        private final Node alX;
        private final Status yw;

        public C1050b(Status status, Node node) {
            this.yw = status;
            this.alX = node;
        }

        public Node getNode() {
            return this.alX;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ah.1 */
    class C11611 extends C1113d<GetLocalNodeResult> {
        final /* synthetic */ ah alU;

        C11611(ah ahVar) {
            this.alU = ahVar;
        }

        protected void m4265a(au auVar) throws RemoteException {
            auVar.m3877p(this);
        }

        protected GetLocalNodeResult av(Status status) {
            return new C1050b(status, null);
        }

        protected /* synthetic */ Result m4266c(Status status) {
            return av(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ah.2 */
    class C11622 extends C1113d<GetConnectedNodesResult> {
        final /* synthetic */ ah alU;

        C11622(ah ahVar) {
            this.alU = ahVar;
        }

        protected void m4268a(au auVar) throws RemoteException {
            auVar.m3878q(this);
        }

        protected GetConnectedNodesResult aw(Status status) {
            return new C1049a(status, null);
        }

        protected /* synthetic */ Result m4269c(Status status) {
            return aw(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ah.3 */
    class C11633 extends C1113d<Status> {
        final /* synthetic */ ah alU;
        final /* synthetic */ NodeListener alV;

        C11633(ah ahVar, NodeListener nodeListener) {
            this.alU = ahVar;
            this.alV = nodeListener;
        }

        protected void m4271a(au auVar) throws RemoteException {
            auVar.m3868a((C0052d) this, this.alV);
        }

        public /* synthetic */ Result m4272c(Status status) {
            return m4273d(status);
        }

        public Status m4273d(Status status) {
            return new Status(13);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ah.4 */
    class C11644 extends C1113d<Status> {
        final /* synthetic */ ah alU;
        final /* synthetic */ NodeListener alV;

        C11644(ah ahVar, NodeListener nodeListener) {
            this.alU = ahVar;
            this.alV = nodeListener;
        }

        protected void m4275a(au auVar) throws RemoteException {
            auVar.m3874b((C0052d) this, this.alV);
        }

        public /* synthetic */ Result m4276c(Status status) {
            return m4277d(status);
        }

        public Status m4277d(Status status) {
            return new Status(13);
        }
    }

    public PendingResult<Status> addListener(GoogleApiClient client, NodeListener listener) {
        return client.m139a(new C11633(this, listener));
    }

    public PendingResult<GetConnectedNodesResult> getConnectedNodes(GoogleApiClient client) {
        return client.m139a(new C11622(this));
    }

    public PendingResult<GetLocalNodeResult> getLocalNode(GoogleApiClient client) {
        return client.m139a(new C11611(this));
    }

    public PendingResult<Status> removeListener(GoogleApiClient client, NodeListener listener) {
        return client.m139a(new C11644(this, listener));
    }
}
