package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataItemAsset;

/* renamed from: com.google.android.gms.wearable.internal.i */
public class C1056i implements DataItemAsset {
    private final String JI;
    private final String xD;

    public C1056i(DataItemAsset dataItemAsset) {
        this.xD = dataItemAsset.getId();
        this.JI = dataItemAsset.getDataItemKey();
    }

    public /* synthetic */ Object freeze() {
        return nl();
    }

    public String getDataItemKey() {
        return this.JI;
    }

    public String getId() {
        return this.xD;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataItemAsset nl() {
        return this;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.xD == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.xD);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.JI);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
