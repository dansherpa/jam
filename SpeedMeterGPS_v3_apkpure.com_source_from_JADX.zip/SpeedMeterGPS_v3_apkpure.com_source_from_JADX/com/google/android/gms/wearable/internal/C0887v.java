package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

/* renamed from: com.google.android.gms.wearable.internal.v */
public class C0887v implements SafeParcelable {
    public static final Creator<C0887v> CREATOR;
    public final C1059m alL;
    public final int statusCode;
    public final int versionCode;

    static {
        CREATOR = new C0444w();
    }

    C0887v(int i, int i2, C1059m c1059m) {
        this.versionCode = i;
        this.statusCode = i2;
        this.alL = c1059m;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0444w.m1859a(this, dest, flags);
    }
}
