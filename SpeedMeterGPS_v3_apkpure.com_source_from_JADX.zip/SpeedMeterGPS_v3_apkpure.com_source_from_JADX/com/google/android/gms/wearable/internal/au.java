package com.google.android.gms.wearable.internal;

import android.content.Context;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.hc;
import com.google.android.gms.internal.hc.C0993e;
import com.google.android.gms.internal.hj;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataApi.DataItemResult;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataApi.DeleteDataItemsResult;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import com.google.android.gms.wearable.DataItemAsset;
import com.google.android.gms.wearable.DataItemBuffer;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.MessageApi.SendMessageResult;
import com.google.android.gms.wearable.NodeApi.GetConnectedNodesResult;
import com.google.android.gms.wearable.NodeApi.GetLocalNodeResult;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.WearableStatusCodes;
import com.google.android.gms.wearable.internal.C0883f.C1051a;
import com.google.android.gms.wearable.internal.C0883f.C1052b;
import com.google.android.gms.wearable.internal.C0883f.C1053c;
import com.google.android.gms.wearable.internal.ad.C0880a;
import com.google.android.gms.wearable.internal.ae.C1048a;
import com.google.android.gms.wearable.internal.ah.C1049a;
import com.google.android.gms.wearable.internal.ah.C1050b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public class au extends hc<ad> {
    private final ExecutorService agR;
    private final HashMap<DataListener, av> amb;
    private final HashMap<MessageListener, av> amc;
    private final HashMap<NodeListener, av> amd;

    /* renamed from: com.google.android.gms.wearable.internal.au.11 */
    class AnonymousClass11 implements Callable<Boolean> {
        final /* synthetic */ au ame;
        final /* synthetic */ ParcelFileDescriptor amg;
        final /* synthetic */ byte[] yI;

        AnonymousClass11(au auVar, ParcelFileDescriptor parcelFileDescriptor, byte[] bArr) {
            this.ame = auVar;
            this.amg = parcelFileDescriptor;
            this.yI = bArr;
        }

        public /* synthetic */ Object call() throws Exception {
            return no();
        }

        public java.lang.Boolean no() {
            /* JADX: method processing error */
/*
            Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x00bf in list []
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:42)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:58)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:281)
	at jadx.api.JavaClass.decompile(JavaClass.java:59)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:161)
*/
            /*
            r5 = this;
            r1 = 3;
            r0 = "WearableClient";
            r0 = android.util.Log.isLoggable(r0, r1);
            if (r0 == 0) goto L_0x0023;
        L_0x0009:
            r0 = "WearableClient";
            r1 = new java.lang.StringBuilder;
            r1.<init>();
            r2 = "processAssets: writing data to FD : ";
            r1 = r1.append(r2);
            r2 = r5.amg;
            r1 = r1.append(r2);
            r1 = r1.toString();
            android.util.Log.d(r0, r1);
        L_0x0023:
            r1 = new android.os.ParcelFileDescriptor$AutoCloseOutputStream;
            r0 = r5.amg;
            r1.<init>(r0);
            r0 = r5.yI;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r1.write(r0);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r1.flush();	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r0 = "WearableClient";	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = 3;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r0 = android.util.Log.isLoggable(r0, r2);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            if (r0 == 0) goto L_0x0055;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
        L_0x003b:
            r0 = "WearableClient";	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2.<init>();	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r3 = "processAssets: wrote data: ";	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = r2.append(r3);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r3 = r5.amg;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = r2.append(r3);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = r2.toString();	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            android.util.Log.d(r0, r2);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
        L_0x0055:
            r0 = 1;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r0 = java.lang.Boolean.valueOf(r0);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = "WearableClient";	 Catch:{ IOException -> 0x00f4 }
            r3 = 3;	 Catch:{ IOException -> 0x00f4 }
            r2 = android.util.Log.isLoggable(r2, r3);	 Catch:{ IOException -> 0x00f4 }
            if (r2 == 0) goto L_0x007d;	 Catch:{ IOException -> 0x00f4 }
        L_0x0063:
            r2 = "WearableClient";	 Catch:{ IOException -> 0x00f4 }
            r3 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x00f4 }
            r3.<init>();	 Catch:{ IOException -> 0x00f4 }
            r4 = "processAssets: closing: ";	 Catch:{ IOException -> 0x00f4 }
            r3 = r3.append(r4);	 Catch:{ IOException -> 0x00f4 }
            r4 = r5.amg;	 Catch:{ IOException -> 0x00f4 }
            r3 = r3.append(r4);	 Catch:{ IOException -> 0x00f4 }
            r3 = r3.toString();	 Catch:{ IOException -> 0x00f4 }
            android.util.Log.d(r2, r3);	 Catch:{ IOException -> 0x00f4 }
        L_0x007d:
            r1.close();	 Catch:{ IOException -> 0x00f4 }
        L_0x0080:
            return r0;
        L_0x0081:
            r0 = move-exception;
            r0 = "WearableClient";	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2.<init>();	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r3 = "processAssets: writing data failed: ";	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = r2.append(r3);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r3 = r5.amg;	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = r2.append(r3);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r2 = r2.toString();	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            android.util.Log.w(r0, r2);	 Catch:{ IOException -> 0x0081, all -> 0x00c8 }
            r0 = "WearableClient";
            r2 = 3;
            r0 = android.util.Log.isLoggable(r0, r2);
            if (r0 == 0) goto L_0x00bf;
        L_0x00a5:
            r0 = "WearableClient";
            r2 = new java.lang.StringBuilder;
            r2.<init>();
            r3 = "processAssets: closing: ";
            r2 = r2.append(r3);
            r3 = r5.amg;
            r2 = r2.append(r3);
            r2 = r2.toString();
            android.util.Log.d(r0, r2);
        L_0x00bf:
            r1.close();
        L_0x00c2:
            r0 = 0;
            r0 = java.lang.Boolean.valueOf(r0);
            goto L_0x0080;
        L_0x00c8:
            r0 = move-exception;
            r2 = "WearableClient";	 Catch:{ IOException -> 0x00f0 }
            r3 = 3;	 Catch:{ IOException -> 0x00f0 }
            r2 = android.util.Log.isLoggable(r2, r3);	 Catch:{ IOException -> 0x00f0 }
            if (r2 == 0) goto L_0x00ec;	 Catch:{ IOException -> 0x00f0 }
        L_0x00d2:
            r2 = "WearableClient";	 Catch:{ IOException -> 0x00f0 }
            r3 = new java.lang.StringBuilder;	 Catch:{ IOException -> 0x00f0 }
            r3.<init>();	 Catch:{ IOException -> 0x00f0 }
            r4 = "processAssets: closing: ";	 Catch:{ IOException -> 0x00f0 }
            r3 = r3.append(r4);	 Catch:{ IOException -> 0x00f0 }
            r4 = r5.amg;	 Catch:{ IOException -> 0x00f0 }
            r3 = r3.append(r4);	 Catch:{ IOException -> 0x00f0 }
            r3 = r3.toString();	 Catch:{ IOException -> 0x00f0 }
            android.util.Log.d(r2, r3);	 Catch:{ IOException -> 0x00f0 }
        L_0x00ec:
            r1.close();	 Catch:{ IOException -> 0x00f0 }
        L_0x00ef:
            throw r0;
        L_0x00f0:
            r1 = move-exception;
            goto L_0x00ef;
        L_0x00f2:
            r0 = move-exception;
            goto L_0x00c2;
        L_0x00f4:
            r1 = move-exception;
            goto L_0x0080;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.wearable.internal.au.11.no():java.lang.Boolean");
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.10 */
    class AnonymousClass10 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        AnonymousClass10(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4083a(Status status) {
            this.amf.m147a(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.12 */
    class AnonymousClass12 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        AnonymousClass12(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4084a(C0887v c0887v) {
            this.amf.m147a(new C1051a(new Status(c0887v.statusCode), c0887v.alL));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.13 */
    class AnonymousClass13 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        AnonymousClass13(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4085Z(DataHolder dataHolder) {
            this.amf.m147a(new DataItemBuffer(dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.14 */
    class AnonymousClass14 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        AnonymousClass14(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4086Z(DataHolder dataHolder) {
            this.amf.m147a(new DataItemBuffer(dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.1 */
    class C11031 extends C1047a {
        final /* synthetic */ au ame;

        C11031(au auVar) {
            this.ame = auVar;
        }

        public void m4087a(Status status) {
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.2 */
    class C11042 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11042(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4088a(C0884p c0884p) {
            this.amf.m147a(new C1052b(new Status(c0884p.statusCode), c0884p.alI));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.3 */
    class C11053 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11053(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4089a(aq aqVar) {
            this.amf.m147a(new C1048a(new Status(aqVar.statusCode), aqVar.alZ));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.4 */
    class C11064 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11064(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4090a(C0888x c0888x) {
            this.amf.m147a(new C1053c(new Status(c0888x.statusCode), c0888x.alM));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.5 */
    class C11075 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11075(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4091a(C0889z c0889z) {
            this.amf.m147a(new C1050b(new Status(c0889z.statusCode), c0889z.alN));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.6 */
    class C11086 extends C1047a {
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11086(au auVar, C0052d c0052d) {
            this.ame = auVar;
            this.amf = c0052d;
        }

        public void m4092a(C0886t c0886t) {
            List arrayList = new ArrayList();
            arrayList.addAll(c0886t.alK);
            this.amf.m147a(new C1049a(new Status(c0886t.statusCode), arrayList));
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.7 */
    class C11097 extends C1047a {
        final /* synthetic */ DataListener alC;
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11097(au auVar, DataListener dataListener, C0052d c0052d) {
            this.ame = auVar;
            this.alC = dataListener;
            this.amf = c0052d;
        }

        public void m4093a(Status status) {
            if (!status.isSuccess()) {
                synchronized (this.ame.amb) {
                    this.ame.amb.remove(this.alC);
                }
            }
            this.amf.m147a(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.8 */
    class C11108 extends C1047a {
        final /* synthetic */ MessageListener alR;
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11108(au auVar, MessageListener messageListener, C0052d c0052d) {
            this.ame = auVar;
            this.alR = messageListener;
            this.amf = c0052d;
        }

        public void m4094a(Status status) {
            if (!status.isSuccess()) {
                synchronized (this.ame.amc) {
                    this.ame.amc.remove(this.alR);
                }
            }
            this.amf.m147a(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.9 */
    class C11119 extends C1047a {
        final /* synthetic */ NodeListener alV;
        final /* synthetic */ au ame;
        final /* synthetic */ C0052d amf;

        C11119(au auVar, NodeListener nodeListener, C0052d c0052d) {
            this.ame = auVar;
            this.alV = nodeListener;
            this.amf = c0052d;
        }

        public void m4095a(Status status) {
            if (!status.isSuccess()) {
                synchronized (this.ame.amd) {
                    this.ame.amd.remove(this.alV);
                }
            }
            this.amf.m147a(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.au.a */
    private static class C1112a extends C1047a {
        private final List<FutureTask<Boolean>> amh;
        private final C0052d<DataItemResult> yO;

        C1112a(C0052d<DataItemResult> c0052d, List<FutureTask<Boolean>> list) {
            this.yO = c0052d;
            this.amh = list;
        }

        public void m4096a(am amVar) {
            this.yO.m147a(new C1051a(new Status(amVar.statusCode), amVar.alL));
            if (amVar.statusCode != 0) {
                for (FutureTask cancel : this.amh) {
                    cancel.cancel(true);
                }
            }
        }
    }

    public au(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.agR = Executors.newCachedThreadPool();
        this.amb = new HashMap();
        this.amc = new HashMap();
        this.amd = new HashMap();
    }

    private FutureTask<Boolean> m3856a(ParcelFileDescriptor parcelFileDescriptor, byte[] bArr) {
        return new FutureTask(new AnonymousClass11(this, parcelFileDescriptor, bArr));
    }

    protected void m3860a(int i, IBinder iBinder, Bundle bundle) {
        if (Log.isLoggable("WearableClient", 2)) {
            Log.d("WearableClient", "onPostInitHandler: statusCode " + i);
        }
        if (i == 0) {
            try {
                ab c11031 = new C11031(this);
                if (Log.isLoggable("WearableClient", 2)) {
                    Log.d("WearableClient", "onPostInitHandler: service " + iBinder);
                }
                ad by = C0880a.by(iBinder);
                for (Entry entry : this.amb.entrySet()) {
                    if (Log.isLoggable("WearableClient", 2)) {
                        Log.d("WearableClient", "onPostInitHandler: adding Data listener " + entry.getValue());
                    }
                    by.m1835a(c11031, new C0881b((av) entry.getValue()));
                }
                for (Entry entry2 : this.amc.entrySet()) {
                    if (Log.isLoggable("WearableClient", 2)) {
                        Log.d("WearableClient", "onPostInitHandler: adding Message listener " + entry2.getValue());
                    }
                    by.m1835a(c11031, new C0881b((av) entry2.getValue()));
                }
                for (Entry entry22 : this.amd.entrySet()) {
                    if (Log.isLoggable("WearableClient", 2)) {
                        Log.d("WearableClient", "onPostInitHandler: adding Node listener " + entry22.getValue());
                    }
                    by.m1835a(c11031, new C0881b((av) entry22.getValue()));
                }
            } catch (Throwable e) {
                Log.d("WearableClient", "WearableClientImpl.onPostInitHandler: error while adding listener", e);
            }
        }
        Log.d("WearableClient", "WearableClientImpl.onPostInitHandler: done");
        super.m2652a(i, iBinder, bundle);
    }

    public void m3861a(C0052d<DataItemResult> c0052d, Uri uri) throws RemoteException {
        ((ad) fo()).m1830a(new AnonymousClass12(this, c0052d), uri);
    }

    public void m3862a(C0052d<GetFdForAssetResult> c0052d, Asset asset) throws RemoteException {
        ((ad) fo()).m1831a(new C11064(this, c0052d), asset);
    }

    public void m3863a(C0052d<Status> c0052d, DataListener dataListener) throws RemoteException {
        synchronized (this.amb) {
            ac acVar = (ac) this.amb.remove(dataListener);
        }
        if (acVar == null) {
            c0052d.m147a(new Status(WearableStatusCodes.UNKNOWN_LISTENER));
        } else {
            m3870a((C0052d) c0052d, acVar);
        }
    }

    public void m3864a(C0052d<Status> c0052d, DataListener dataListener, IntentFilter[] intentFilterArr) throws RemoteException {
        av a = av.m3880a(dataListener, intentFilterArr);
        synchronized (this.amb) {
            if (this.amb.get(dataListener) != null) {
                c0052d.m147a(new Status(WearableStatusCodes.DUPLICATE_LISTENER));
                return;
            }
            this.amb.put(dataListener, a);
            ((ad) fo()).m1835a(new C11097(this, dataListener, c0052d), new C0881b(a));
        }
    }

    public void m3865a(C0052d<GetFdForAssetResult> c0052d, DataItemAsset dataItemAsset) throws RemoteException {
        m3862a((C0052d) c0052d, Asset.createFromRef(dataItemAsset.getId()));
    }

    public void m3866a(C0052d<Status> c0052d, MessageListener messageListener) throws RemoteException {
        synchronized (this.amc) {
            ac acVar = (ac) this.amc.remove(messageListener);
            if (acVar == null) {
                c0052d.m147a(new Status(WearableStatusCodes.UNKNOWN_LISTENER));
            } else {
                m3870a((C0052d) c0052d, acVar);
            }
        }
    }

    public void m3867a(C0052d<Status> c0052d, MessageListener messageListener, IntentFilter[] intentFilterArr) throws RemoteException {
        av a = av.m3881a(messageListener, intentFilterArr);
        synchronized (this.amc) {
            if (this.amc.get(messageListener) != null) {
                c0052d.m147a(new Status(WearableStatusCodes.DUPLICATE_LISTENER));
                return;
            }
            this.amc.put(messageListener, a);
            ((ad) fo()).m1835a(new C11108(this, messageListener, c0052d), new C0881b(a));
        }
    }

    public void m3868a(C0052d<Status> c0052d, NodeListener nodeListener) throws RemoteException, RemoteException {
        av a = av.m3882a(nodeListener);
        synchronized (this.amd) {
            if (this.amd.get(nodeListener) != null) {
                c0052d.m147a(new Status(WearableStatusCodes.DUPLICATE_LISTENER));
                return;
            }
            this.amd.put(nodeListener, a);
            ((ad) fo()).m1835a(new C11119(this, nodeListener, c0052d), new C0881b(a));
        }
    }

    public void m3869a(C0052d<DataItemResult> c0052d, PutDataRequest putDataRequest) throws RemoteException {
        for (Entry value : putDataRequest.getAssets().entrySet()) {
            Asset asset = (Asset) value.getValue();
            if (asset.getData() == null && asset.getDigest() == null && asset.getFd() == null && asset.getUri() == null) {
                throw new IllegalArgumentException("Put for " + putDataRequest.getUri() + " contains invalid asset: " + asset);
            }
        }
        PutDataRequest j = PutDataRequest.m3105j(putDataRequest.getUri());
        j.setData(putDataRequest.getData());
        List arrayList = new ArrayList();
        for (Entry value2 : putDataRequest.getAssets().entrySet()) {
            Asset asset2 = (Asset) value2.getValue();
            if (asset2.getData() == null) {
                j.putAsset((String) value2.getKey(), (Asset) value2.getValue());
            } else {
                try {
                    ParcelFileDescriptor[] createPipe = ParcelFileDescriptor.createPipe();
                    if (Log.isLoggable("WearableClient", 3)) {
                        Log.d("WearableClient", "processAssets: replacing data with FD in asset: " + asset2 + " read:" + createPipe[0] + " write:" + createPipe[1]);
                    }
                    j.putAsset((String) value2.getKey(), Asset.createFromFd(createPipe[0]));
                    Runnable a = m3856a(createPipe[1], asset2.getData());
                    arrayList.add(a);
                    this.agR.submit(a);
                } catch (Throwable e) {
                    throw new IllegalStateException("Unable to create ParcelFileDescriptor for asset in request: " + putDataRequest, e);
                }
            }
        }
        try {
            ((ad) fo()).m1832a(new C1112a(c0052d, arrayList), j);
        } catch (Throwable e2) {
            throw new IllegalStateException("Unable to putDataItem: " + putDataRequest, e2);
        }
    }

    public void m3870a(C0052d<Status> c0052d, ac acVar) throws RemoteException {
        ((ad) fo()).m1834a(new AnonymousClass10(this, c0052d), new ao(acVar));
    }

    public void m3871a(C0052d<SendMessageResult> c0052d, String str, String str2, byte[] bArr) throws RemoteException {
        ((ad) fo()).m1836a(new C11053(this, c0052d), str, str2, bArr);
    }

    protected void m3872a(hj hjVar, C0993e c0993e) throws RemoteException {
        hjVar.m1200e(c0993e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName());
    }

    public void m3873b(C0052d<DataItemBuffer> c0052d, Uri uri) throws RemoteException {
        ((ad) fo()).m1838b(new AnonymousClass14(this, c0052d), uri);
    }

    public void m3874b(C0052d<Status> c0052d, NodeListener nodeListener) throws RemoteException {
        synchronized (this.amd) {
            ac acVar = (ac) this.amd.remove(nodeListener);
            if (acVar == null) {
                c0052d.m147a(new Status(WearableStatusCodes.UNKNOWN_LISTENER));
            } else {
                m3870a((C0052d) c0052d, acVar);
            }
        }
    }

    protected String bp() {
        return "com.google.android.gms.wearable.BIND";
    }

    protected String bq() {
        return "com.google.android.gms.wearable.internal.IWearableService";
    }

    protected ad bz(IBinder iBinder) {
        return C0880a.by(iBinder);
    }

    public void m3875c(C0052d<DeleteDataItemsResult> c0052d, Uri uri) throws RemoteException {
        ((ad) fo()).m1840c(new C11042(this, c0052d), uri);
    }

    public void disconnect() {
        super.disconnect();
        this.amb.clear();
        this.amc.clear();
        this.amd.clear();
    }

    public void m3876o(C0052d<DataItemBuffer> c0052d) throws RemoteException {
        ((ad) fo()).m1841d(new AnonymousClass13(this, c0052d));
    }

    public void m3877p(C0052d<GetLocalNodeResult> c0052d) throws RemoteException {
        ((ad) fo()).m1842e(new C11075(this, c0052d));
    }

    public void m3878q(C0052d<GetConnectedNodesResult> c0052d) throws RemoteException {
        ((ad) fo()).m1843f(new C11086(this, c0052d));
    }

    protected /* synthetic */ IInterface m3879x(IBinder iBinder) {
        return bz(iBinder);
    }
}
