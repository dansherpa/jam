package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.ac.C0878a;

public class av extends C0878a {
    private final DataListener ami;
    private final MessageListener amj;
    private final NodeListener amk;
    private final IntentFilter[] aml;

    public av(DataListener dataListener, MessageListener messageListener, NodeListener nodeListener, IntentFilter[] intentFilterArr) {
        this.ami = dataListener;
        this.amj = messageListener;
        this.amk = nodeListener;
        this.aml = intentFilterArr;
    }

    public static av m3880a(DataListener dataListener, IntentFilter[] intentFilterArr) {
        return new av(dataListener, null, null, intentFilterArr);
    }

    public static av m3881a(MessageListener messageListener, IntentFilter[] intentFilterArr) {
        return new av(null, messageListener, null, intentFilterArr);
    }

    public static av m3882a(NodeListener nodeListener) {
        return new av(null, null, nodeListener, null);
    }

    public void m3883Y(DataHolder dataHolder) {
        if (this.ami != null) {
            try {
                this.ami.onDataChanged(new DataEventBuffer(dataHolder));
            } finally {
                dataHolder.close();
            }
        } else {
            dataHolder.close();
        }
    }

    public void m3884a(af afVar) {
        if (this.amj != null) {
            this.amj.onMessageReceived(afVar);
        }
    }

    public void m3885a(ai aiVar) {
        if (this.amk != null) {
            this.amk.onPeerConnected(aiVar);
        }
    }

    public void m3886b(ai aiVar) {
        if (this.amk != null) {
            this.amk.onPeerDisconnected(aiVar);
        }
    }

    public IntentFilter[] np() {
        return this.aml;
    }
}
