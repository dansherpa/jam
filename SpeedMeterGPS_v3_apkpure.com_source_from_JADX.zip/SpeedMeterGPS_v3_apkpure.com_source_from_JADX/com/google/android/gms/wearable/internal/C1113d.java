package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.C0053a.C0903b;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.wearable.Wearable;

/* renamed from: com.google.android.gms.wearable.internal.d */
abstract class C1113d<R extends Result> extends C0903b<R, au> {
    public C1113d() {
        super(Wearable.yE);
    }
}
