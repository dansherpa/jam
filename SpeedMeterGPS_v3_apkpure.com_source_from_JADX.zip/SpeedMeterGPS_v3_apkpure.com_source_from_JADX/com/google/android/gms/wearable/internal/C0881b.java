package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.internal.ac.C0878a;

/* renamed from: com.google.android.gms.wearable.internal.b */
public class C0881b implements SafeParcelable {
    public static final Creator<C0881b> CREATOR;
    public final ac alw;
    public final IntentFilter[] alx;
    final int xJ;

    static {
        CREATOR = new C0438c();
    }

    C0881b(int i, IBinder iBinder, IntentFilter[] intentFilterArr) {
        this.xJ = i;
        if (iBinder != null) {
            this.alw = C0878a.bx(iBinder);
        } else {
            this.alw = null;
        }
        this.alx = intentFilterArr;
    }

    public C0881b(av avVar) {
        this.xJ = 1;
        this.alw = avVar;
        this.alx = avVar.np();
    }

    public int describeContents() {
        return 0;
    }

    IBinder nj() {
        return this.alw == null ? null : this.alw.asBinder();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0438c.m1853a(this, dest, flags);
    }
}
