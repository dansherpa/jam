package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.wearable.MessageApi;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.MessageApi.SendMessageResult;

public final class ae implements MessageApi {

    /* renamed from: com.google.android.gms.wearable.internal.ae.a */
    public static class C1048a implements SendMessageResult {
        private final int qX;
        private final Status yw;

        public C1048a(Status status, int i) {
            this.yw = status;
            this.qX = i;
        }

        public int getRequestId() {
            return this.qX;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ae.1 */
    class C11581 extends C1113d<SendMessageResult> {
        final /* synthetic */ String alO;
        final /* synthetic */ String alP;
        final /* synthetic */ ae alQ;
        final /* synthetic */ byte[] yI;

        C11581(ae aeVar, String str, String str2, byte[] bArr) {
            this.alQ = aeVar;
            this.alO = str;
            this.alP = str2;
            this.yI = bArr;
        }

        protected void m4254a(au auVar) throws RemoteException {
            auVar.m3871a(this, this.alO, this.alP, this.yI);
        }

        protected SendMessageResult au(Status status) {
            return new C1048a(status, -1);
        }

        protected /* synthetic */ Result m4255c(Status status) {
            return au(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ae.2 */
    class C11592 extends C1113d<Status> {
        final /* synthetic */ IntentFilter[] alD;
        final /* synthetic */ ae alQ;
        final /* synthetic */ MessageListener alR;

        C11592(ae aeVar, MessageListener messageListener, IntentFilter[] intentFilterArr) {
            this.alQ = aeVar;
            this.alR = messageListener;
            this.alD = intentFilterArr;
        }

        protected void m4257a(au auVar) throws RemoteException {
            auVar.m3867a((C0052d) this, this.alR, this.alD);
        }

        public /* synthetic */ Result m4258c(Status status) {
            return m4259d(status);
        }

        public Status m4259d(Status status) {
            return new Status(13);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.ae.3 */
    class C11603 extends C1113d<Status> {
        final /* synthetic */ ae alQ;
        final /* synthetic */ MessageListener alR;

        C11603(ae aeVar, MessageListener messageListener) {
            this.alQ = aeVar;
            this.alR = messageListener;
        }

        protected void m4261a(au auVar) throws RemoteException {
            auVar.m3866a((C0052d) this, this.alR);
        }

        public /* synthetic */ Result m4262c(Status status) {
            return m4263d(status);
        }

        public Status m4263d(Status status) {
            return new Status(13);
        }
    }

    private PendingResult<Status> m3145a(GoogleApiClient googleApiClient, MessageListener messageListener, IntentFilter[] intentFilterArr) {
        return googleApiClient.m139a(new C11592(this, messageListener, intentFilterArr));
    }

    public PendingResult<Status> addListener(GoogleApiClient client, MessageListener listener) {
        return m3145a(client, listener, null);
    }

    public PendingResult<Status> removeListener(GoogleApiClient client, MessageListener listener) {
        return client.m139a(new C11603(this, listener));
    }

    public PendingResult<SendMessageResult> sendMessage(GoogleApiClient client, String nodeId, String action, byte[] data) {
        return client.m139a(new C11581(this, nodeId, action, data));
    }
}
