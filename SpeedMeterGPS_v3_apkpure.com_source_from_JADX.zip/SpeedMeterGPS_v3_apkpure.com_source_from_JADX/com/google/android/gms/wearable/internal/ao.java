package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.internal.ac.C0878a;

public class ao implements SafeParcelable {
    public static final Creator<ao> CREATOR;
    public final ac alw;
    final int xJ;

    static {
        CREATOR = new ap();
    }

    ao(int i, IBinder iBinder) {
        this.xJ = i;
        if (iBinder != null) {
            this.alw = C0878a.bx(iBinder);
        } else {
            this.alw = null;
        }
    }

    public ao(ac acVar) {
        this.xJ = 1;
        this.alw = acVar;
    }

    public int describeContents() {
        return 0;
    }

    IBinder nj() {
        return this.alw == null ? null : this.alw.asBinder();
    }

    public void writeToParcel(Parcel dest, int flags) {
        ap.m1850a(this, dest, flags);
    }
}
