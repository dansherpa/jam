package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.C0874c;

/* renamed from: com.google.android.gms.wearable.internal.r */
public class C0885r implements SafeParcelable {
    public static final Creator<C0885r> CREATOR;
    public final C0874c alJ;
    public final int statusCode;
    public final int versionCode;

    static {
        CREATOR = new C0442s();
    }

    C0885r(int i, int i2, C0874c c0874c) {
        this.versionCode = i;
        this.statusCode = i2;
        this.alJ = c0874c;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0442s.m1857a(this, dest, flags);
    }
}
