package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.hn;
import com.google.android.gms.wearable.DataItemAsset;

public class DataItemAssetParcelable implements SafeParcelable, DataItemAsset {
    public static final Creator<DataItemAssetParcelable> CREATOR;
    private final String JI;
    private final String xD;
    final int xJ;

    static {
        CREATOR = new C0439j();
    }

    DataItemAssetParcelable(int versionCode, String id, String key) {
        this.xJ = versionCode;
        this.xD = id;
        this.JI = key;
    }

    public DataItemAssetParcelable(DataItemAsset value) {
        this.xJ = 1;
        this.xD = (String) hn.m1230f(value.getId());
        this.JI = (String) hn.m1230f(value.getDataItemKey());
    }

    public int describeContents() {
        return 0;
    }

    public /* synthetic */ Object freeze() {
        return nl();
    }

    public String getDataItemKey() {
        return this.JI;
    }

    public String getId() {
        return this.xD;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataItemAsset nl() {
        return this;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DataItemAssetParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        if (this.xD == null) {
            stringBuilder.append(",noid");
        } else {
            stringBuilder.append(",");
            stringBuilder.append(this.xD);
        }
        stringBuilder.append(", key=");
        stringBuilder.append(this.JI);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0439j.m1854a(this, dest, flags);
    }
}
