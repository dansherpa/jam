package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.RemoteException;
import com.google.android.gms.common.api.C0053a.C0052d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.DataApi;
import com.google.android.gms.wearable.DataApi.DataItemResult;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataApi.DeleteDataItemsResult;
import com.google.android.gms.wearable.DataApi.GetFdForAssetResult;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import com.google.android.gms.wearable.DataItemBuffer;
import com.google.android.gms.wearable.PutDataRequest;
import java.io.IOException;
import java.io.InputStream;

/* renamed from: com.google.android.gms.wearable.internal.f */
public final class C0883f implements DataApi {

    /* renamed from: com.google.android.gms.wearable.internal.f.a */
    public static class C1051a implements DataItemResult {
        private final DataItem alE;
        private final Status yw;

        public C1051a(Status status, DataItem dataItem) {
            this.yw = status;
            this.alE = dataItem;
        }

        public DataItem getDataItem() {
            return this.alE;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.b */
    public static class C1052b implements DeleteDataItemsResult {
        private final int alF;
        private final Status yw;

        public C1052b(Status status, int i) {
            this.yw = status;
            this.alF = i;
        }

        public int getNumDeleted() {
            return this.alF;
        }

        public Status getStatus() {
            return this.yw;
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.c */
    public static class C1053c implements GetFdForAssetResult {
        private final ParcelFileDescriptor alG;
        private final Status yw;

        public C1053c(Status status, ParcelFileDescriptor parcelFileDescriptor) {
            this.yw = status;
            this.alG = parcelFileDescriptor;
        }

        public ParcelFileDescriptor getFd() {
            return this.alG;
        }

        public InputStream getInputStream() {
            return new AutoCloseInputStream(this.alG);
        }

        public Status getStatus() {
            return this.yw;
        }

        public void release() {
            try {
                this.alG.close();
            } catch (IOException e) {
            }
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.1 */
    class C11651 extends C1113d<DataItemResult> {
        final /* synthetic */ PutDataRequest aly;
        final /* synthetic */ C0883f alz;

        C11651(C0883f c0883f, PutDataRequest putDataRequest) {
            this.alz = c0883f;
            this.aly = putDataRequest;
        }

        protected void m4279a(au auVar) throws RemoteException {
            auVar.m3869a((C0052d) this, this.aly);
        }

        public DataItemResult aq(Status status) {
            return new C1051a(status, null);
        }

        public /* synthetic */ Result m4280c(Status status) {
            return aq(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.2 */
    class C11662 extends C1113d<DataItemResult> {
        final /* synthetic */ Uri abh;
        final /* synthetic */ C0883f alz;

        C11662(C0883f c0883f, Uri uri) {
            this.alz = c0883f;
            this.abh = uri;
        }

        protected void m4282a(au auVar) throws RemoteException {
            auVar.m3861a((C0052d) this, this.abh);
        }

        protected DataItemResult aq(Status status) {
            return new C1051a(status, null);
        }

        protected /* synthetic */ Result m4283c(Status status) {
            return aq(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.3 */
    class C11673 extends C1113d<DataItemBuffer> {
        final /* synthetic */ C0883f alz;

        C11673(C0883f c0883f) {
            this.alz = c0883f;
        }

        protected void m4285a(au auVar) throws RemoteException {
            auVar.m3876o(this);
        }

        protected DataItemBuffer ar(Status status) {
            return new DataItemBuffer(DataHolder.af(status.getStatusCode()));
        }

        protected /* synthetic */ Result m4286c(Status status) {
            return ar(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.4 */
    class C11684 extends C1113d<DataItemBuffer> {
        final /* synthetic */ Uri abh;
        final /* synthetic */ C0883f alz;

        C11684(C0883f c0883f, Uri uri) {
            this.alz = c0883f;
            this.abh = uri;
        }

        protected void m4288a(au auVar) throws RemoteException {
            auVar.m3873b((C0052d) this, this.abh);
        }

        protected DataItemBuffer ar(Status status) {
            return new DataItemBuffer(DataHolder.af(status.getStatusCode()));
        }

        protected /* synthetic */ Result m4289c(Status status) {
            return ar(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.5 */
    class C11695 extends C1113d<DeleteDataItemsResult> {
        final /* synthetic */ Uri abh;
        final /* synthetic */ C0883f alz;

        C11695(C0883f c0883f, Uri uri) {
            this.alz = c0883f;
            this.abh = uri;
        }

        protected void m4291a(au auVar) throws RemoteException {
            auVar.m3875c(this, this.abh);
        }

        protected DeleteDataItemsResult as(Status status) {
            return new C1052b(status, 0);
        }

        protected /* synthetic */ Result m4292c(Status status) {
            return as(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.6 */
    class C11706 extends C1113d<GetFdForAssetResult> {
        final /* synthetic */ Asset alA;
        final /* synthetic */ C0883f alz;

        C11706(C0883f c0883f, Asset asset) {
            this.alz = c0883f;
            this.alA = asset;
        }

        protected void m4294a(au auVar) throws RemoteException {
            auVar.m3862a((C0052d) this, this.alA);
        }

        protected GetFdForAssetResult at(Status status) {
            return new C1053c(status, null);
        }

        protected /* synthetic */ Result m4295c(Status status) {
            return at(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.7 */
    class C11717 extends C1113d<GetFdForAssetResult> {
        final /* synthetic */ DataItemAsset alB;
        final /* synthetic */ C0883f alz;

        C11717(C0883f c0883f, DataItemAsset dataItemAsset) {
            this.alz = c0883f;
            this.alB = dataItemAsset;
        }

        protected void m4297a(au auVar) throws RemoteException {
            auVar.m3865a((C0052d) this, this.alB);
        }

        protected GetFdForAssetResult at(Status status) {
            return new C1053c(status, null);
        }

        protected /* synthetic */ Result m4298c(Status status) {
            return at(status);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.8 */
    class C11728 extends C1113d<Status> {
        final /* synthetic */ DataListener alC;
        final /* synthetic */ IntentFilter[] alD;
        final /* synthetic */ C0883f alz;

        C11728(C0883f c0883f, DataListener dataListener, IntentFilter[] intentFilterArr) {
            this.alz = c0883f;
            this.alC = dataListener;
            this.alD = intentFilterArr;
        }

        protected void m4300a(au auVar) throws RemoteException {
            auVar.m3864a((C0052d) this, this.alC, this.alD);
        }

        public /* synthetic */ Result m4301c(Status status) {
            return m4302d(status);
        }

        public Status m4302d(Status status) {
            return new Status(13);
        }
    }

    /* renamed from: com.google.android.gms.wearable.internal.f.9 */
    class C11739 extends C1113d<Status> {
        final /* synthetic */ DataListener alC;
        final /* synthetic */ C0883f alz;

        C11739(C0883f c0883f, DataListener dataListener) {
            this.alz = c0883f;
            this.alC = dataListener;
        }

        protected void m4304a(au auVar) throws RemoteException {
            auVar.m3863a((C0052d) this, this.alC);
        }

        public /* synthetic */ Result m4305c(Status status) {
            return m4306d(status);
        }

        public Status m4306d(Status status) {
            return new Status(13);
        }
    }

    private PendingResult<Status> m3146a(GoogleApiClient googleApiClient, DataListener dataListener, IntentFilter[] intentFilterArr) {
        return googleApiClient.m139a(new C11728(this, dataListener, intentFilterArr));
    }

    private void m3147a(Asset asset) {
        if (asset == null) {
            throw new IllegalArgumentException("asset is null");
        } else if (asset.getDigest() == null) {
            throw new IllegalArgumentException("invalid asset");
        } else if (asset.getData() != null) {
            throw new IllegalArgumentException("invalid asset");
        }
    }

    public PendingResult<Status> addListener(GoogleApiClient client, DataListener listener) {
        return m3146a(client, listener, null);
    }

    public PendingResult<DeleteDataItemsResult> deleteDataItems(GoogleApiClient client, Uri uri) {
        return client.m139a(new C11695(this, uri));
    }

    public PendingResult<DataItemResult> getDataItem(GoogleApiClient client, Uri uri) {
        return client.m139a(new C11662(this, uri));
    }

    public PendingResult<DataItemBuffer> getDataItems(GoogleApiClient client) {
        return client.m139a(new C11673(this));
    }

    public PendingResult<DataItemBuffer> getDataItems(GoogleApiClient client, Uri uri) {
        return client.m139a(new C11684(this, uri));
    }

    public PendingResult<GetFdForAssetResult> getFdForAsset(GoogleApiClient client, Asset asset) {
        m3147a(asset);
        return client.m139a(new C11706(this, asset));
    }

    public PendingResult<GetFdForAssetResult> getFdForAsset(GoogleApiClient client, DataItemAsset asset) {
        return client.m139a(new C11717(this, asset));
    }

    public PendingResult<DataItemResult> putDataItem(GoogleApiClient client, PutDataRequest request) {
        return client.m139a(new C11651(this, request));
    }

    public PendingResult<Status> removeListener(GoogleApiClient client, DataListener listener) {
        return client.m139a(new C11739(this, listener));
    }
}
