package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.internal.ab.C0876a;

/* renamed from: com.google.android.gms.wearable.internal.a */
public abstract class C1047a extends C0876a {
    public void m3845Z(DataHolder dataHolder) {
        throw new UnsupportedOperationException();
    }

    public void m3846a(Status status) {
        throw new UnsupportedOperationException();
    }

    public void m3847a(am amVar) {
        throw new UnsupportedOperationException();
    }

    public void m3848a(aq aqVar) {
        throw new UnsupportedOperationException();
    }

    public void m3849a(as asVar) {
        throw new UnsupportedOperationException();
    }

    public void m3850a(C0884p c0884p) {
        throw new UnsupportedOperationException();
    }

    public void m3851a(C0885r c0885r) {
        throw new UnsupportedOperationException();
    }

    public void m3852a(C0886t c0886t) {
        throw new UnsupportedOperationException();
    }

    public void m3853a(C0887v c0887v) {
        throw new UnsupportedOperationException();
    }

    public void m3854a(C0888x c0888x) {
        throw new UnsupportedOperationException();
    }

    public void m3855a(C0889z c0889z) {
        throw new UnsupportedOperationException();
    }
}
