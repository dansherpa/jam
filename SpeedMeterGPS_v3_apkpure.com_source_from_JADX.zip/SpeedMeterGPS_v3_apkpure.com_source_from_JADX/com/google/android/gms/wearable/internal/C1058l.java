package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.util.Log;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.google.android.gms.wearable.internal.l */
public class C1058l implements DataItem {
    private byte[] TC;
    private Map<String, DataItemAsset> alH;
    private Uri mUri;

    public C1058l(DataItem dataItem) {
        this.mUri = dataItem.getUri();
        this.TC = dataItem.getData();
        Map hashMap = new HashMap();
        for (Entry entry : dataItem.getAssets().entrySet()) {
            if (entry.getKey() != null) {
                hashMap.put(entry.getKey(), ((DataItemAsset) entry.getValue()).freeze());
            }
        }
        this.alH = Collections.unmodifiableMap(hashMap);
    }

    public /* synthetic */ Object freeze() {
        return nm();
    }

    public Map<String, DataItemAsset> getAssets() {
        return this.alH;
    }

    public byte[] getData() {
        return this.TC;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataItem nm() {
        return this;
    }

    public DataItem setData(byte[] data) {
        throw new UnsupportedOperationException();
    }

    public String toString() {
        return toString(Log.isLoggable("DataItem", 3));
    }

    public String toString(boolean verbose) {
        StringBuilder stringBuilder = new StringBuilder("DataItemEntity[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        stringBuilder.append(",dataSz=" + (this.TC == null ? "null" : Integer.valueOf(this.TC.length)));
        stringBuilder.append(", numAssets=" + this.alH.size());
        stringBuilder.append(", uri=" + this.mUri);
        if (verbose) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.alH.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.alH.get(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}
