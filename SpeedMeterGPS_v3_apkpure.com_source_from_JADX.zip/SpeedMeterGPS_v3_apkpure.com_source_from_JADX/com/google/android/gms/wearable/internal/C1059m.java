package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/* renamed from: com.google.android.gms.wearable.internal.m */
public class C1059m implements SafeParcelable, DataItem {
    public static final Creator<C1059m> CREATOR;
    private byte[] TC;
    private final Map<String, DataItemAsset> alH;
    private final Uri mUri;
    final int xJ;

    static {
        CREATOR = new C0440n();
    }

    C1059m(int i, Uri uri, Bundle bundle, byte[] bArr) {
        this.xJ = i;
        this.mUri = uri;
        Map hashMap = new HashMap();
        bundle.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        for (String str : bundle.keySet()) {
            hashMap.put(str, (DataItemAssetParcelable) bundle.getParcelable(str));
        }
        this.alH = hashMap;
        this.TC = bArr;
    }

    public int describeContents() {
        return 0;
    }

    public /* synthetic */ Object freeze() {
        return nn();
    }

    public Map<String, DataItemAsset> getAssets() {
        return this.alH;
    }

    public byte[] getData() {
        return this.TC;
    }

    public Uri getUri() {
        return this.mUri;
    }

    public boolean isDataValid() {
        return true;
    }

    public C1059m m3887m(byte[] bArr) {
        this.TC = bArr;
        return this;
    }

    public Bundle nh() {
        Bundle bundle = new Bundle();
        bundle.setClassLoader(DataItemAssetParcelable.class.getClassLoader());
        for (Entry entry : this.alH.entrySet()) {
            bundle.putParcelable((String) entry.getKey(), new DataItemAssetParcelable((DataItemAsset) entry.getValue()));
        }
        return bundle;
    }

    public C1059m nn() {
        return this;
    }

    public /* synthetic */ DataItem setData(byte[] x0) {
        return m3887m(x0);
    }

    public String toString() {
        return toString(Log.isLoggable("DataItem", 3));
    }

    public String toString(boolean verbose) {
        StringBuilder stringBuilder = new StringBuilder("DataItemParcelable[");
        stringBuilder.append("@");
        stringBuilder.append(Integer.toHexString(hashCode()));
        stringBuilder.append(",dataSz=" + (this.TC == null ? "null" : Integer.valueOf(this.TC.length)));
        stringBuilder.append(", numAssets=" + this.alH.size());
        stringBuilder.append(", uri=" + this.mUri);
        if (verbose) {
            stringBuilder.append("]\n  assets: ");
            for (String str : this.alH.keySet()) {
                stringBuilder.append("\n    " + str + ": " + this.alH.get(str));
            }
            stringBuilder.append("\n  ]");
            return stringBuilder.toString();
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        C0440n.m1855a(this, dest, flags);
    }
}
