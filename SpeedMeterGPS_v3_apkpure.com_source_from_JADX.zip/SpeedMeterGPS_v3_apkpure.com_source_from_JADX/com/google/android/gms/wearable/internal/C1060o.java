package com.google.android.gms.wearable.internal;

import android.net.Uri;
import com.google.android.gms.common.data.C0060d;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.DataItemAsset;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.wearable.internal.o */
public final class C1060o extends C0060d implements DataItem {
    private final int RD;

    public C1060o(DataHolder dataHolder, int i, int i2) {
        super(dataHolder, i);
        this.RD = i2;
    }

    public /* synthetic */ Object freeze() {
        return nm();
    }

    public Map<String, DataItemAsset> getAssets() {
        Map<String, DataItemAsset> hashMap = new HashMap(this.RD);
        for (int i = 0; i < this.RD; i++) {
            C1057k c1057k = new C1057k(this.DD, this.Ez + i);
            if (c1057k.getDataItemKey() != null) {
                hashMap.put(c1057k.getDataItemKey(), c1057k);
            }
        }
        return hashMap;
    }

    public byte[] getData() {
        return getByteArray("data");
    }

    public Uri getUri() {
        return Uri.parse(getString("path"));
    }

    public DataItem nm() {
        return new C1058l(this);
    }

    public DataItem setData(byte[] data) {
        throw new UnsupportedOperationException();
    }
}
