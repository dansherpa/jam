package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.data.C0060d;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

/* renamed from: com.google.android.gms.wearable.internal.h */
public final class C1055h extends C0060d implements DataEvent {
    private final int RD;

    public C1055h(DataHolder dataHolder, int i, int i2) {
        super(dataHolder, i);
        this.RD = i2;
    }

    public /* synthetic */ Object freeze() {
        return nk();
    }

    public DataItem getDataItem() {
        return new C1060o(this.DD, this.Ez, this.RD);
    }

    public int getType() {
        return getInteger("event_type");
    }

    public DataEvent nk() {
        return new C1054g(this);
    }
}
