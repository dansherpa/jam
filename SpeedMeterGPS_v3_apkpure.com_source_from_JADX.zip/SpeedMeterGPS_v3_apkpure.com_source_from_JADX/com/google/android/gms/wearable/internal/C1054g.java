package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataItem;

/* renamed from: com.google.android.gms.wearable.internal.g */
public class C1054g implements DataEvent {
    private int AQ;
    private DataItem alE;

    public C1054g(DataEvent dataEvent) {
        this.AQ = dataEvent.getType();
        this.alE = (DataItem) dataEvent.getDataItem().freeze();
    }

    public /* synthetic */ Object freeze() {
        return nk();
    }

    public DataItem getDataItem() {
        return this.alE;
    }

    public int getType() {
        return this.AQ;
    }

    public boolean isDataValid() {
        return true;
    }

    public DataEvent nk() {
        return this;
    }
}
