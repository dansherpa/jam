package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;

/* renamed from: com.google.android.gms.wearable.internal.c */
public class C0438c implements Creator<C0881b> {
    static void m1853a(C0881b c0881b, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, c0881b.xJ);
        C0072b.m234a(parcel, 2, c0881b.nj(), false);
        C0072b.m246a(parcel, 3, c0881b.alx, i, false);
        C0072b.m228G(parcel, C);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cv(x0);
    }

    public C0881b cv(Parcel parcel) {
        IntentFilter[] intentFilterArr = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        IBinder iBinder = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    iBinder = C0071a.m214p(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    intentFilterArr = (IntentFilter[]) C0071a.m199b(parcel, A, IntentFilter.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new C0881b(i, iBinder, intentFilterArr);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public C0881b[] ee(int i) {
        return new C0881b[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ee(x0);
    }
}
