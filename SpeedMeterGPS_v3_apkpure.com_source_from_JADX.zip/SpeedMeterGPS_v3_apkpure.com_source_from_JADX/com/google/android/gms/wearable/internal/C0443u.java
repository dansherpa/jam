package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.wearable.DataEvent;
import java.util.List;

/* renamed from: com.google.android.gms.wearable.internal.u */
public class C0443u implements Creator<C0886t> {
    static void m1858a(C0886t c0886t, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, c0886t.versionCode);
        C0072b.m252c(parcel, 2, c0886t.statusCode);
        C0072b.m251b(parcel, 3, c0886t.alK, false);
        C0072b.m228G(parcel, C);
    }

    public C0886t cA(Parcel parcel) {
        int i = 0;
        int B = C0071a.m189B(parcel);
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i2 = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    list = C0071a.m200c(parcel, A, ai.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new C0886t(i2, i, list);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cA(x0);
    }

    public C0886t[] ej(int i) {
        return new C0886t[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ej(x0);
    }
}
