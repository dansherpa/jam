package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;

/* renamed from: com.google.android.gms.wearable.e */
public class C0437e implements Creator<PutDataRequest> {
    static void m1812a(PutDataRequest putDataRequest, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, putDataRequest.xJ);
        C0072b.m236a(parcel, 2, putDataRequest.getUri(), i, false);
        C0072b.m233a(parcel, 4, putDataRequest.nh(), false);
        C0072b.m244a(parcel, 5, putDataRequest.getData(), false);
        C0072b.m228G(parcel, C);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cu(x0);
    }

    public PutDataRequest cu(Parcel parcel) {
        byte[] bArr = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        Bundle bundle = null;
        Uri uri = null;
        while (parcel.dataPosition() < B) {
            Bundle bundle2;
            Uri uri2;
            int g;
            byte[] bArr2;
            int A = C0071a.m187A(parcel);
            byte[] bArr3;
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    bArr3 = bArr;
                    bundle2 = bundle;
                    uri2 = uri;
                    g = C0071a.m205g(parcel, A);
                    bArr2 = bArr3;
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    g = i;
                    Bundle bundle3 = bundle;
                    uri2 = (Uri) C0071a.m194a(parcel, A, Uri.CREATOR);
                    bArr2 = bArr;
                    bundle2 = bundle3;
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    uri2 = uri;
                    g = i;
                    bArr3 = bArr;
                    bundle2 = C0071a.m215q(parcel, A);
                    bArr2 = bArr3;
                    break;
                case DetectedActivity.TILTING /*5*/:
                    bArr2 = C0071a.m216r(parcel, A);
                    bundle2 = bundle;
                    uri2 = uri;
                    g = i;
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    bArr2 = bArr;
                    bundle2 = bundle;
                    uri2 = uri;
                    g = i;
                    break;
            }
            i = g;
            uri = uri2;
            bundle = bundle2;
            bArr = bArr2;
        }
        if (parcel.dataPosition() == B) {
            return new PutDataRequest(i, uri, bundle, bArr);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public PutDataRequest[] ec(int i) {
        return new PutDataRequest[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ec(x0);
    }
}
