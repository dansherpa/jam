package com.google.android.gms.wearable;

import android.net.Uri;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0071a;
import com.google.android.gms.common.internal.safeparcel.C0071a.C0070a;
import com.google.android.gms.common.internal.safeparcel.C0072b;
import com.google.android.gms.location.DetectedActivity;

/* renamed from: com.google.android.gms.wearable.a */
public class C0434a implements Creator<Asset> {
    static void m1810a(Asset asset, Parcel parcel, int i) {
        int C = C0072b.m225C(parcel);
        C0072b.m252c(parcel, 1, asset.xJ);
        C0072b.m244a(parcel, 2, asset.getData(), false);
        C0072b.m240a(parcel, 3, asset.getDigest(), false);
        C0072b.m236a(parcel, 4, asset.ale, i, false);
        C0072b.m236a(parcel, 5, asset.uri, i, false);
        C0072b.m228G(parcel, C);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return cs(x0);
    }

    public Asset cs(Parcel parcel) {
        Uri uri = null;
        int B = C0071a.m189B(parcel);
        int i = 0;
        ParcelFileDescriptor parcelFileDescriptor = null;
        String str = null;
        byte[] bArr = null;
        while (parcel.dataPosition() < B) {
            int A = C0071a.m187A(parcel);
            switch (C0071a.ar(A)) {
                case DataEvent.TYPE_CHANGED /*1*/:
                    i = C0071a.m205g(parcel, A);
                    break;
                case DataEvent.TYPE_DELETED /*2*/:
                    bArr = C0071a.m216r(parcel, A);
                    break;
                case DetectedActivity.STILL /*3*/:
                    str = C0071a.m213o(parcel, A);
                    break;
                case DetectedActivity.UNKNOWN /*4*/:
                    parcelFileDescriptor = (ParcelFileDescriptor) C0071a.m194a(parcel, A, ParcelFileDescriptor.CREATOR);
                    break;
                case DetectedActivity.TILTING /*5*/:
                    uri = (Uri) C0071a.m194a(parcel, A, Uri.CREATOR);
                    break;
                default:
                    C0071a.m198b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new Asset(i, bArr, str, parcelFileDescriptor, uri);
        }
        throw new C0070a("Overread allowed size end=" + B, parcel);
    }

    public Asset[] ea(int i) {
        return new Asset[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ea(x0);
    }
}
