package com.google.android.gms.wearable;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.ac.C0878a;
import com.google.android.gms.wearable.internal.af;
import com.google.android.gms.wearable.internal.ai;

public abstract class WearableListenerService extends Service implements DataListener, MessageListener, NodeListener {
    public static final String BIND_LISTENER_INTENT_ACTION = "com.google.android.gms.wearable.BIND_LISTENER";
    private IBinder Gz;
    private volatile int aln;
    private Handler alo;
    private Object alp;
    private boolean alq;
    private String xN;

    /* renamed from: com.google.android.gms.wearable.WearableListenerService.a */
    private class C1046a extends C0878a {
        final /* synthetic */ WearableListenerService alr;

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.1 */
        class C04301 implements Runnable {
            final /* synthetic */ DataHolder als;
            final /* synthetic */ C1046a alt;

            C04301(C1046a c1046a, DataHolder dataHolder) {
                this.alt = c1046a;
                this.als = dataHolder;
            }

            public void run() {
                DataEventBuffer dataEventBuffer = new DataEventBuffer(this.als);
                try {
                    this.alt.alr.onDataChanged(dataEventBuffer);
                } finally {
                    dataEventBuffer.release();
                }
            }
        }

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.2 */
        class C04312 implements Runnable {
            final /* synthetic */ C1046a alt;
            final /* synthetic */ af alu;

            C04312(C1046a c1046a, af afVar) {
                this.alt = c1046a;
                this.alu = afVar;
            }

            public void run() {
                this.alt.alr.onMessageReceived(this.alu);
            }
        }

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.3 */
        class C04323 implements Runnable {
            final /* synthetic */ C1046a alt;
            final /* synthetic */ ai alv;

            C04323(C1046a c1046a, ai aiVar) {
                this.alt = c1046a;
                this.alv = aiVar;
            }

            public void run() {
                this.alt.alr.onPeerConnected(this.alv);
            }
        }

        /* renamed from: com.google.android.gms.wearable.WearableListenerService.a.4 */
        class C04334 implements Runnable {
            final /* synthetic */ C1046a alt;
            final /* synthetic */ ai alv;

            C04334(C1046a c1046a, ai aiVar) {
                this.alt = c1046a;
                this.alv = aiVar;
            }

            public void run() {
                this.alt.alr.onPeerDisconnected(this.alv);
            }
        }

        private C1046a(WearableListenerService wearableListenerService) {
            this.alr = wearableListenerService;
        }

        public void m3841Y(DataHolder dataHolder) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onDataItemChanged: " + this.alr.xN + ": " + dataHolder);
            }
            this.alr.ni();
            synchronized (this.alr.alp) {
                if (this.alr.alq) {
                    dataHolder.close();
                    return;
                }
                this.alr.alo.post(new C04301(this, dataHolder));
            }
        }

        public void m3842a(af afVar) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onMessageReceived: " + afVar);
            }
            this.alr.ni();
            synchronized (this.alr.alp) {
                if (this.alr.alq) {
                    return;
                }
                this.alr.alo.post(new C04312(this, afVar));
            }
        }

        public void m3843a(ai aiVar) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onPeerConnected: " + this.alr.xN + ": " + aiVar);
            }
            this.alr.ni();
            synchronized (this.alr.alp) {
                if (this.alr.alq) {
                    return;
                }
                this.alr.alo.post(new C04323(this, aiVar));
            }
        }

        public void m3844b(ai aiVar) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", "onPeerDisconnected: " + this.alr.xN + ": " + aiVar);
            }
            this.alr.ni();
            synchronized (this.alr.alp) {
                if (this.alr.alq) {
                    return;
                }
                this.alr.alo.post(new C04334(this, aiVar));
            }
        }
    }

    public WearableListenerService() {
        this.aln = -1;
        this.alp = new Object();
    }

    private boolean ed(int i) {
        String str = GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE;
        String[] packagesForUid = getPackageManager().getPackagesForUid(i);
        if (packagesForUid == null) {
            return false;
        }
        for (Object equals : packagesForUid) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }

    private void ni() throws SecurityException {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.aln) {
            if (GooglePlayServicesUtil.m125b(getPackageManager(), GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE) && ed(callingUid)) {
                this.aln = callingUid;
                return;
            }
            throw new SecurityException("Caller is not GooglePlayServices");
        }
    }

    public final IBinder onBind(Intent intent) {
        return BIND_LISTENER_INTENT_ACTION.equals(intent.getAction()) ? this.Gz : null;
    }

    public void onCreate() {
        super.onCreate();
        if (Log.isLoggable("WearableLS", 3)) {
            Log.d("WearableLS", "onCreate: " + getPackageName());
        }
        this.xN = getPackageName();
        HandlerThread handlerThread = new HandlerThread("WearableListenerService");
        handlerThread.start();
        this.alo = new Handler(handlerThread.getLooper());
        this.Gz = new C1046a();
    }

    public void onDataChanged(DataEventBuffer dataEvents) {
    }

    public void onDestroy() {
        synchronized (this.alp) {
            this.alq = true;
            this.alo.getLooper().quit();
        }
        super.onDestroy();
    }

    public void onMessageReceived(MessageEvent messageEvent) {
    }

    public void onPeerConnected(Node peer) {
    }

    public void onPeerDisconnected(Node peer) {
    }
}
