package com.google.android.gms.wearable;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.Optional;
import com.google.android.gms.common.api.Api.C0048b;
import com.google.android.gms.common.api.Api.C0049c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.internal.gz;
import com.google.android.gms.wearable.internal.C0882e;
import com.google.android.gms.wearable.internal.C0883f;
import com.google.android.gms.wearable.internal.ae;
import com.google.android.gms.wearable.internal.ah;
import com.google.android.gms.wearable.internal.au;

public class Wearable {
    public static final Api<WearableOptions> API;
    public static final DataApi DataApi;
    public static final MessageApi MessageApi;
    public static final NodeApi NodeApi;
    public static final C0435b alm;
    public static final C0049c<au> yE;
    private static final C0048b<au, WearableOptions> yF;

    /* renamed from: com.google.android.gms.wearable.Wearable.1 */
    static class C08731 implements C0048b<au, WearableOptions> {
        C08731() {
        }

        public au m3107a(Context context, Looper looper, gz gzVar, WearableOptions wearableOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            if (wearableOptions == null) {
                WearableOptions wearableOptions2 = new WearableOptions(null);
            }
            return new au(context, looper, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    public static final class WearableOptions implements Optional {

        public static class Builder {
            public WearableOptions build() {
                return new WearableOptions();
            }
        }

        private WearableOptions(Builder builder) {
        }
    }

    static {
        DataApi = new C0883f();
        MessageApi = new ae();
        NodeApi = new ah();
        alm = new C0882e();
        yE = new C0049c();
        yF = new C08731();
        API = new Api(yF, yE, new Scope[0]);
    }

    private Wearable() {
    }
}
