package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.C0907g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.internal.C1060o;

public class DataItemBuffer extends C0907g<DataItem> implements Result {
    private final Status yw;

    public DataItemBuffer(DataHolder dataHolder) {
        super(dataHolder);
        this.yw = new Status(dataHolder.getStatusCode());
    }

    protected /* synthetic */ Object m4081c(int i, int i2) {
        return m4082n(i, i2);
    }

    protected String eU() {
        return "path";
    }

    public Status getStatus() {
        return this.yw;
    }

    protected DataItem m4082n(int i, int i2) {
        return new C1060o(this.DD, i, i2);
    }
}
