package com.google.android.gms.wearable;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.C0907g;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.wearable.internal.C1055h;

public class DataEventBuffer extends C0907g<DataEvent> implements Result {
    private final Status yw;

    public DataEventBuffer(DataHolder dataHolder) {
        super(dataHolder);
        this.yw = new Status(dataHolder.getStatusCode());
    }

    protected /* synthetic */ Object m4079c(int i, int i2) {
        return m4080m(i, i2);
    }

    protected String eU() {
        return "path";
    }

    public Status getStatus() {
        return this.yw;
    }

    protected DataEvent m4080m(int i, int i2) {
        return new C1055h(this.DD, i, i2);
    }
}
